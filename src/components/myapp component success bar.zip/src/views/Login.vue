
<template>
<div id="app">
  <v-app id="inspire">
    <v-app id="inspire">
      <v-main>
        <v-container
          class="fill-height"
          fluid
        >
          <v-row
            align="center"
            justify="center"
          >
            <v-col
              cols="12"
              sm="8"
              md="4"
            >
              <v-card class="elevation-12">
                <v-toolbar
                  color="primary"
                  dark
                  flat
                >
                  <v-toolbar-title>Login form</v-toolbar-title>
                  <v-spacer></v-spacer>
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <v-btn
                        :href="source"
                        icon
                        large
                        target="_blank"
                        v-on="on"
                      >
                        <v-icon>mdi-code-tags</v-icon>
                      </v-btn>
                    </template>
                    <span>Source</span>
                  </v-tooltip>
                </v-toolbar>
                <v-card-text>
                  <v-form>
                    <v-text-field
                      label="Username"
                      name="login"
                      prepend-icon="mdi-account"
                      type="text"
                      v-model="username"
                    ></v-text-field>
                    <v-text-field
                      id="password"
                      label="Password"
                      name="password"
                      prepend-icon="mdi-lock"
                      type="password"
                      v-model="password"
                    ></v-text-field>
                  </v-form>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="primary" @click="login">Login</v-btn>
                </v-card-actions>
              </v-card>
            </v-col>
          </v-row>
        </v-container>
      </v-main>
    </v-app>
  </v-app>
</div>
</template>

<script>
import Axios from 'axios'
export default {
  name: 'App',
  components: {
  },
  data: () => ({
    username: '',
    password: ''
  }),
  methods: {
    login () {
      try {
        var user = {
          em_username: this.username,
          em_password: this.password
        }
        console.log('tmmm' + user)
        // const url = 'https://localhost:5001/Home/login'
        const url = ' http://cptsvs52t/dist/Home/login'
        Axios.post(url, user).then(res => {
          console.log(res.data)
          localStorage.setItem('user', res.data[0].em_username)
          // router.push('/main')
          // this.$router.push('/main')
          this.$router.replace('main')
        })
      } catch (error) {
        console.log(error)
      }
    },
    test () {
      this.$router.replace('main')
    }
  },
  computed: {
    show () {
      return 0
    }
  },
  mounted () {
    localStorage.clear()
  }

}
</script>
