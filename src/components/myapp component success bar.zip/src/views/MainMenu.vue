<template>
  <div>
      <!-- <About/> -->
<v-container>
  <v-row>
     <v-col cols="4">
        <Dash/>
     </v-col>
     <v-col cols="4">
        <Dash/>
     </v-col>
     <v-col cols="4">
        <Dash/>
     </v-col>
  </v-row>
</v-container>

<v-container>
  <v-row>
     <v-col cols="4">
        <Graph/>
     </v-col>
     <v-col cols="4">
        <Graph/>
     </v-col>
     <v-col cols="4">
        <Graph/>
     </v-col>
  </v-row>
</v-container>
   </div>
</template>

<script>
// import About from './About'
import Dash from './Dasbord'
import Graph from './Graph'
export default {
  components: {
    // About,
    Dash,
    Graph
  }
}
</script>
