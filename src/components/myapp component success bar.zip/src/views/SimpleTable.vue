<template>
 <div>
   <v-container>
     <!-- <v-row>
          <v-col  md="1">
               <v-btn class="mx-2" fab dark  color="cyan" @click="Show_insert()"><v-icon dark>mdi-plus</v-icon></v-btn>
         </v-col>
            <v-col  md="11">
         </v-col>
     </v-row> -->
   </v-container>
   <div v-if="showsuccess"><Success/></div>
   <v-card>
   <div v-if="firstLoad">
         <Skalaton/>
       </div>
        <v-card-title v-show="!firstLoad">
      Product  <v-btn class="mx-2" fab dark  color="cyan" @click="Show_insert()"><v-icon dark>mdi-plus</v-icon></v-btn>
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
         <!-- <v-skeleton-loader v-if="firstLoad"  type="table" type="list-item-avatar,  card-heading, image,list-item-avatar"></v-skeleton-loader> -->
     <v-simple-table style="margin-top:calc(1%)" v-show="!firstLoad" >
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-center">
             Product Name
          </th>
          <th class="text-center">
            Product Made
          </th>
           <th class="text-center">
            Product Price
          </th>
           <th class="text-center">
            Product Type
          </th>
           <th class="text-center">
            Product Code
          </th>
            <th class="text-center">
            Action
          </th>
        </tr>
      </thead>
      <tbody class="text-center">
        <tr
          v-for="item in datarow"
          :key="item.product_name"
        >
          <td>{{ item.product_name }}</td>
          <td>{{ item.product_made }}</td>
          <td>{{ item.product_price }}</td>
          <td>{{ item.product_type }}</td>
          <td>{{ item.product_code }}</td>
             <td>
              <v-btn @click="Show_update(item.product_id,item.product_name,item.product_price,item.product_type,item.product_code)" text icon small color="orange darken-2"><v-icon >mdi-pencil </v-icon></v-btn>
              <v-btn  @click="Show_delete(item.product_id)" text icon small color="red" ><v-icon >mdi-delete-forever</v-icon></v-btn>
            </td>
        </tr>
      </tbody>
    </template>
  </v-simple-table>
  <br/>
  </v-card>
<!-- ********************************* dialog confirm delete ******************************************* -->
   <v-dialog
      v-model="dialog"
      width="300"
    >
      <v-card>
        <v-card-title class="headline grey lighten-2">
          Delete
        </v-card-title>

        <v-card-text>
          confirm delete
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            text
            @click="delete_product()"
          >
            Confirm
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
<!-- ********************************* /dialog confirm delete ******************************************* -->
<!-- ********************************* dialog update ******************************************* -->
 <v-dialog
      v-model="dialog_update"
      width="600"
    >
      <v-card>
        <v-card-title class="headline grey lighten-2">
          Update Product
        </v-card-title>

        <v-card-text>
           <v-container>
             <v-row>
               <v-col cols="12" md="4">
                    <v-text-field
                        v-model="product_name_update"
                        label="Product Name"
                        required>
                    </v-text-field>
               </v-col>
               <v-col cols="12" md="4">
                       <v-text-field
                        v-model="product_made_update"
                        label="Product Made"
                        required>
                    </v-text-field>
               </v-col>
               <v-col cols="12" md="4">
                        <v-text-field
                        v-model="product_price_update"
                        label="Product Price"
                        required>
                    </v-text-field>
               </v-col>
             </v-row>
             <v-row>
                <v-col cols="12" md="4">
                    <v-text-field
                        v-model="product_type_update"
                        label="Product Type"
                        required>
                    </v-text-field>
               </v-col>
               <v-col cols="12" md="4">
                       <v-text-field
                        v-model="product_code_update"
                        label="Product Code"
                        required>
                    </v-text-field>
               </v-col>
             </v-row>
           </v-container>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            text
            @click="update_product()"
          >
            Confirm
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
<!-- ********************************* /dialog update ******************************************* -->

<v-dialog
        transition="dialog-top-transition"
        max-width="600"
        v-model="dialog_insert"
      >
        <template>
          <v-card>
            <v-toolbar
              color="primary"
              dark
            >Opening from the top</v-toolbar>
            <v-card-text>
              <!-- <div class="text-h2 pa-12">Hello world!</div> -->
                <v-container>
             <v-row>
               <v-col cols="12" md="4">
                    <v-text-field
                        v-model="product_name"
                        label="Product Name"
                        required>
                    </v-text-field>
               </v-col>
               <v-col cols="12" md="4">
                       <v-text-field
                        v-model="product_made"
                        label="Product Made"
                        required>
                    </v-text-field>
               </v-col>
               <v-col cols="12" md="4">
                        <v-text-field
                        v-model="product_price"
                        label="Product Price"
                        required>
                    </v-text-field>
               </v-col>
             </v-row>
             <v-row>
                <v-col cols="12" md="4">
                    <v-text-field
                        v-model="product_type"
                        label="Product Type"
                        required>
                    </v-text-field>
               </v-col>
               <v-col cols="12" md="4">
                       <v-text-field
                        v-model="product_code"
                        label="Product Code"
                        required>
                    </v-text-field>
               </v-col>
             </v-row>
           </v-container>
            </v-card-text>
            <v-card-actions class="justify-end">
              <v-btn
                text
                @click="insert()"
              >Save</v-btn>
            </v-card-actions>
          </v-card>
        </template>
      </v-dialog>
 </div>
</template>
<script>
import Axios from 'axios'
import Skalaton from '../components/Skeleton'
import Success from '../components/Successbar'
export default {
  components: {
    Skalaton,
    Success
  },
  data () {
    return {
      data: '',
      dialog: false,
      id_delete: '',
      dialog_update: false,
      product_id_update: '',
      product_name_update: '',
      product_made_update: '',
      product_price_update: '',
      product_type_update: '',
      product_code_update: '',
      product_id: '',
      product_name: '',
      product_made: '',
      product_price: '',
      product_type: '',
      product_code: '',
      dialog_insert: false,
      firstLoad: true,
      search: '',
      showsuccess: false
    }
  },
  methods: {
    Show_delete (id) {
      console.log(id)
      this.id_delete = id
      this.dialog = true
    },
    Show_insert () {
      this.dialog_insert = true
    },
    reset_insert () {
      this.product_name = ''
      this.product_made = ''
      this.product_price = ''
      this.product_type = ''
      this.product_code = ''
    },
    Show_update (id, name, price, type, code) {
      this.product_id_update = id
      this.product_name_update = name
      this.product_made_update = name
      this.product_price_update = price
      this.product_type_update = type
      this.product_code_update = code
      console.log('update')
      this.dialog_update = true
    },
    update_product () {
      this.dialog_update = false
      var product = {
        product_name: this.product_name_update,
        product_made: this.product_made_update,
        product_price: this.product_price_update,
        product_type: this.product_type_update,
        product_code: this.product_code_update
      }
      try {
        const url = 'https://localhost:5001/Home/Update/' + this.product_id_update
        Axios.put(url, product).then(res => {
          console.log('data update' + res)
          this.get_product()
        })
      } catch (error) {
        console.log(error)
      }
    },
    insert () {
      setTimeout(() => {
        this.showsuccess = true
      }, 1000)
      var product = {
        product_name: this.product_name,
        product_made: this.product_made,
        product_price: this.product_price,
        product_type: this.product_type,
        product_code: this.product_code
      }
      try {
        const url = 'https://localhost:5001/Home/Insert/' + this.product_id
        Axios.post(url, product).then(res => {
          console.log('data insert' + res)
          this.dialog_insert = false
          this.reset_insert()
          this.showsuccess = false
          setTimeout(() => {
            this.get_product()
          }, 3000)
        })
      } catch (error) {
        console.log(error)
      }
    },
    get_product () {
      try {
        const url = 'https://localhost:5001/Home/product'
        Axios.get(url).then(res => {
          console.log(res)
          this.data = res.data
        })
      } catch (error) {
        console.log(error)
      }
      console.log('get')
    },
    delete_product () {
      setTimeout(() => {
        this.showsuccess = true
      }, 1000)
      try {
        const url = 'https://localhost:5001/Home/Delete/' + this.id_delete
        Axios.delete(url).then(res => {
          console.log(res)
          this.dialog = false
          this.showsuccess = false
          setTimeout(() => {
            this.get_product()
          }, 3000)
        })
      } catch (error) {
        console.log(error)
      }
    }
  },
  computed: {
    datarow () {
      console.log(this.data)
      return this.data
    }
  },
  mounted () {
    // try {
    //   const url = 'https://localhost:5001/Home/product'
    //   Axios.get(url).then(res => {
    //     console.log(res)
    //     this.data = res.data
    //   })
    // } catch (error) {
    //   console.log(error)
    // }
    this.get_product()
    setTimeout(() => {
      this.firstLoad = false
    }, 1000)
  }
}
</script>
