import Vue from 'vue'
import VueRouter from 'vue-router'
// import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import MainPage from '../views/MainPage.vue'
import Calenda from '../views/Calenda.vue'
import datatableTest from '../views/datatableTest.vue'
import SimpleTable from '../views/SimpleTable.vue'
import Skalaton from '../components/Skeleton.vue'
import Success from '../components/Successbar.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/skalaton',
    name: 'Skalaton',
    component: Skalaton
  },
  {
    path: '/success',
    name: 'Success',
    component: Success
  },
  {
    path: '/Crud',
    name: 'datatableTest',
    component: datatableTest
  },
  {
    path: '/calenda',
    name: 'Calenda',
    component: Calenda
  },
  {
    path: '/main',
    name: 'Main',
    component: MainPage
  },
  {
    path: '/simple',
    name: 'SimpleTable',
    component: SimpleTable
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
