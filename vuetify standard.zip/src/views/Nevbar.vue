/* eslint-disable vue/no-side-effects-in-computed-properties */
<template>
  <v-app-bar app color="primary" dark>
    <div class="d-flex align-center">
      <v-img
        alt="Vuetify Logo"
        class="shrink mr-2"
        contain
        src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png"
        transition="scale-transition"
        width="40"
      />

      <v-img
        alt="Vuetify Name"
        class="shrink mt-1 hidden-sm-and-down"
        contain
        min-width="100"
        src="https://cdn.vuetifyjs.com/images/logos/vuetify-name-dark.png"
        width="100"
      />
    </div>

    <v-spacer>
  <v-btn  @click="go_home"   text style="padding:calc(3%)">
      <v-icon large>mdi-pig</v-icon>
       Home
    </v-btn>
     <v-btn  @click="go_calenda"  text style="padding:calc(3%)" >
      <v-icon large>mdi-sheep</v-icon>
      Calenda
    </v-btn>
     <v-btn   @click="go_about"  text style="padding:calc(3%)" >
      <v-icon large>mdi-cow</v-icon>
      About
    </v-btn>
     <v-btn  @click="go_crud"  text style="padding:calc(3%)" >
      <v-icon large>mdi-turtle</v-icon>
      Turtle
    </v-btn>
     <v-btn   text style="padding:calc(3%)" >
      <v-icon large>mdi-panda</v-icon>
      Panda
    </v-btn>
    </v-spacer>
 <v-tooltip left>
    <template v-slot:activator="{ on, attrs }">
    <v-btn target="_blank" text @click="Logout" v-bind="attrs"
          v-on="on">
      <!-- <span class="mr-2">Latest Release</span> -->
      <v-icon>mdi-import</v-icon>
    </v-btn>
     </template>
      <span>Logout</span>
 </v-tooltip>
  </v-app-bar>
</template>

<script>
export default {
  name: 'App',
  components: {
  },
  data: () => ({
    username: '',
    password: '',
    valuetap: localStorage.getItem('test')
  }),
  methods: {
    go_calenda () {
      this.$router.replace('calenda')
    },
    go_crud () {
      this.$router.replace('crud')
    },
    go_home () {
      this.$router.replace('main')
    },
    go_about () {
      this.$router.replace('about')
    },
    Logout () {
      this.$router.replace('/')
    }
  },
  computed: {
  }
}
</script>
