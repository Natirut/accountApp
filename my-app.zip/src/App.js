import React from 'react';
//import React, { Component } from 'react'
//import logo from './logo.svg';
import './Page/App.css';
import './Nev/App.css';
import ReactDOM from 'react-dom'
import  Pages from './Page/index.component'
//React.Component

import RootNavbar from './Nev/nevbar'
import Navbar from './Nev/index.component'
import Grid from '@material-ui/core/Grid'
import './index.css'
class App extends React.Component{
  render(){
   
    return(
      <>
        <Grid container apacing={0} className="BackG">
           <Grid item xs={12}>
              <Navbar />
              <Pages />
           </Grid>
        </Grid>
         
      </>
    )
  }
}


export default App // export ตัว Component App เพื่อเอาไปใช้ที่ไฟล์อื่น
