import React from 'react';
import Shee1 from './Pass_component/sheet1'
class Main2 extends React.Component{
    render(){
        return(
          <div>
           <Shee1 />
          </div>
        )
      
    }
}
export default Main2