import React from 'react';
import './five_component/App.css';
import Page1 from './five_component/compo1'
import Page2 from './five_component/compo2'
import Page3 from './five_component/compo3'
import Page4 from './five_component/compo4'
import Page5 from './five_component/compo5'

class Main extends React.Component{
    render(){
        return(
            <div >
                <div class="top-left " ><Page1/></div>
                <div class="top-right" ><Page2/></div>
                <div class="center" ><Page3/></div>
                <div class="buttom-left" ><Page4/></div>
                <div class="buttom-right" ><Page5/></div>
            </div>
           
        )
    }
}
export default Main