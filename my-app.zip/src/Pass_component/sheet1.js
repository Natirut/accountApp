import React from 'react'
import Sheet2 from './sheet2'
class Shet1 extends React.Component{
    constructor() {
        super();
        this.state = {
            status : null
        }
    }
    
   componentDidMount(){
    this.setState(prevState => {
        return {
            status:  <Sheet2 close={this.clear}/>
        }
    });
   }
    render(){
        return(
            <div>
                <div>Sheet1</div>
                {this.state.status}
                {/* <Page3 iAmProps={this.state.count} /> */}
                 
            </div>
        )
    }

    clear = () => {
        console.log("clear")
        this.setState(prevState => {
            return { status: null }
        });
    };

   


    
}
export default Shet1