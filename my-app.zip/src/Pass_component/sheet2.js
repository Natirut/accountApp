import React from 'react'
import './style.css'

class Shet2 extends React.Component {  
    constructor(props) {
        super();
        this.state = {
            person: [
                { id: "59161030", fname: "Supa", age: "20" },
                { id: "59161025", fname: "Tiger", age: "32" },
                { id: "59160683", fname: "Tae", age: "31" },
                { id: "59163796", fname: "Fere", age: "75" }
            ],
            count: 1,
            
        }
        this.handleClose = this.handleClose.bind(this);
        console.log(props)
    }
    componentWillReceiveProps() {
        console.log(this.props)
    }
    render() {
    //     var _data = this.props.info;
    //    console.log(_data);
        return (
            // <table>
            //     {this.state.person.map((item =>
            //       <tr key={item.id}>{item.fname}{item.age}</tr>
            //     ))}
           // </table>
           <>
           <button onClick={this.handleClose}>close</button>
            <table>
                <tr key={"header"}>
                    {Object.keys(this.state.person[0]).map((key) => (
                        <th>{key}</th>
                    ))}
                </tr>
                {this.state.person.map((item) => (
                    <tr key={item.id}>
                        {Object.values(item).map((val) => (
                            <td>{val}</td>
                        ))}
                    </tr>
                ))}
            </table>
         </>
        
        )
    }

    componentWillUnmount() {
        // window.removeEventListener('resize', this.resizeListener)
        console.log("willUnmount")
    }
    handleClose() {
        this.props.close();
    }
}
export default Shet2