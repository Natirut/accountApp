import React from 'react'
import Page3 from './compo3'
class Show1 extends React.Component {
    constructor() {
        super();
        this.state = {
            name: "Now",
            count: 1
        }
        this.plus1 = this.plus1.bind(this);
    }
  

    render() {
        return (
            <div class="div1">
                1
                <input type='button' onClick={this.plus1} />
                Count: {this.state.count}
                Count: {this.state.name}

                <div class="center" >
                    <Page3 iAmProps={this.state.count} />
                </div>
            </div>

        )
    }
    plus = () => {
        this.setState(prevState => {
            return { count: prevState.count + 1 }
        });
    };

    plus1() {
        this.setState(prevState => {
            return { count: prevState.count + 1 }
        });
    }

    componentDidMount() {
        this.setState(prevState => {
            return {
                name: "now2"
            }
        });
    }
}
export default Show1