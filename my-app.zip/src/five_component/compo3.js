import React from 'react'
class Show3 extends React.Component{
    constructor(props) {
      
        super();
        console.log(props)
        this.state = {
            name: ''
        }
    }
    componentWillReceiveProps() {
        // this.setState({
        //     name: this.props
        // });
     
        this.setState(prevState => {
            return {
                name: this.props.iAmProps
            }
        });
      
        console.log('componentWillReceiveProps: ', this.props.iAmProps)
    }
    render(){
        // console.log(this.props)
        return(
            <div class="div3">
                3
                Name: {this.state.name}
                {/* <button onClick={this.hand}>hand</button> */}
                </div>
            
        )
    }

    hand = () =>{
        // console.log(this.state.name)
    }
}
export default Show3