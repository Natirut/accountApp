import React from 'react'
class Show4 extends React.Component{
    render(){
        return(
            <div class="div4">4</div>
        )
    }
}
export default Show4