import React from 'react'
class Show2 extends React.Component{
    render(){
        return(
            <div class="div2">2</div>
        )
    }
}
export default Show2