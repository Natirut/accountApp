import React from 'react'
class Show5 extends React.Component{
    render(){
        return(
            <div class="div5">5</div>
        )
    }
}
export default Show5