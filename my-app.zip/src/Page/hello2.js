import React from 'react';
//import React, { Component } from 'react'
//import logo from './logo.svg';
import './App.css';
//React.Component

class App2 extends React.Component{
  render(){
    return(
      <div >
         <h1>Hello 2</h1>
      </div>
    )
  }
}


export default App2 // export ตัว Component App เพื่อเอาไปใช้ที่ไฟล์อื่น
