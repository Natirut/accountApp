import React from 'react';
//import React, { Component } from 'react'
//import logo from './logo.svg';
//import './App.css';
import Grid from '@material-ui/core/Grid'
//React.Component

class App1 extends React.Component{
  render(){
    return(
      <div>
          {/* <Grid container spacing={0}> */}
             <Grid item xs={12} style={{ backgroundColor: 'blue' }}>
                   <h1>Hello</h1>
            </Grid>
            {/* <Grid item xs={12} style={{ backgroundColor: 'red' }}>
                   <h1>Hellor</h1>
            </Grid>
          </Grid> */}
        
         {/* <input type="text"   onChange={this.showText} ></input>
         <br/>
         <select name="cars" id="cars" onChange={this.change}>
          <option value="volvo">Volvo</option>
          <option value="saab">Saab</option>
          <option value="opel">Opel</option>
          <option value="audi">Audi</option>
        </select> */}
      </div>
    )
  }
  showText(e){
    //console.log(e.target.value);
    console.log(e);
  }
  change(e){
    console.log(e.target.value);
  }
}


export default App1 // export ตัว Component App เพื่อเอาไปใช้ที่ไฟล์อื่น
