import React from 'react';
import Home from './home/index.component'
import App1 from './hello1'
import App2 from './hello2'
import App3 from './hello3'
import Grid from '@material-ui/core/Grid';
class Main extends React.Component{
    constructor(props){
      
      super(props) 
      this.state = {
          page:null
      }
    }

    componentDidMount(){
     if(this.props.page === 'home'){
         this.setState({page:<Home/>})
     }else if(this.props.page === 'hello1'){
        this.setState({page:<App1/>})
     }
     else if(this.props.page === 'hello2'){
        this.setState({page:<App2/>})
     }
     else if(this.props.page === 'hello3'){
        this.setState({page:<App3/>})
     }
    }

    render(){
        return(
           < >
                <Grid container style={{ width: '100% !important' }} >
                    {this.state.page}
                </Grid>
           </>
        )
    }
}
export default Main