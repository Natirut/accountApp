import React from 'react';
import ReactDOM from 'react-dom'

import PageSelect from '../Page/index.component'
class Navbar extends React.Component {
    constructor() {
        super();

    }

    componentDidMount() {
        ReactDOM.unmountComponentAtNode(document.getElementById('test'))
        ReactDOM.render(<PageSelect page='home' />, document.getElementById('test'))
    }
    change1() {
        ReactDOM.unmountComponentAtNode(document.getElementById('test'))
        ReactDOM.render(<PageSelect page='hello1' />, document.getElementById('test'));
    }

    change2() {
        ReactDOM.unmountComponentAtNode(document.getElementById('test'))
        ReactDOM.render(<PageSelect page='hello2' />, document.getElementById('test'));
      
    }

    change3() {
        ReactDOM.unmountComponentAtNode(document.getElementById('test'))
        ReactDOM.render(<PageSelect page='hello3' />, document.getElementById('test'));
    }

    render() {
        return (
            <div>
                <div className="nav">
                    <input type="checkbox" id="nav-check" />
                    <div className="nav-header">
                        <div className="nav-title">
                            Projectee
                      </div>
                    </div>
                    <div className="nav-btn">
                        <label for="nav-check">
                            <span></span>
                            <span></span>
                            <span></span>
                        </label>
                    </div>

                    <div className="nav-links">
                        <a onClick={this.change1}>Hello1</a>
                        <a onClick={this.change2}>Hello2</a>
                        <a onClick={this.change3}>Hello3</a>
                    </div>
                </div>
                <div id="test"></div>
                {/* <li className="streamer" onClick={() => this.test(1)}>streamer2</li> */}
            </div>
        )
    }


}


export default Navbar 
