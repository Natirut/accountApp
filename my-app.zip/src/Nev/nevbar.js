import React from 'react';
import ReactDOM from 'react-dom'
import App1 from '../Page/hello1'
import App2 from '../Page/hello2'
import App3 from '../Page/hello3'
import BarChart from '../charts/barChart/index.component';
class RootNavbar extends React.Component {
  render() {
    return (
      <div>
        <div className="nav">
          <input type="checkbox" id="nav-check" />
          <div className="nav-header">
            <div className="nav-title">
              Project
                      </div>
          </div>
          <div className="nav-btn">
            <label for="nav-check">
              <span></span>
              <span></span>
              <span></span>
            </label>
          </div>

          <div className="nav-links">
            <a onClick={this.change1}>Hello1</a>
            <a onClick={this.change2}>Hello2</a>
            <a onClick={this.change3}>Hello3</a> 
          </div>
        </div>
        <div id="test"></div>
        {/* <li className="streamer" onClick={() => this.test(1)}>streamer2</li> */}
      </div>
    )
  }

  // test(x){ 
  //   console.log(x)
  // }
  
  change1(){
    ReactDOM.render(<App1 />, document.getElementById('test'));
  }
  
  change2(){
    ReactDOM.render(<App2 />, document.getElementById('test'));
  }
  
  change3(){
    ReactDOM.render(<App2 />, document.getElementById('test'));
  }
    // render() {
    //   return <h1>Hello, {this.props.name}</h1>;
    // }
  
}


export default RootNavbar // export ตัว Component App เพื่อเอาไปใช้ที่ไฟล์อื่น
