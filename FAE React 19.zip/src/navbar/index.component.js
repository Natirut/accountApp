/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import './style.css';
import FormControl from '@material-ui/core/FormControl';
import { InputLabel } from '@material-ui/core';
import Select from '@material-ui/core/Select';
import ReactDom from 'react-dom';
import QRScanner from '../pages/components/qrcodeReader/index.component';
import Atp from '../App'
import PageSelecter from '../pages/index.component';
import MenuItem from '@material-ui/core/MenuItem';

import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import LinearScaleIcon from '@material-ui/icons/LinearScale';

import Register from '../pages/Register/index.component';

import { Provider } from 'react-redux';
import store from '../redux/store';

class NavBar extends React.Component {
  constructor() {
    super();

    this.state = {
      openScanner: false,
      cssTab3: {},
      show: false,
      tax_invoice: null,
      fae_menu: null,
      itc_menu: null,
      sub_menu: null,
      sub_menuRequester: null,
      anchorEl: null,
      openRegister: false,
    }
    this.close = this.close.bind(this);
    this.openScanner = this.openScanner.bind(this);
    this.summary = this.summary.bind(this);
    this.recyclegarbage = this.recyclegarbage.bind(this);
    // this.disposalWaste = this.disposalWaste.bind(this);
    this.home = this.home.bind(this);
    this.manage = this.manage.bind(this);
    this.login = this.login.bind(this);
    this.register = this.register.bind(this);
    this.logout = this.logout.bind(this);
    // this.Routefae = this.Routefae.bind(this);
    this.history = this.history.bind(this);
    this.showmenu = this.showmenu.bind(this);
    this.invoicePrepared = this.invoicePrepared.bind(this);
    this.optionClicked = this.optionClicked.bind(this);
    this.register = this.register.bind(this);
    this.requester = this.requester.bind(this);
  }
  login() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='login' />, document.getElementById('space'));
  }
  openScanner() {
    this.setState({ openScanner: true, anchorEl: null, })
  }
  faeCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='faeCheck' />, document.getElementById('space'));
  }
  faeApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='faeApprove' />, document.getElementById('space'));
  }
  itcCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='itcCheck' />, document.getElementById('space'));
  }
  itcApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='itcApprove' />, document.getElementById('space'));
  }

  register() {
    this.setState({ openRegister: true, anchorEl: null, })
  }

  async componentDidMount() {

    if (localStorage.getItem('dept').toLocaleLowerCase() === 'fae') {
      this.setState({
        tax_invoice:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }}>Invoice menu</InputLabel>
            <Select disableUnderline color="primary" >
              <MenuItem onClick={this.invoicePrepared} value="Invoice Prepared">Prepare</MenuItem>
              <MenuItem onClick={this.invoiceCheck} value="Invoice Checked">Check</MenuItem>
              <MenuItem onClick={this.invoiceApprove} value="Invoice Approve">Approve</MenuItem>
              <MenuItem value="Tax Invoice Making Approve" onClick={this.makingApproveInvoice} >Making Approve</MenuItem>
              <MenuItem onClick={this.invoicePDF} value="Invoice Approve">Demo Invoice PDF</MenuItem>
            </Select>
          </FormControl>
      })
      this.setState({
        fae_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >Waste menu</InputLabel>
            <Select disableUnderline color="primary" >
              <MenuItem onClick={this.recyclegarbage} value="Fae Prepared">Prepare</MenuItem>
              <MenuItem onClick={this.faeCheck} value="Fae Checked">Check</MenuItem>
              <MenuItem onClick={this.faeApprove} value="Fae Approve">Approve</MenuItem>
              <MenuItem onClick={this.history} value="History">History</MenuItem>
            </Select>
          </FormControl>
      })
    } else if (localStorage.getItem('dept') === 'IMO') {
      this.setState({
        fae_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >Menu</InputLabel>
            <Select disableUnderline color="primary" >
              {/* <MenuItem  onClick={this.requester}>Requester Input</MenuItem> */}
              <MenuItem onClick={this.requesterPrepare} value="req-prepare">Prepare</MenuItem>
              <MenuItem onClick={this.requesterCheck} value="req-check">Check</MenuItem>
              <MenuItem onClick={this.requesterApprove} value="req-approve">Approve</MenuItem>
              <MenuItem onClick={this.requesterHistory} value="req-approve">History</MenuItem>
              {/* <MenuItem onClick={this.requesterFormA}>FormA</MenuItem> */}
            </Select>
          </FormControl>
      })
    } else if (localStorage.getItem('dept') === 'itc') {
      // this.setState({
      //   fae_menu:
      //     <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
      //       <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >Requester</InputLabel>
      //       <Select disableUnderline color="primary" >
      //         <MenuItem onClick={this.requesterPrepare} value="req-prepare">Prepare</MenuItem>
      //         <MenuItem onClick={this.requesterCheck} value="req-check">Check</MenuItem>
      //         <MenuItem onClick={this.requesterApprove} value="req-approve">Approve</MenuItem>
      //       </Select>
      //     </FormControl>
      // })

      this.setState({
        itc_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >ITC verify</InputLabel>
            <Select disableUnderline color="primary" >

              <MenuItem onClick={this.itcCheck} value="itc-check">Check</MenuItem>
              <MenuItem onClick={this.itcApprove} value="itc-approve">Approve</MenuItem>

            </Select>
          </FormControl>
      })
    }
    else if (localStorage.getItem('dept') === 'ACC') {
      this.setState({
        fae_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >ACC</InputLabel>
            <Select disableUnderline color="primary" >
              <MenuItem onClick={this.AccPrepare}  value="req-prepare">ACC Prepare</MenuItem>
              <MenuItem onClick={this.AccCheck} value="req-check">ACC Check</MenuItem>
              <MenuItem onClick={this.AccApprove} value="req-approve">ACC Approve</MenuItem>
            </Select>
          </FormControl>
      })
    }

    else if (localStorage.getItem('dept') === 'PDC') {
      this.setState({
        fae_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >PDC</InputLabel>
            <Select disableUnderline color="primary" >
              {/* <MenuItem onClick={this.AccPrepare}  value="req-prepare">ACC Prepare</MenuItem> */}
              <MenuItem onClick={this.PdcCheck} value="req-check">PDC Check</MenuItem>
              <MenuItem onClick={this.PdcApprove} value="req-approve">PDC Approve</MenuItem>
            </Select>
          </FormControl>
      })
    }
    
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='home' />, document.getElementById('space'));
  }
  home() {
    this.setState({
      cssTab3: {},
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='home' />, document.getElementById('space'));
  }
  summary() {
    this.setState({
      cssTab3: { backgroundColor: '#dedef0', borderRadius: '10px' },
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='summary' />, document.getElementById('space'));
  }
  requester() {
    this.setState({
      cssTab3: {},
    })
    this.setState({
      cssTab4: { backgroundColor: '#dedef0', borderRadius: '10px' },
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requester' />, document.getElementById('space'));
  }
  requesterPrepare() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requesterprepare' />, document.getElementById('space'));
  }
  requesterCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requestercheck' />, document.getElementById('space'));
  }
  requesterApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requesterapprove' />, document.getElementById('space'));
  }
  requesterHistory() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requesterhistory' />, document.getElementById('space'));
  }
  requesterFormA() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requesterformA' />, document.getElementById('space'));
  }
  AccPrepare() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='accprepare' />, document.getElementById('space'));
  }
  AccCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='acccheck' />, document.getElementById('space'));
  }
  AccApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='accapprove' />, document.getElementById('space'));
  }
  PdcCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='pdccheck' />, document.getElementById('space'));
  }
  PdcApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='pdcapprove' />, document.getElementById('space'));
  }
  recyclegarbage() {
    this.setState({
      cssTab3: {},
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='recycle' />, document.getElementById('space'));
  }
  manage() {
    this.setState({
      cssTab3: {},
      anchorEl: null,
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='manage' />, document.getElementById('space'));
  }
  history() {
    this.setState({
      cssTab3: {},
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='history' />, document.getElementById('space'));
  }
  // Routefae() {
  //   this.setState({
  //     cssTab3: {},
  //   })
  //   ReactDom.unmountComponentAtNode(document.getElementById('space'))
  //   ReactDom.render(<PageSelecter page='routefae' />, document.getElementById('space'));
  // }
  invoicePrepared() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='invoiceprepared' />, document.getElementById('space'));
  }
  invoiceApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='invoiceapprove' />, document.getElementById('space'));
  }
  invoiceCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='invoicecheck' />, document.getElementById('space'));
  }
  invoicePDF() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='invoicepdf' />, document.getElementById('space'));
  }
  
  makingApproveInvoice() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='makingApprove' />, document.getElementById('space'));
  }

  close() {
    this.setState({ openScanner: false, openRegister: false, })
    this.setState({ anchorEl: null, })
  }
  showmenu() {
    this.setState({ show: true })
  }

  logout() {
    localStorage.clear();
    ReactDom.unmountComponentAtNode(document.getElementById('root'))
    ReactDom.render(<Atp />, document.getElementById('root'));
  }

  optionClicked(event) {
    this.setState({ anchorEl: event.currentTarget })
  }


  render() {
    let qrScanner;
    if (this.state.openScanner === true) {
      qrScanner = <QRScanner callBackClose={this.close} />
    }
    let register;
    if (this.state.openRegister === true) {
      register = <Register close={this.close} />
    }

    return (
      <>
        {register}
        <div className="nav">
          <input type="checkbox" id="nav-check" />
          <div className="nav-header">
            <div className="nav-title" onClick={this.home} style={this.state.cssHome}>
              <img src={`${process.env.REACT_APP_FILES_PATH}/icons/logo.png`} alt="logo"
                style={{ width: '47px', height: '44px', position: 'absolute', top: 'calc(20%)' }}
              />
            </div>
          </div>
          <div className="nav-btn">
            <label htmlFor="nav-check">
              <span></span>
              <span></span>
              <span></span>
            </label>
          </div>

          <div className="nav-links">
            {this.state.fae_menu}
            {this.state.itc_menu}
            {/* DONT DELETE */}
            {/* <a onClick={this.summary} style={this.state.cssTab3}>Summary Data</a> */}

            

            {(localStorage.getItem('dept').toLocaleLowerCase() === 'fae') ? this.state.tax_invoice : ''}
            {(localStorage.getItem('dept').toLocaleLowerCase() === 'fae') ? <>
              <Button onClick={this.optionClicked} style={{ position: 'absolute', right: 'calc(4%)', backgroundColor: '#006600', color: 'aliceblue' }}> Options </Button>
              <Menu
                id="simple-menu"
                anchorEl={this.state.anchorEl}
                keepMounted
                open={Boolean(this.state.anchorEl)}
                onClose={this.close}
              >
                <MenuItem onClick={this.manage}>Manage data</MenuItem>
                <MenuItem onClick={this.register}>Create user</MenuItem>
                <MenuItem onClick={this.openScanner}>Scaner QR</MenuItem>
                <MenuItem >
                  <LinearScaleIcon /><LinearScaleIcon /><LinearScaleIcon /><LinearScaleIcon />
                </MenuItem>
                <MenuItem onClick={this.logout} style={{ backgroundColor: '#660000', color: '#ffb3bf' }}>Logout</MenuItem>
              </Menu></>
              :
              <><Button onClick={this.optionClicked} style={{ position: 'absolute', right: 'calc(4%)', backgroundColor: '#006600', color: 'aliceblue' }}> Options </Button>
                <Menu
                  id="simple-menu"
                  anchorEl={this.state.anchorEl}
                  keepMounted
                  open={Boolean(this.state.anchorEl)}
                  onClose={this.close}
                >
                  <MenuItem onClick={this.logout} style={{ backgroundColor: '#660000', color: '#ffb3bf' }}>Logout</MenuItem>
                </Menu></>}

          </div>
        </div>
        <React.StrictMode>
          <Provider store={store}>
            {qrScanner}
            <div id="space"></div>
          </Provider>
        </React.StrictMode>
      </>
    )
  }
}

export default NavBar;
