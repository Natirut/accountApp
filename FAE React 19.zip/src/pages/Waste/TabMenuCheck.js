import React from 'react'
import Grid from '@material-ui/core/Grid';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import SwipeableViews from 'react-swipeable-views';
import Prepare from '../Waste/index.component';
import Check from '../setRoute/fae/check.component';
import CheckTab2 from '../setRoute/faetab2/checktab2';
class MenuCheck extends React.Component{
     constructor(props){
          super(props)
          this.state={
            index: 0,
          }
          this.handleChange = this.handleChange.bind(this)
          this.handleChangeIndex = this.handleChangeIndex.bind(this)
     }
     handleChange = async (event, value) => {
        console.log("valll", value)
        await this.setState({
            index: null,
        });
        this.setState({
            index: value,
        });
      //  this.ShowFormOne()
        // this.ShowFormOne()
    };

    handleChangeIndex = async index => {
        // console.log("index", index)
        await this.setState({
            index: null,
        });
        this.setState({
            index,
        });
   //     this.ShowFormOne()
    };
     componentDidMount(){

     }
     render(){
         return(
             <>
             <Grid container style={{ marginTop: 'calc(5%)' }}>
                <Grid container>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid>
                        <Tabs value={this.state.index} fullWidth onChange={this.handleChange} style={{ backgroundColor: '#fff' }}>
                            <Tab label="FAE CHECK" />
                            <Tab label="FAE CHECK REQUESTER" />
                        </Tabs>
                    </Grid>
                </Grid>

                <Grid container>
                    <Grid item xs={12} >

                        <SwipeableViews index={this.state.index} onChangeIndex={this.handleChangeIndex}>
                           <Check/>
                           <CheckTab2/>
                        </SwipeableViews>
                    </Grid>
                </Grid>
            </Grid>
             </>
         )
     }
}
export default MenuCheck




