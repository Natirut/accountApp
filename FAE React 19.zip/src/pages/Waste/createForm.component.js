import React from 'react';
import Autocomplete from '@material-ui/lab/Autocomplete';
import PhotoLibraryIcon from '@material-ui/icons/PhotoLibrary';
import FormControl from '@material-ui/core/FormControl';
import SaveIcon from '@material-ui/icons/Save';
import CancelIcon from '@material-ui/icons/Cancel';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import moment from 'moment';
import { CameraAlt, CloudUpload, Today } from '@material-ui/icons';
import { Grid, TextField, Select, MenuItem, InputLabel, ButtonGroup, IconButton } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import DatePicker from '../components/datepicker/index.component';
import DialogRe from './dialog_Recycle';
import DialogCar from './dialog_Car';
import DialogType from './dialog_typeWast';
import Axios from 'axios';
import Confirm from '../components/confirm/index.component';
import Camera from '../components/captureImages/captureImages.component';
// import SuccessBar from '../components/successBar/index.component';
import LoadBar from '../components/progress/index.component';
import SuccessBar from '../components/successBar/index.component'
import Badge from '@material-ui/core/Badge';
import DialogImage from './dialogViewImage';
import ImageSlice from './component/showimageSlice'
class Create extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            open: false,
            slide: null,
            pickerDate: false,
            pickedDate: '',
            open_DialogRe: false, //1,
            open_DialogCar: false, //1,
            open_DialogType: false, //1,
            open_DialogImage: false, //1,
            data_com: null,
            data_car: null,
            data_type: null,
            currenDate: new Date(),
            time: "",
            confirm: false,
            successShow: false,
            loadShow: false,
            id_delete: "",
            id_deleteCar: "",
            id_deleteType: "",
            boi: "",
            captureImage: false,
            filesSelected: null,
            cptType: "",
            generate: "",
            wasteGroup: "",
            wasteName: "",
            contractor: "",
            container: "",
            wastephase: "",
            netwasteWeight: "",
            totalWeight: "",
            containerWeight: "",
            imagedata: "",
            qtyof: "",
            dataImage: [],
            ima: [],
            showLish: "",
            datawastename: null,
            imageshow: false,

            allSheet: [],
            showdot: null,
            showbefordot: null,
            showafterdot: null,
            showitem_wastetype: null,
            showitem_boitype: null,
            datasetmaintype4: null,

            checkstep4: null,
            checkstep3: null,

            cptmaintype: null,
            wastetype: null,
            boitype: null,
            normaltype: null,
            biddingType: null,
            data_deptdiv: null,
            data_div: null,
            show_div: null,
            data_dept: null,
            product_type: null

        };
        this.handleClose = this.handleClose.bind(this);
        this.handleCancle = this.handleCancle.bind(this);
        this.onSelectedDate = this.onSelectedDate.bind(this);
        this.openDatePicker = this.openDatePicker.bind(this);
        this.submit = this.submit.bind(this)
        this.ShowAdd = this.ShowAdd.bind(this);//1
        this.close = this.close.bind(this);
        this.GetCompany = this.GetCompany.bind(this);
        this.GetCar = this.GetCar.bind(this);
        this.GetType = this.GetType.bind(this);

        this.getCurren = this.getCurren.bind(this);
        this.test = this.test.bind(this);
        this.ondelete = this.ondelete.bind(this);
        this.callBlack = this.callBlack.bind(this)
        this.ondelete = this.ondelete.bind(this);
        this.ondeleteCar = this.ondeleteCar.bind(this);
        this.ondeleteType = this.ondeleteType.bind(this);
        this.SetBoi = this.SetBoi.bind(this);
        this.SetCptType = this.SetCptType.bind(this);
        this.SetGenerate = this.SetGenerate.bind(this);
        this.SetWasteGroup = this.SetWasteGroup.bind(this);
        this.SetWasteName = this.SetWasteName.bind(this);
        this.SetContainer = this.SetContainer.bind(this);
        this.SetWastePhase = this.SetWastePhase.bind(this);
        this.SetTotalWaight = this.SetTotalWaight.bind(this);
        // this.SetContainerWaight = this.SetContainerWaight.bind(this);
        this.SetNetWeight = this.SetNetWeight.bind(this);

        this.openCamera = this.openCamera.bind(this);
        this.onFileSelect = this.onFileSelect.bind(this);
        this.SetQtyof = this.SetQtyof.bind(this);
        this.ViewImage = this.ViewImage.bind(this)
        this.Setready = this.Setready.bind(this);
        this.Setima = this.Setima.bind(this);
        this.GetWasteName = this.GetWasteName.bind(this);
        this.testnow = this.testnow.bind(this);
        this.testmai = this.testmai.bind(this);
        this.Set_dot = this.Set_dot.bind(this);
        this.showmaintype = this.showmaintype.bind(this);
        this.showboitype = this.showboitype.bind(this);
        this.shownormaltype = this.shownormaltype.bind(this);
        this.Set_biddingType = this.Set_biddingType.bind(this);
        this.getDept = this.getDept.bind(this);
        this.SetDept = this.SetDept.bind(this);
        this.SetProductType = this.SetProductType.bind(this);
        this.Setcptmaintype = this.Setcptmaintype.bind(this);
        this.SetWasteType = this.SetWasteType.bind(this);
        this.SetNormalType = this.SetNormalType.bind(this);
        this.SetBoiType = this.SetBoiType.bind(this);

    }
    async SetBoiType(e) {
        await this.setState({ boitype: e.target.value })
        await this.showmaintype()
        await this.showboitype()
        await this.shownormaltype()
    }
    async SetNormalType(e) {
        await this.setState({ normaltype: e.target.value })
        await this.showmaintype()
        await this.showboitype()
        await this.shownormaltype()
    }
    async SetWasteType(e) {
        await this.setState({ wastetype: e.target.value })
        await this.showmaintype()
        await this.showboitype()
        await this.shownormaltype()
    }
    async Setcptmaintype(e) {
        await this.setState({ cptmaintype: e.target.value })
        await this.showmaintype()
        // await this.showboitype()
        await this.shownormaltype()
    }
    async SetProductType(e) {
        await this.setState({ product_type: e.target.value })
    }
    async SetDept(e, data) {
        if (data !== null) {
            // console.log("data",data.depT_ABB_NAME)
            await this.setState({ data_div: data.diV_NAME_WC })
            this.setState({ data_dept: data.depT_ABB_NAME })
            this.setState({
                show_div:
                    <TextField id="div" style={{ width: '190px' }} label="Div" variant="outlined" value={this.state.data_div} />
            })
        }
        // console.log("data", data.diV_NAME_WC)

        // await this.setState({ data_div: this.state.data_dept.find(x => x.depT_ABB_NAME === data.diV_NAME_WC) })

    }
    async getDept() {
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/service/dept`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(async res => {
                    console.log("data", res.data.data)
                    await this.setState({ data_deptdiv: res.data.data })
                })


        } catch (err) {
            console.log(err.response)
        }
    }
    async Set_biddingType(e) {
        await this.setState({ biddingType: e.target.value })
    }
    showmaintype() {
        if (this.state.cptmaintype === "Part") {
            this.setState({
                showitem_wastetype:
                    <FormControl variant="outlined" >
                        <InputLabel id="d">Waste Type</InputLabel>
                        <Select
                            labelId="t"
                            id="test2"
                            style={{ width: '190px' }}
                            onChange={this.SetWasteType}
                            label="Waste Type"
                        >
                            <MenuItem value="Normal">Normal</MenuItem>
                            <MenuItem value="Company Approval">Company Approval</MenuItem>
                        </Select>
                    </FormControl>
            })
        }
        else if (this.state.cptmaintype === "Asset") {
            this.setState({
                showitem_wastetype:
                    <FormControl variant="outlined" >
                        <InputLabel id="d">Waste Type</InputLabel>
                        <Select
                            labelId="t"
                            id="test2"
                            style={{ width: '190px' }}
                            onChange={this.SetWasteType}
                            label="Waste Type"
                        >
                            <MenuItem value="Fixed">Fixed</MenuItem>
                            <MenuItem value="Non-Fixed">Non-Fixed</MenuItem>
                        </Select>
                    </FormControl>
            })
        } else if (this.state.cptmaintype === "Other") {
            this.setState({
                showitem_wastetype:
                    <FormControl variant="outlined" >
                        <InputLabel id="d">Waste Type</InputLabel>
                        <Select
                            labelId="t"
                            id="test2"
                            style={{ width: '190px' }}
                            onChange={this.SetWasteType}
                            label="Waste Type"
                        >
                            <MenuItem value="Valuable">Valuable</MenuItem>
                            <MenuItem value="Cost">Cost</MenuItem>
                        </Select>
                    </FormControl>
            })
        }
    }
    async showboitype() {
        await this.setState({
            showitem_boitype:
                <FormControl variant="outlined" >
                    <InputLabel id="d">BOI Type</InputLabel>
                    <Select
                        labelId="t"
                        id="test2"
                        style={{ width: '173px' }}
                        onChange={this.SetBoiType}
                        label="BOI Type"
                    >
                        <MenuItem value="BOI">BOI</MenuItem>
                        <MenuItem value="Non-BOI">Non-BOI</MenuItem>



                    </Select>
                </FormControl>
        })
    }
    async shownormaltype() {
        if (this.state.cptmaintype === 'Part' && this.state.wastetype === 'Normal' && this.state.boitype === 'Non-BOI') {
            await this.setState({
                showitem_normaltype:
                    <FormControl variant="outlined" >
                        <InputLabel id="d">Parts Normal Type</InputLabel>
                        <Select
                            labelId="t"
                            id="test2"
                            style={{ width: '170px' }}
                            onChange={this.SetNormalType}
                            label="Parts Normal Type"
                        >
                            <MenuItem value="Extra Work">Extra Work</MenuItem>
                            <MenuItem value="Mass Production Trial">Mass Production Trial</MenuItem>
                            <MenuItem value="Mass Production">Mass Production</MenuItem>
                        </Select>
                    </FormControl>
            })
        }else{
            await this.setState({
                showitem_normaltype:null
            })
        }

    }


    Set_dot() {
        this.setState({
            showbefordot: <>
                <IconButton color="info" onClick={this.testnow} style={{ position: 'absolute', marginLeft: 'calc(12%)' }} >
                    <Badge color="secondary" variant="dot" >
                        <PhotoLibraryIcon />
                    </Badge>
                </IconButton>
            </>
        })

        this.setState({
            showafterdot: <>
                <IconButton color="info" onClick={this.testnow} style={{ position: 'absolute', marginLeft: 'calc(12%)' }} >
                    <PhotoLibraryIcon />
                </IconButton>
            </>
        })

        this.setState({
            showdot: <>
                <IconButton color="info" onClick={this.testnow} style={{ position: 'absolute', marginLeft: 'calc(12%)' }} >
                    <PhotoLibraryIcon />
                </IconButton>
            </>
        })
    }
    async testmai() {
        await this.setState({ allSheet: [] })
        let excell, powerr, wordd, pdff, nott;
        excell = 0;
        powerr = 0;
        wordd = 0;
        pdff = 0;
        nott = 0;
        console.log("len", this.state.filesSelected.length)
        for (let i = 0; i < this.state.filesSelected.length; i++) {
            if (this.state.filesSelected[i].type === "image/jpeg" || this.state.filesSelected[i].type === "image/png") {

            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
                powerr = powerr + 1
            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
                excell = excell + 1
            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                wordd = wordd + 1
            }
            else if (this.state.filesSelected[i].type === "application/pdf") {
                pdff = pdff + 1
            }
            else {
                nott = nott + 1
            }
        }

        this.state.allSheet.push(
            powerr, excell, wordd, pdff, nott
        )
        console.log("all", this.state.allSheet)
    }
    async testnow() {
        this.setState({ open_DialogImage: true, });
    }
    async ViewImage() {
        await this.Setready()
        this.Setima()
    }

    Setready() {
        let file;
        for (let i = 0; i < this.state.filesSelected.length; i++) {
            let reader = new FileReader();
            file = this.state.filesSelected[i];

            reader.onload = (file) => {

                this.state.dataImage.push(reader.result)
            }
            reader.readAsDataURL(file)
        }

    }
    async Setima() {
        console.log("imaa", this.state.ima)
        await this.setState({ ima: this.state.dataImage })
        await this.setState({ imageshow: true })
    }

    async SetQtyof(e) {
        await this.setState({ qtyof: e.target.value })
        console.log(this.state.qtyof)
    }
    async SetBoi(e) {
        await this.setState({ boi: e.target.value })
        console.log(this.state.boi)
    }
    async SetCptType(e) {
        await this.setState({ cptType: e.target.value })
        console.log(this.state.cptType)
    }
    async SetGenerate(e) {
        await this.setState({ generate: e.target.value })
        console.log(this.state.generate)
    }
    async SetWasteName(e) {
        await this.setState({ wasteName: e.target.value })
        console.log(this.state.wasteName)
    }
    async SetWasteGroup(e) {
        await this.setState({ wasteGroup: e.target.value })
        console.log(this.state.wasteGroup)
    }
    async SetContainer(e) {
        await this.setState({ container: e.target.value })
        console.log(this.state.container)
    }
    async SetWastePhase(e) {
        await this.setState({ wastephase: e.target.value })
        console.log(this.state.wastephase)
    }
    async onFileSelect(e) {
        if (e.target.files.length > 0) {
            this.setState({ showdot: this.state.showbefordot })
        } else {
            this.setState({ showdot: this.state.showafterdot })
        }
        console.log(e.target.files.length)
        await this.setState({ filesSelected: e.target.files })
        // await this.setState({ ima: URL.createObjectURL(e.target.files[0]) })
        let tmp = []
        let file;
        for (let i = 0; i < this.state.filesSelected.length; i++) {
            if (this.state.filesSelected[i].type === "image/jpeg" || this.state.filesSelected[i].type === "image/png") {
                let reader = new FileReader();
                file = this.state.filesSelected[i];

                reader.onload = (file) => {

                    tmp.push(reader.result)
                }
                reader.readAsDataURL(file)

            }

        }
        this.setState({ ima: tmp })



        await this.setState({ allSheet: [] })
        let excell, powerr, wordd, pdff, nott;
        excell = 0;
        powerr = 0;
        wordd = 0;
        pdff = 0;
        nott = 0;
        console.log("len", this.state.filesSelected.length)
        for (let i = 0; i < this.state.filesSelected.length; i++) {
            if (this.state.filesSelected[i].type === "image/jpeg" || this.state.filesSelected[i].type === "image/png") {

            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
                powerr = powerr + 1
            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
                excell = excell + 1
            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                wordd = wordd + 1
            }
            else if (this.state.filesSelected[i].type === "application/pdf") {
                pdff = pdff + 1
            }
            else {
                nott = nott + 1
            }
        }

        this.state.allSheet.push(
            powerr, excell, wordd, pdff, nott
        )
        console.log("all", this.state.allSheet)
        this.setState({ open_DialogImage: null, });
        //  this.setState({ open_DialogImage: true, });
        //  console.log(this.state.ima)
        //  this.setState({ imageshow: true })

    }
    close(image) {
        console.log("close")
        if (image) {
            console.log("IMAGE: ", image)
            this.setState({ imagedata: image })

        }
        this.setState({ open_DialogRe: false, });
        this.setState({ open_DialogCar: false, });
        this.setState({ open_DialogType: false, });
        this.setState({ open_DialogImage: false, });
        this.setState({ captureImage: false, })
    }
    openCamera() {
        this.setState({ captureImage: true })
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.close();
    }

    handleCancle() {
        this.setState({ open: false, })
        this.props.cancle();
    }

    openDatePicker() {
        this.setState({ pickerDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ pickedDate: date.selectedDate })
        }
        this.setState({ pickerDate: false, })
    }
    async SetTotalWaight(event) {
        await this.setState({
            totalWeight: event.target.value
        })
        if (this.state.containerWeight === "" && this.state.totalWeight === "") {
            this.setState({
                netwasteWeight: ""
            })
        }
        else if (this.state.containerWeight !== "" && this.state.totalWeight !== "") {
            this.setState({
                netwasteWeight: (parseFloat(this.state.totalWeight) - parseFloat(this.state.containerWeight)).toFixed(3).toString()
            })
        }
        else if (this.state.containerWeight === "") {
            this.setState({
                netwasteWeight: (parseFloat(this.state.totalWeight)).toFixed(3).toString()
            })
        }
        else if (this.state.totalWeight === "") {
            this.setState({
                netwasteWeight: ""
            })
        }
        //  console.log("connnnn",this.state.containerWeight)

        // console.log(this.state.totalWeight)

    }

    async SetNetWeight(event) {
        await this.setState({
            containerWeight: event.target.value
        })

        if (this.state.containerWeight === "" && this.state.totalWeight === "") {
            this.setState({
                netwasteWeight: ""
            })
        }
        else if (this.state.containerWeight !== "" && this.state.totalWeight !== "") {
            this.setState({
                netwasteWeight: (parseFloat(this.state.totalWeight) - parseFloat(this.state.containerWeight)).toFixed(3).toString()
            })
        }
        else if (this.state.containerWeight === "") {
            this.setState({
                netwasteWeight: (parseFloat(this.state.totalWeight)).toFixed(3).toString()
            })
        }
        else if (this.state.totalWeight === "") {
            this.setState({
                netwasteWeight: ""
            })
        }

    }
    async submit() {
        console.log("Noeeee", this.state.wastetype)
        try {

            //  console.log(document.getElementById('qtyof').value)
            // console.log(this.state.wastephase)
            //  console.log(this.state.qtyof)
            // console.log(this.state.cptType)
            // console.log(document.getElementById('lotNo').value)
            // console.log(document.getElementById('companyApprove').value)
            // console.log(this.state.generate)
            // console.log(this.state.wasteGroup)
            // console.log(document.getElementById('wasteName').value)
            // console.log(document.getElementById('totalWeight').value)
            // console.log(document.getElementById('containerWeight').value)
            // console.log( this.state.container)
            console.log(this.state.data_dept)
            console.log(this.state.data_div)


            let formData = new FormData();

            formData.append('date', document.getElementById('date').value);
            formData.append('time', document.getElementById('time').value);
            formData.append('phase', this.state.wastephase);
            // formData.append('typeBoi', this.state.boi);
            formData.append('cptMainType', this.state.cptmaintype);
            formData.append('wasteType', this.state.wastetype);
            formData.append('boiType', this.state.boitype);
            formData.append('partNormalType', this.state.normaltype);
            // formData.append('cptType', this.state.cptType);
            formData.append('department', this.state.data_dept);
            formData.append('division', this.state.data_div);
            formData.append('lotNo', document.getElementById('lotNo').value);
            formData.append('biddingType', this.state.biddingType);
            formData.append('companyApprove', document.getElementById('companyApprove').value);
            formData.append('contractorCompany', this.state.contractor);
            formData.append('productionType', this.state.product_type);
            // formData.append('gennerateGroup', this.state.generate);
            formData.append('wasteGroup', this.state.wasteGroup);
            formData.append('wasteName', this.state.wasteName);
            formData.append('totalWeight', this.state.totalWeight);
            formData.append('containerWeight', this.state.containerWeight);
            formData.append('qtyOfContainer', document.getElementById('qtyof').value);
            formData.append('containerType', this.state.container);
            formData.append('netWasteWeight', this.state.netwasteWeight);
            // formData.append('wasteContractor', this.state.contractor);

            for (const item of this.state.imagedata) {
                formData.append('imageCapture', item);
            }

            // formData.append('files', '');

            for (const item of this.state.filesSelected) {
                formData.append('files', item);
            }

            // for (var value of formData.values()) {
            //     console.log("test",value);
            //  }

            console.log()

            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'multipart/form-data', accept: 'text/plain',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const response = await instance.post(`/fae-part/waste`, formData);

            console.log(response)
            this.setState({ loadShow: true });
            setTimeout(() => {
                this.setState({ successShow: true });
            }, 1000);
            setTimeout(() => {
                this.handleClose()
            }, 1200);
            // await this.handleClose()
        } catch (err) {
            console.log(err.stack)
        }
    }
    async ShowAdd(e) {//1
        console.log(e.target.value);
        await this.setState({ contractor: e.target.value })
        console.log(this.state.contractor)
        if (e.target.value === 70) {
            await this.setState({ open_DialogRe: true })
            console.log("Ready Add")
        }
    }
    async componentDidMount() {
        // this.setState({showbutton: <AddCircleIcon fontSize="large" style={{ color: green[500] }} / >})
        await this.getDept()
        this.GetCompany()
        this.GetWasteName()
        this.Set_dot()
        // this.GetCar()
        // this.GetType()

        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });

        this.setState({ open: true, })

        if (this.props.data) {
            console.log('Data for edit');
        }
    }
    GetWasteName() {
        //  let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteName`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({
                        datawastename: res.data.data.map((item) => (
                            <MenuItem value={item.wasteName}>{item.wasteName} </MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    ondelete(id) {
        // alert(id)
        this.setState({ confirm: true, })
        this.setState({ id_delete: id, })
    }
    ondeleteCar(id) {
        this.setState({ confirm: true, })
        this.setState({ id_deleteCar: id, })
    }
    ondeleteType(id) {
        this.setState({ confirm: true, })
        this.setState({ id_deleteType: id, })
    }
    GetCompany() {
        let url = "http://cptsvs531/api-fae-part/fae-part/company"
        // let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({
                        data_com: res.data.data.map((item) => (
                            <MenuItem value={item.companyName}>{item.companyName} </MenuItem>
                        ))
                    });
                    // console.log(res.data)

                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    GetCar() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/car"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/car`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({
                        data_car: res.data.data.map((item) => (
                            <MenuItem value={item.carType}><CancelIcon style={{ paddingRight: '4%' }} color="secondary" onClick={() => this.ondeleteCar(item._id)} />{item.carType}</MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    GetType() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/wasteType"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteType`
        try {
            Axios.get(url)
                .then(res => {
                    this.setState({
                        data_type: res.data.data.map((item) => (
                            <MenuItem value={item.typeName}><CancelIcon style={{ paddingRight: '4%' }} color="secondary" onClick={() => this.ondeleteType(item._id)} />{item.typeName}</MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    uploadFileOnlocal() {
        document.getElementById('file').click();
    }
    getCurren() {
        let datee
        let timee
        datee = moment(this.state.currenDate).format('YYYY/MM/DD')
        timee = moment(this.state.currenDate).format('HH:mm')
        this.setState({ pickedDate: datee })
        this.setState({ time: timee })
        console.log(datee)
        console.log(timee)

    }
    test(e) {
        console.log(e.target.value)
        this.setState({ time: e.target.value })
    }

    truedelete() {
        // let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company/"+id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company/${this.state.id_delete}`
        try {
            Axios.delete(url)
                .then(res => {
                    console.log(res.data)
                    this.GetCompany()
                })
        } catch (err) {
            console.log(err.response)
        }
    }
    truedeleteCar() {
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/car/${this.state.id_deleteCar}`
        try {
            Axios.delete(url)
                .then(res => {
                    console.log(res.data)
                    this.GetCar()
                })
        } catch (err) {
            console.log(err.response)
        }
    }
    truedeleteType() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/wasteType/"+id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteType/${this.state.id_deleteType}`
        try {
            Axios.delete(url)
                .then(res => {
                    console.log(res.data)
                    this.GetType()
                })
        } catch (err) {
            console.log(err.response)
        }
    }
    callBlack(x) {
        this.setState({ confirm: false, })
        if (x === true) {
            this.truedelete()
            this.truedeleteCar()
            this.truedeleteType()
        }
    }

    render() {
        let datepicker;
        if (this.state.pickerDate === true) {
            datepicker = <DatePicker callBackClose={this.onSelectedDate} />
        }
        let Dialog_re;//1
        if (this.state.open_DialogRe === true) {
            Dialog_re = <DialogRe close={this.close} get={this.GetCompany} />
        }
        let Dialog_car;//1
        if (this.state.open_DialogCar === true) {
            Dialog_car = <DialogCar close={this.close} get={this.GetCar} />
        }
        let Dialog_type;//1
        if (this.state.open_DialogType === true) {
            Dialog_type = <DialogType close={this.close} get={this.GetType} />
        }
        let confirm;

        if (this.state.confirm === true) {
            confirm = <Confirm content={{ header: 'Confirm deleting', description: 'Delete this row from selection form.' }} confirmed={this.callBlack} />
        }

        let camera;
        if (this.state.captureImage === true) {
            camera = <Camera close={this.close} />
        }
        let success;
        if (this.state.successShow === true) {
            success = <SuccessBar />
        }
        let load;
        if (this.state.loadShow === true) {
            load = <LoadBar />
        }
        let dialog_image;//1
        if (this.state.open_DialogImage === true) {
            dialog_image = <DialogImage close={this.close} data={this.state.ima} sheet={this.state.allSheet} />
        }
        let showimage;
        if (this.state.imageshow === true) {
            showimage = <ImageSlice data={this.state.ima} />
        }
        return (
            <>

                {confirm}{camera}{Dialog_re}{Dialog_car}{Dialog_type}{datepicker}{dialog_image}
                <Dialog fullScreen open={this.state.open} onClose={this.handleCancle} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: ' #d3ffd3', color: '#424874' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleCancle}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Create Waste</Typography>
                        </Toolbar>
                    </AppBar>
                    {success}{load}
                    <Grid container style={{ marginTop: 'calc(4%)' }}>
                        {/* first row */}

                        <Grid container   >
                            <Grid item xs={1}>

                            </Grid>
                            <Grid item xs={3}>
                                <TextField id="date" style={{ width: '190px' }} label="Move Out Date" variant="outlined" value={this.state.pickedDate} onClick={this.openDatePicker} />
                            </Grid>

                            <Grid item xs={3}>
                                <TextField onChange={this.test} style={{ width: '180px' }} id="time" type="time" label="Move Out Time" variant="outlined" value={this.state.time} />
                                <Today onClick={this.getCurren} style={{ color: '#00b300', position: 'absolute' }} />
                            </Grid>
                            <Grid item xs={2}>
                                <FormControl variant="outlined" >
                                    <InputLabel id="demo-simple-select-outlined-label">Waste of Phase</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="phase"
                                        style={{ width: '170px' }}
                                        onChange={this.SetWastePhase}
                                        label="Waste of Phase"
                                    >
                                        <MenuItem value=""><em>None</em></MenuItem>
                                        <MenuItem value="Phase 1">Phase 1</MenuItem>
                                        <MenuItem value="Phase 2">Phase 2</MenuItem>
                                        <MenuItem value="Phase 3">Phase 3</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={2} style={{ marginLeft: '30px' }} >
                                <Autocomplete
                                    id="combo-box-demo"
                                    options={this.state.data_deptdiv}
                                    getOptionLabel={(option) => option.depT_ABB_NAME}
                                    style={{ width: 170 }}
                                    onChange={(event, newValue) => {
                                        this.SetDept(event, newValue)
                                    }}
                                    renderInput={(params) => <TextField {...params} label="Dept" variant="outlined" />}
                                />
                            </Grid>
                        </Grid>

                        <Grid container spacing={0} style={{ marginTop: 'calc(3%)' }}>
                            <Grid item xs={1}>

                            </Grid>
                            <Grid item xs={2}>
                                {this.state.show_div}
                            </Grid>

                        </Grid>
                        {/* secon Row */}
                        <Grid container spacing={0} style={{ marginTop: 'calc(3%)' }}>
                            <Grid container>
                                <Grid item xs={1}></Grid>
                                <Grid item xs={3}>
                                    {/* <TextField label="Waste Name" style={{ width: '180px' }} variant="outlined" id="wasteName" /> */}
                                    <FormControl variant="outlined" >
                                        <InputLabel id="wasteName">Waste Name</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteName"
                                            style={{ width: '190px' }}
                                            onChange={this.SetWasteName}
                                            label="Waste Name"
                                        >
                                            {this.state.datawastename}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={3} >
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Waste Group</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteGroup"
                                            style={{ width: '190px' }}
                                            onChange={this.SetWasteGroup}
                                            label="Waste Group"
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="General Waste">General Waste</MenuItem>
                                            <MenuItem value="Recycle Waste">Recycle Waste</MenuItem>
                                            <MenuItem value="Hazardous Waste">Hazardous Waste</MenuItem>
                                            <MenuItem value="Infectious Waste">Infectious Waste</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>

                                <Grid item xs={2}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Contractor Company</InputLabel>
                                        <Select
                                            labelId="disposalCompany"
                                            id="wasteContractor"
                                            style={{ width: '173px' }}
                                            onChange={this.ShowAdd}
                                            label="Contractor Company"
                                        >
                                            <MenuItem value="" >
                                                <em >None</em>
                                            </MenuItem>
                                            {this.state.data_com}
                                            {/* <MenuItem value={70}><div style={{ marginLeft: '45%' }}>
                                        <AddCircleIcon fontSize="large" style={{ color: green[500] }} />
                                    </div></MenuItem> */}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                <Grid item xs={2} style={{ marginLeft: '30px' }}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="demo-simple-select-outlined-label">Bidding Type</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="Bidding Type"
                                            style={{ width: '170px' }}
                                            onChange={this.Set_biddingType}
                                            label="BOI/Non-BOI"
                                        >
                                            <MenuItem value="-">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="Test1">Test1</MenuItem>
                                            <MenuItem value="Test2">Test2</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>

                            </Grid>

                        </Grid>


                        {/* 3 row */}
                        <Grid container spacing={0} style={{ marginTop: 'calc(3%)' }}>
                            <Grid item xs={1}></Grid>
                            <Grid item xs={3}>
                                <FormControl variant="outlined" >
                                    <InputLabel id="gennerate-group">CPT Main Type</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="test"
                                        style={{ width: '190px' }}
                                        onChange={this.Setcptmaintype}
                                        label="CPT Main Type"
                                    >
                                        <MenuItem value="Part">Part</MenuItem>
                                        <MenuItem value="Asset">Asset</MenuItem>
                                        <MenuItem value="Other">Other</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={3}>
                                {this.state.showitem_wastetype}
                            </Grid>
                            <Grid item xs={2}>
                                {this.state.showitem_boitype}
                            </Grid>
                            <Grid item xs={2} style={{ marginLeft: '30px' }}>
                                {this.state.showitem_normaltype}
                            </Grid>
                        </Grid>

                        {/* 4 row */}
                        <Grid container style={{ marginTop: 'calc(3%)' }}>
                            <Grid item xs={1}>

                            </Grid>
                            {/* <Grid item xs={3}> */}
                            {/* <FormControl variant="outlined" >
                                    <InputLabel id="demo-simple-select-outlined-label">CPT Type</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="cptType"
                                        style={{ width: '190px' }}
                                        onChange={this.SetCptType}
                                        label="CPT Type"
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value="Fixed Asset">Fixed Asset</MenuItem>
                                        <MenuItem value="Non Fixed Asset">Non Fixed Asset</MenuItem>
                                        <MenuItem value="Company Approval">Company Approval</MenuItem>
                                        <MenuItem value="Parts">Parts</MenuItem>
                                        <MenuItem value="PMD">PMD</MenuItem>
                                        <MenuItem value="IMO">IMO</MenuItem>
                                        <MenuItem value="MSC">MCS</MenuItem>
                                        <MenuItem value="-">Other (Please Specific)</MenuItem>
                                    </Select>
                                </FormControl> */}
                            {/* </Grid> */}
                            <Grid item xs={3} >
                                {/* <TextField label="Production Type." style={{ width: '190px' }} variant="outlined" id="Product" /> */}
                                <FormControl variant="outlined" >
                                    <InputLabel id="demo-simple-select-outlined-label">Production Type</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="productType"
                                        style={{ width: '190px' }}
                                        onChange={this.SetProductType}
                                        label="Production Type"
                                    >
                                        <MenuItem value="Production">Production</MenuItem>
                                        <MenuItem value="Non-Production">Non-Production</MenuItem>
                                        <MenuItem value="Other">Other</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={3} >
                                <TextField label="Lot No." style={{ width: '190px' }} variant="outlined" id="lotNo" />
                            </Grid>
                            <Grid item xs={2} >
                                <TextField label="Company Approval No." style={{ width: '173px' }} variant="outlined" id="companyApprove" />
                            </Grid>
                            <Grid item xs={2} style={{ marginLeft: '30px' }}>
                                {/* <FormControl variant="outlined" >
                                    <InputLabel id="demo-simple-select-outlined-label">Generate Group</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="gennerateGroup"
                                        style={{ width: '170px' }}
                                        onChange={this.SetGenerate}
                                        label="Generate Group"
                                    >

                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value="Production">Production</MenuItem>
                                        <MenuItem value="Non-Production">Non-Production</MenuItem>
                                        <MenuItem value="-">Other (Please Specific)</MenuItem>
                                    </Select>
                                </FormControl> */}
                                <TextField style={{ width: '170px' }} onChange={this.SetTotalWaight} label="Total Weight" variant="outlined" />
                            </Grid>

                        </Grid>





                        {/* 5th Row */}
                        <Grid container spacing={0} style={{ marginTop: 'calc(3%)' }}>
                            <Grid item xs={1}></Grid>

                            <Grid item xs={3}>
                                <TextField style={{ width: '190px' }} onChange={this.SetNetWeight} label="Container Weight" variant="outlined" id="containerWeight" />

                            </Grid>
                            <Grid item xs={3}>
                                <TextField style={{ width: '190px' }} onChange={this.SetQtyof} variant="outlined" label="Qty Of Container" id="qtyof" value={this.state.qtyof} />
                            </Grid>


                            <Grid item xs={2} >
                                <FormControl variant="outlined" >
                                    <InputLabel id="gennerate-group">Container Type</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="containerType"
                                        style={{ width: '173px' }}
                                        onChange={this.SetContainer}
                                        label="Container Type"
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value="ถุง Big Bag">ถุง Big Bag</MenuItem>
                                        <MenuItem value="ถังเหล็ก">ถังเหล็ก</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={2} style={{ marginLeft: '30px' }}>
                                <TextField style={{ width: '170px' }} value={this.state.netwasteWeight} disabled="true" label="Net Waste Weight" variant="outlined" id="netWasteWeight" />
                            </Grid>

                        </Grid>



                        {/* 5th row */}
                        <Grid container spacing={0} style={{ marginTop: 'calc(2%)' }}>
                            <Grid item xs={1}></Grid>

                            <Grid item xs={2}>
                                {/* <IconButton color="primary" onClick={this.ViewImage}>
                                    <PhotoLibraryIcon />
                                </IconButton> */}
                                {/* <button onClick={this.testmai}>

                                </button> */}

                                {/* <IconButton color="info" onClick={this.testnow}>
                                 <Badge color="secondary" variant="dot" >
                                    <PhotoLibraryIcon />
                                    </Badge>
                                </IconButton>
                                <IconButton color="info" onClick={this.testnow}>
                                    <PhotoLibraryIcon />
                                </IconButton> */}
                                {/* {this.state.showdot} */}
                            </Grid>
                            <Grid item xs={6}></Grid>
                            <Grid item xs={2} style={{ marginLeft: '30px' }}>
                                {this.state.showdot}
                                <ButtonGroup style={{ padding: '15px' }} size="small" color="primary" aria-label="outlined secondary button group">
                                    <Button >
                                        <IconButton color="primary" aria-label="upload picture" component="span" onClick={this.openCamera}>
                                            <CameraAlt style={{ color: '#b300b3' }} />
                                        </IconButton>
                                    </Button>
                                    <Button onClick={this.uploadFileOnlocal}>
                                        <input accept=".png,.jpg" id="file" type="file" onChange={this.onFileSelect} multiple hidden />
                                        <IconButton color="primary" component="span">
                                            <CloudUpload style={{ color: '#3c00b3' }} />
                                        </IconButton>
                                    </Button>
                                </ButtonGroup>
                            </Grid>
                        </Grid>
                        <Grid container style={{ textAlign: 'center' }}>
                            <Grid item xs={12} style={{ marginTop: 'calc(2%)' }}>
                                {/* <center> */}
                                <Button variant="contained" startIcon={<SaveIcon />} color="primary" onClick={this.submit}>Save</Button>
                                <Button variant="contained" startIcon={<CancelIcon />} color="secondary" onClick={this.handleCancle} style={{ marginLeft: '10px' }}>cancel</Button>
                                {/* </center> */}
                            </Grid>
                        </Grid>
                        <Grid container style={{ marginTop: '10px' }}>
                            {/* {this.state.ima}
                        <img src={this.state.ima[0]}  /> */}
                            <Grid item xs={1}></Grid>
                            <Grid item xs={10}>
                                {showimage}
                            </Grid>
                            <Grid item xs={1}></Grid>


                        </Grid>
                    </Grid>
                </Dialog>
            </>
        );
    }
}

export default Create;