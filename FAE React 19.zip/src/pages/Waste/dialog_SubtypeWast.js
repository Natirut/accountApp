import React from 'react';
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import Button from '@material-ui/core/Button';
import Axios from 'axios'
import Grid from '@material-ui/core/Grid';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';

class Subwaste extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            subname: null,
            open: false,
            slide: null,
            data_type: [],
            Id: ""
        }
        this.handleClose = this.handleClose.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.GetType = this.GetType.bind(this);
        this.SetId = this.SetId.bind(this);
        this.insertSub = this.insertSub.bind(this);


    }
    SetId(e) {
        console.log(e.target.value);
        this.setState({ Id: e.target.value })
    }
    GetType() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/wasteType"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteType`
        try {
            Axios.get(url)
                .then(res => {
                    this.setState({
                        data_type: res.data.data.map((item) => (
                            <MenuItem value={item._id}>{item.typeName}</MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    componentDidMount() {
        this.GetType()
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
    }
    handleChange(event) {
        this.setState({
            subname: event.target.value
        });
    }
    handleClose() {
        this.props.close();

    }
    async insertSub() {
        const sub = {
            typeName: this.state.subname,
            mainType: this.state.Id
        };
        // console.log(company)
        // let url = process.env.REACT_APP_ENDPOINT + "/fae-part/SubWasteType"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/SubWasteType`
        // console.log(this.state.name)
        try {
            Axios.post(url, sub)
                .then(async res => {
                    console.log(res.data)
                    await this.handleClose();
                    await this.props.get();
                })
        } catch (err) {
            console.log(err.stack)
        }
    }
    render() {
        return (
            <>
                <Dialog open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#BEEACB', color: '#005F7E' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleClose}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Add Sub Wast</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>
                        <Grid container>
                            <Grid item xs={6}>
                                <TextField
                                    autoFocus
                                    margin="dense"
                                    id="name"
                                    label="Sub group"
                                    type="text"
                                    fullWidth
                                    value={this.state.subname}
                                    onChange={this.handleChange}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <FormControl style={{ marginLeft: '20px', paddingTop: '5px' }}>
                                    <InputLabel id="demo-simple-select-helper-label" style={{ width: '150px', paddingTop: '5px' }}>Type of wast</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-helper-label"
                                        id="demo-simple-select-helper"
                                        style={{ width: '150px' }}
                                        onChange={this.SetId}
                                    //   value={age}
                                    //   onChange={handleChange}
                                    >

                                        {this.state.data_type}
                                    </Select>
                                </FormControl>
                            </Grid>
                        </Grid>

                        <Button variant="contained" color="secondary" onClick={this.insertSub}>
                            ADD
                        </Button>
                    </DialogContent>



                </Dialog>
            </>
        )
    }
}
export default Subwaste