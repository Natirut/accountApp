import React from 'react'
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
class ShowImageSlice extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
        console.log("data ima",this.props.data)
    }
    componentDidMount() {

    }
    render() {
        return (
            <>
                <div
                    style={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        justifyContent: 'space-around',
                        overflow: 'hidden',
                        // backgroundColor: 'skyblue'
                    }}
                >
                    <GridList cellHeight={180} style={{
                        width:500,
                        height:450
                    }} >
                        {this.props.data.map((item) => (
                            <GridListTile key={item}  >
                                <center>
                                    <img src={item} alt="test" style={{ width: '200px', height: '200px' }} />

                                </center>

                                <GridListTileBar
                                    style={{
                                        background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)'
                                    }}
                                // title={tile.title}
                                // classes={{
                                //     root: classes.titleBar,
                                //     title: classes.title,
                                // }}
                                />
                            </GridListTile>
                        ))}
                    </GridList>
                </div>

              
            </>
        )
    }
}
export default ShowImageSlice

