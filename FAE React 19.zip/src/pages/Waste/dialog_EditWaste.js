import React from 'react';
import moment from 'moment';
import Axios from 'axios';
import PhotoLibraryIcon from '@material-ui/icons/PhotoLibrary';
import Badge from '@material-ui/core/Badge';
import Autocomplete from '@material-ui/lab/Autocomplete';
import FormControl from '@material-ui/core/FormControl';
import { CameraAlt, CloudUpload, Today } from '@material-ui/icons';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import TextField from '@material-ui/core/TextField';
import { Grid, Select, MenuItem, InputLabel, ButtonGroup, IconButton } from '@material-ui/core';
import DatePicker from '../components/datepicker/index.component'
import Camera from '../components/captureImages/captureImages.component'
import DialogImage from './dialogViewImage'
class EditWaste extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            //dataWaste:[],
            captureImage: false,
            data_com: null,
            pickerDate: false,
            filesSelected: null,
            imagedata: "",


            status_file: false,
            id_update: "",
            date_update: "",
            time_update: "",
            phase_update: "",
            dept_update: "",
            div_update: "",
            wastename_update: "",
            wastegroup_update: "",
            contractor_company_update: "",
            biddingtype_update: "",
            cptmaintype_update: "",
            wastetype_update: "",
            boi_update: "",
            partsnomal_update: "",
            producttype_update: "",
            lotno_update: "",
            companyno_update: "",
            totalweight_update: "",
            containerweight_update: "",
            qty_update: "",
            containertype_update: "",
            netwaste_update: "",

            files_update: "",
            status_update: "",

            data_deptdiv: null,

            datatruedept: null,
            datawastename: null,
            showbefordot: null,
            showafterdot: null,
            showdot: null,
            allSheet: [],
            ima: [],
            open_DialogImage: false,

            showitem_wastetype: null,
            showitem_parttype: null,

            rowdatalist: null
        }
        this.onFileSelect = this.onFileSelect.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.SetBoi = this.SetBoi.bind(this);
        this.GetCompany = this.GetCompany.bind(this);
        this.openDatePicker = this.openDatePicker.bind(this);
        this.onSelectedDate = this.onSelectedDate.bind(this);
        this.SetCptType = this.SetCptType.bind(this);
        this.SetLotno = this.SetLotno.bind(this);
        this.SetComno = this.SetComno.bind(this);
        this.SetGenerate = this.SetGenerate.bind(this);
        this.SetWasteGroup = this.SetWasteGroup.bind(this);
        this.SetWasteName = this.SetWasteName.bind(this);
        this.SetTotalWaight = this.SetTotalWaight.bind(this);
        this.SetConWeight = this.SetConWeight.bind(this);
        this.SetContractor = this.SetContractor.bind(this);
        this.SetContainertype = this.SetContainertype.bind(this);
        this.SetPhase = this.SetPhase.bind(this);
        this.getCurren = this.getCurren.bind(this);
        this.SetTime = this.SetTime.bind(this);
        this.openCamera = this.openCamera.bind(this);
        this.close = this.close.bind(this);
        this.submit = this.submit.bind(this);
        this.getDept = this.getDept.bind(this);
        this.TrueDept = this.TrueDept.bind(this);
        this.GetWasteName = this.GetWasteName.bind(this);
        this.SetBinding = this.SetBinding.bind(this);
        this.SetWasteType = this.SetWasteType.bind(this);
        this.SetPartsType = this.SetPartsType.bind(this);
        this.SetProduct = this.SetProduct.bind(this);
        this.SetQty = this.SetQty.bind(this);
        this.Set_dot = this.Set_dot.bind(this);
        this.openimage = this.openimage.bind(this);
        this.setProps = this.setProps.bind(this);
        this.setMenuitem = this.setMenuitem.bind(this);
        this.setrow = this.setrow.bind(this);
        console.log('PSROPS EDIT: ', props)
    }


    openimage() {
        this.setState({ open_DialogImage: true, });
    }
    Set_dot() {
        this.setState({
            showbefordot: <>
                <IconButton color="info" onClick={this.openimage} style={{ position: 'absolute', marginLeft: 'calc(12%)' }} >
                    <Badge color="secondary" variant="dot" >
                        <PhotoLibraryIcon />
                    </Badge>
                </IconButton>
            </>
        })

        this.setState({
            showafterdot: <>
                <IconButton color="info" onClick={this.openimage} style={{ position: 'absolute', marginLeft: 'calc(12%)' }} >
                    <PhotoLibraryIcon />
                </IconButton>
            </>
        })

        this.setState({
            showdot: <>
                <IconButton color="info" onClick={this.openimage} style={{ position: 'absolute', marginLeft: 'calc(12%)' }} >
                    <PhotoLibraryIcon />
                </IconButton>
            </>
        })
    }

    async SetDept(e, data) {
        if (data !== null) {
            await this.setState({ dept_update: data })
            const div = this.state.data_deptdiv.find(x => x.depT_ABB_NAME === data)
            this.setState({ div_update: div.diV_NAME_WC })
        }
    }

    GetWasteName() {
        //  let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteName`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({
                        datawastename: res.data.data.map((item) => (
                            <MenuItem value={item.wasteName}>{item.wasteName} </MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    async getDept() {
        try {
            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/service/dept`);
            this.setState({ data_deptdiv: response.data.data })
        } catch (err) {
            console.log(err.response)
        }
    }
    TrueDept() {
        let tmp = []
        for (const element of this.state.data_deptdiv) {
            tmp.push(element.depT_ABB_NAME)
        }
        // for(let i = 0;i<=this.state.data_deptdiv.length;i++){
        //      if(i<=this.state.data_deptdiv.length){
        //           console.log("tmp",this.state.data_deptdiv[i].depT_ABB_NAME)
        //      }
        // tmp.push(this.state.data_deptdiv[i].depT_ABB_NAME)

        // }  
        this.setState({ datatruedept: tmp })
    }

    openCamera() {
        this.setState({ captureImage: true })
    }
    async onFileSelect(e) {
        if (e.target.files.length > 0) {
            this.setState({ showdot: this.state.showbefordot })
        } else {
            this.setState({ showdot: this.state.showafterdot })
        }
        await this.setState({ filesSelected: e.target.files })
        let tmp = []
        let file;
        for (let i = 0; i < this.state.filesSelected.length; i++) {
            if (this.state.filesSelected[i].type === "image/jpeg" || this.state.filesSelected[i].type === "image/png") {
                let reader = new FileReader();
                file = this.state.filesSelected[i];

                reader.onload = (file) => {

                    tmp.push(reader.result)
                }
                reader.readAsDataURL(file)

            }

        }
        this.setState({ ima: tmp })



        await this.setState({ allSheet: [] })
        let excell, powerr, wordd, pdff, nott;
        excell = 0;
        powerr = 0;
        wordd = 0;
        pdff = 0;
        nott = 0;
        console.log("len", this.state.filesSelected.length)
        for (let i = 0; i < this.state.filesSelected.length; i++) {
            if (this.state.filesSelected[i].type === "image/jpeg" || this.state.filesSelected[i].type === "image/png") {

            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
                powerr = powerr + 1
            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
                excell = excell + 1
            }
            else if (this.state.filesSelected[i].type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                wordd = wordd + 1
            }
            else if (this.state.filesSelected[i].type === "application/pdf") {
                pdff = pdff + 1
            }
            else {
                nott = nott + 1
            }
        }

        this.state.allSheet.push(
            powerr, excell, wordd, pdff, nott
        )
        console.log("all", this.state.allSheet)
        // console.log(this.state.filesSelected)
    }
    async SetBoi(e) {
        await this.setState({ boi_update: e.target.value })
        console.log(this.state.boi_update)
        await this.setMenuitem()
        await this.SetmenunormalType()
    }
    async SetPartsType(e) {
        await this.setState({ partsnomal_update: e.target.value })
        await this.setMenuitem()
        await this.SetmenunormalType()
    }

    async SetCptType(e) {
        await this.setState({ cptmaintype_update: e.target.value })
        console.log("test")
        await this.setMenuitem()
        await this.SetmenunormalType()
    }
    async SetLotno(e) {
        await this.setState({ lotno_update: e.target.value })
        console.log(this.state.lotno_update)
    }
    async SetComno(e) {
        await this.setState({ companyno_update: e.target.value })
    }
    async SetGenerate(e) {
        await this.setState({ generate_update: e.target.value })
    }
    async SetWasteGroup(e) {
        await this.setState({ wastegroup_update: e.target.value })
    }
    async SetWasteName(e) {
        await this.setState({ wastename_update: e.target.value })
    }
    async SetContractor(e) {
        await this.setState({ contractor_update: e.target.value })
    }
    async SetContainertype(e) {
        await this.setState({ containertype_update: e.target.value })
    }
    async SetPhase(e) {
        await this.setState({ phase_update: e.target.value })
    }
    async SetBinding(e) {
        await this.setState({ biddingtype_update: e.target.value })
    }
    async SetTime(e) {
        console.log(e.target.value)
        this.setState({ time_update: e.target.value })
    }
    async SetWasteType(e) {
       await this.setState({ wastetype_update: e.target.value })
       await this.setMenuitem()
       await this.SetmenunormalType()

    }
    async SetProduct(e) {
        this.setState({ producttype_update: e.target.value })
    }
    async SetQty(e) {
        this.setState({ qty_update: e.target.value })
    }


    async SetTotalWaight(event) {
        await this.setState({
            totalweight_update: event.target.value
        })
        if (this.state.containerweight_update === "" && this.state.totalweight_update === "") {
            this.setState({
                netwaste_update: ""
            })
        }
        else if (this.state.containerweight_update !== "" && this.state.totalweight_update !== "") {
            this.setState({
                netwaste_update: (parseFloat(this.state.totalweight_update) - parseFloat(this.state.containerweight_update)).toFixed(3).toString()
            })
        }
        else if (this.state.containerweight_update === "") {
            this.setState({
                netwaste_update: (parseFloat(this.state.totalweight_update)).toFixed(3).toString()
            })
        }
        else if (this.state.totalweight_update === "") {
            this.setState({
                netwaste_update: ""
            })
        }
    }

    async SetConWeight(event) {
        await this.setState({
            containerweight_update: event.target.value
        })

        if (this.state.containerweight_update === "" && this.state.totalweight_update === "") {
            this.setState({
                netwaste_update: ""
            })
        }
        else if (this.state.containerweight_update !== "" && this.state.totalweight_update !== "") {
            this.setState({
                netwaste_update: (parseFloat(this.state.totalweight_update) - parseFloat(this.state.containerweight_update)).toFixed(3).toString()
            })
        }
        else if (this.state.containerweight_update === "") {
            this.setState({
                netwaste_update: (parseFloat(this.state.totalweight_update)).toFixed(3).toString()
            })
        }
        else if (this.state.totalweight_update === "") {
            this.setState({
                netwaste_update: ""
            })
        }
    }
    handleClose() {
        this.props.cancle();
    }
    handleCancle() {
        this.props.cancle();
    }
    async submit() {

        try {
            let formData = new FormData();

            formData.append('date', document.getElementById('date').value);
            formData.append('time', document.getElementById('time').value);
            formData.append('phase', this.state.phase_update);
            formData.append('cptMainType', this.state.cptmaintype_update);
            formData.append('wasteType', this.state.wastetype_update);
            formData.append('boiType', this.state.boi_update);
            formData.append('partNormalType', this.state.partsnomal_update);
            formData.append('department', this.state.dept_update);
            formData.append('division', this.state.div_update);
            formData.append('lotNo', document.getElementById('lotNo').value);
            formData.append('biddingType', this.state.biddingtype_update);
            formData.append('companyApprove', document.getElementById('companyApprove').value);
            formData.append('contractorCompany', this.state.contractor_company_update);
            formData.append('productionType', this.state.producttype_update);
            formData.append('wasteGroup', this.state.wastegroup_update);
            formData.append('wasteName', this.state.wastename_update);
            formData.append('totalWeight', this.state.totalweight_update);
            formData.append('containerWeight', this.state.containerweight_update);
            formData.append('qtyOfContainer', this.state.qty_update);
            formData.append('containerType', this.state.containertype_update);
            formData.append('netWasteWeight', this.state.netwaste_update);
            formData.append('wasteContractor', this.state.contractor_update);
            formData.append('status', this.state.status_update);

            // if(this.state.imagedata!=="" && this.state.filesSelected!==null){
            //     for (const item of this.state.imagedata) {
            //         formData.append('imageCapture', item);
            //    }
            //    for (const item of this.state.filesSelected) {
            //        formData.append('files', item);
            //    }      
            //  }

            if (this.state.imagedata !== "") {
                for (const item of this.state.imagedata) {
                    formData.append('imageCapture', item);
                }
            }

            else if (this.state.filesSelected !== null) {
                for (const item of this.state.filesSelected) {
                    formData.append('files', item);
                }
            } else {
                for (const item of this.state.files_update) {
                    formData.append('imageCapture', item);
                }

            }


            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'multipart/form-data', accept: 'text/plain',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const response = await instance.put(`/fae-part/waste/${this.state.id_update}`, formData);

            console.log(response)
            this.props.close()

        } catch (err) {
            console.log(err.stack)
        }
    }
    async setProps() {
        await this.setState({
            id_update: this.props.data._id,
            date_update: this.props.data.date,
            time_update: this.props.data.time,
            phase_update: this.props.data.phase,
            dept_update: this.props.data.department,
            div_update: this.props.data.division,
            wastename_update: this.props.data.wasteName,
            wastegroup_update: this.props.data.wasteGroup,
            contractor_company_update: this.props.data.contractorCompany,
            biddingtype_update: this.props.data.biddingType,
            cptmaintype_update: this.props.data.cptMainType,
            wastetype_update: this.props.data.wasteType,
            boi_update: this.props.data.boiType,
            partsnomal_update: this.props.data.partNormalType,
            producttype_update: this.props.data.productionType,
            lotno_update: this.props.data.lotNo,
            companyno_update: this.props.data.companyApprove,
            totalweight_update: this.props.data.totalWeight,
            containerweight_update: this.props.data.containerWeight,
            qty_update: this.props.data.qtyOfContainer,
            containertype_update: this.props.data.containerType,
            netwaste_update: this.props.data.netWasteWeight,


            files_update: this.props.data.files,
            status_update: this.props.data.status
        })
        console.log("fileUp", this.state.files_update)
    }
    async setrow() {
        await this.setState({
            rowdatalist:
                <>
                    <MenuItem value="">
                        <em>None</em>
                    </MenuItem>
                    <MenuItem value="Normal">Normal</MenuItem>
                    <MenuItem value="Company Approval">Company Approval</MenuItem>
                    <MenuItem value="Fixed">Fixed</MenuItem>
                    <MenuItem value="Non-Fixed">Non-Fixed</MenuItem>
                    <MenuItem value="Valiable">Valiable</MenuItem>
                    <MenuItem value="Cost">Cost</MenuItem>
                </>
        })
    }

    async setMenuitem() {
        if (this.state.cptmaintype_update=== 'Part') {
            await this.setState({
                showitem_wastetype:
                    <>
                        <FormControl variant="outlined" >
                            <InputLabel id="gennerate-group">Waste Type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="cptmaintype"
                                style={{ width: '180px' }}
                                value={this.state.wastetype_update}
                                label=">Waste Type"
                                onChange={this.SetWasteType}
                            >

                                <MenuItem value="Normal">Normal</MenuItem>
                                <MenuItem value="Company Approval">Company Approval</MenuItem>
                                {/* 
                            <MenuItem value="Fixed">Fixed</MenuItem>
                            <MenuItem value="Non-Fixed">Non-Fixed</MenuItem>
                            <MenuItem value="Valiable">Valiable</MenuItem>
                            <MenuItem value="Cost">Cost</MenuItem> */}
                                {/* {this.state.rowdatalist} */}
                            </Select>
                        </FormControl>
                    </>
            })
        } else if(this.state.cptmaintype_update === 'Asset'){
            await this.setState({
                showitem_wastetype:
                    <>
                        <FormControl variant="outlined" >
                            <InputLabel id="gennerate-group">Waste Type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="cptmaintype"
                                style={{ width: '180px' }}
                                value={this.state.wastetype_update}
                                label=">Waste Type"
                                onChange={this.SetWasteType}
                            >
                            <MenuItem value="Fixed">Fixed</MenuItem>
                            <MenuItem value="Non-Fixed">Non-Fixed</MenuItem>
                            </Select>
                        </FormControl>
                    </>
            })
        }else if(this.state.cptmaintype_update === 'Other'){
            await this.setState({
                showitem_wastetype:
                    <>
                        <FormControl variant="outlined" >
                            <InputLabel id="gennerate-group">Waste Type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="cptmaintype"
                                style={{ width: '180px' }}
                                value={this.state.wastetype_update}
                                label=">Waste Type"
                                onChange={this.SetWasteType}
                            >
                            <MenuItem value="Valiable">Valiable</MenuItem>
                            <MenuItem value="Cost">Cost</MenuItem> 
                            </Select>
                        </FormControl>
                    </>
            }) 
        }

    }
   async SetmenunormalType(){
        if(this.state.cptmaintype_update === 'Part' && this.state.wastetype_update === 'Normal' && this.state.boi_update === 'Non-BOI'){
          await  this.setState({showitem_parttype:
                <FormControl variant="outlined" >
                <InputLabel id="gennerate-group">Parts Normal Type</InputLabel>
                <Select
                    labelId="demo-simple-select-outlined-label"
                    id="boitype"
                    style={{ width: '180px' }}
                    value={this.state.partsnomal_update}
                    label=">Parts Normal Type"
                    onChange={this.SetPartsType}
                >
                    <MenuItem value="Extra Work">Extra Work</MenuItem>
                    <MenuItem value="Mass Production Trial">Mass Production Trial</MenuItem>
                    <MenuItem value="Mass Production">Mass Production</MenuItem>
                </Select>
            </FormControl>
                 
            })
        }
        else{
            await  this.setState({showitem_parttype:null})
        }
    }
    async componentDidMount() {
        await this.setProps()
        // await this.setrow()
        await this.setMenuitem()
        await this.SetmenunormalType()
        await this.GetWasteName()
        await this.getDept()
        await this.TrueDept()
        await this.GetCompany()
        this.Set_dot()

        //await this.setState({dataWaste:this.props.data})
        // console.log("test", this.props.data.files)

        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
    }
    openDatePicker() {
        this.setState({ pickerDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ date_update: date.selectedDate })
        }
        this.setState({ pickerDate: false, })
    }
    getCurren() {
        let datee
        let timee
        datee = moment(this.state.currenDate).format('YYYY/MM/DD')
        timee = moment(this.state.currenDate).format('HH:mm')
        this.setState({ date_update: datee })
        this.setState({ time_update: timee })
        console.log(datee)
        console.log(timee)

    }
    uploadFileOnlocal() {
        document.getElementById('file').click();
    }
    GetCompany() {
        //  let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({
                        data_com: res.data.data.map((item) => (
                            <MenuItem value={item.companyName}>{item.companyName} </MenuItem>
                        ))
                    });
                    console.log(res.data)

                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    close(image) {
        console.log("dataImage", image)
        if (image) {
            console.log("IMAGE: ", image)
            this.setState({ imagedata: image })

        }
        this.setState({ open_DialogImage: false, })
        this.setState({ captureImage: false, })
    }
    render() {
        let dialog_image;//1
        if (this.state.open_DialogImage === true) {
            dialog_image = <DialogImage close={this.close} data={this.state.ima} sheet={this.state.allSheet} />
        }
        let datepicker;
        if (this.state.pickerDate === true) {
            datepicker = <DatePicker callBackClose={this.onSelectedDate} />
        }
        let camera;
        if (this.state.captureImage === true) {
            camera = <Camera close={this.close} />
        }
        return (
            <>
                <div>{datepicker}{camera}{dialog_image}
                    <Dialog
                        fullWidth="true"
                        maxWidth="lg"
                        open={this.state.open}
                        TransitionComponent={this.state.slide}
                        onClose={this.handleClose}
                        style={{ overflow: 'hidden' }}
                    >
                        <DialogTitle >Edit Waste</DialogTitle>
                        <DialogContent  >
                            {/* <Grid item xs={12}   > */}
                            {/* row1 */}
                            <Grid container    >
                                <Grid item xs={3}>
                                    <TextField id="date" style={{ width: '180px' }} label="Move Out Date" variant="outlined" value={this.state.date_update} onClick={this.openDatePicker} />
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField onChange={this.SetTime} value={this.state.time_update} style={{ width: '180px' }} id="time" type="time" label="Move Out Time" variant="outlined" />
                                    <Today onClick={this.getCurren} style={{ color: '#00b300', position: 'absolute' }} />
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Waste of Phase</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteGroup"
                                            style={{ width: '180px' }}
                                            value={this.state.phase_update}
                                            onChange={this.SetPhase}
                                            label="Waste of Phase"
                                        >
                                            <MenuItem value=""><em>None</em></MenuItem>
                                            <MenuItem value="Phase 1">Phase 1</MenuItem>
                                            <MenuItem value="Phase 2">Phase 2</MenuItem>
                                            <MenuItem value="Phase 3">Phase 3</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={3}>
                                    <Autocomplete
                                        id="combo-box-demo"
                                        options={this.state.datatruedept}
                                        defaultValue={this.state.dept_update}
                                        getOptionLabel={(option) => option}
                                        style={{ width: 170 }}
                                        onChange={(event, newValue) => {
                                            this.SetDept(event, newValue)
                                        }}
                                        renderInput={(params) => <TextField {...params} label="Dept" defaultValue={this.state.dept_update} variant="outlined" />}
                                    />
                                </Grid>
                            </Grid>

                            {/* row2 */}
                            <Grid container style={{ paddingTop: 'calc(3%)' }} >
                                <Grid item xs={3}>
                                    <TextField value={this.state.div_update} style={{ width: '180px' }} label="Div" variant="outlined" />
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Waste Name</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteGroup"
                                            style={{ width: '180px' }}
                                            onChange={this.SetWasteName}
                                            value={this.state.wastename_update}
                                            label="Waste Name"
                                        >
                                            {this.state.datawastename}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Waste Group</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteGroup"
                                            style={{ width: '180px' }}
                                            value={this.state.wastegroup_update}
                                            onChange={this.SetWasteGroup}
                                            label="Waste Group"
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="General Waste">General Waste</MenuItem>
                                            <MenuItem value="Recycle Waste">Recycle Waste</MenuItem>
                                            <MenuItem value="Hazardous Waste">Hazardous Waste</MenuItem>
                                            <MenuItem value="Infectious Waste">Infectious Waste</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Contractor Company</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteGroup"
                                            style={{ width: '180px' }}
                                            value={this.state.contractor_company_update}
                                            onChange={this.SetContractor}
                                            label="Contractor Company"
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            {this.state.data_com}
                                        </Select>
                                    </FormControl>
                                </Grid>
                            </Grid>

                            {/* third Row */}
                            <Grid container style={{ paddingTop: 'calc(3%)' }} >
                                <Grid item xs={3} >
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Bidding Type</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="wasteGroup"
                                            style={{ width: '180px' }}
                                            value={this.state.biddingtype_update}
                                            onChange={this.SetBinding}
                                            label="Bidding Type"
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="Test1">Test1</MenuItem>
                                            <MenuItem value="Test2">Test2</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>

                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">CPT Main Type</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="cptmaintype"
                                            style={{ width: '180px' }}
                                            value={this.state.cptmaintype_update}
                                            label=">CPT Main Type"
                                            onChange={this.SetCptType}
                                        >
                                            {/* {this.state.datasetmaintype} */}
                                            <MenuItem value="Part">Part</MenuItem>
                                            <MenuItem value="Asset">Asset</MenuItem>
                                            <MenuItem value="Other">Other</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={3}>
                                    {this.state.showitem_wastetype}
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">BOI Type</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="boitype"
                                            style={{ width: '180px' }}
                                            value={this.state.boi_update}
                                            label="BOI Type"
                                            onChange={this.SetBoi}
                                        >
                                            <MenuItem value="BOI">BOI</MenuItem>
                                            <MenuItem value="Non-BOI">Non-BOI</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                            </Grid>

                            {/* 4th Row */}
                            <Grid container style={{ paddingTop: 'calc(3%)' }}>
                                <Grid item xs={3}>
                                  {this.state.showitem_parttype}
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Production Type</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="boitype"
                                            style={{ width: '180px' }}
                                            value={this.state.producttype_update}
                                            label="Production Type"
                                            onChange={this.SetProduct}
                                        >
                                            <MenuItem value="Production">Production</MenuItem>
                                            <MenuItem value="Non-Production">Non-Production</MenuItem>
                                            <MenuItem value="Other">Other</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={3} >
                                    <TextField style={{ width: '180px' }} onChange={this.SetLotno} value={this.state.lotno_update} label="Lot No." variant="outlined" id="lotNo" />
                                </Grid>
                                <Grid item xs={3} >
                                    <TextField style={{ width: '180px' }} onChange={this.SetComno} value={this.state.companyno_update} label="Company Approval No." variant="outlined" id="companyApprove" />
                                </Grid>
                            </Grid>

                            {/* 5th row */}
                            <Grid container style={{ paddingTop: 'calc(3%)' }}>
                                <Grid item xs={3}>
                                    <TextField style={{ width: '180px' }} onChange={this.SetTotalWaight} value={this.state.totalweight_update} label="Total Weight" id="totalWeight" variant="outlined" />
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField style={{ width: '180px' }} onChange={this.SetConWeight} value={this.state.containerweight_update} label="Container Weight" variant="outlined" id="containerWeight" />
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField style={{ width: '180px' }} onChange={this.SetQty} value={this.state.qty_update} label="Qty Of Container" variant="outlined" id="containerWeight" />
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl variant="outlined" >
                                        <InputLabel id="gennerate-group">Container Type</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-outlined-label"
                                            id="boitype"
                                            style={{ width: '180px' }}
                                            value={this.state.containertype_update}
                                            label="Production Type"
                                            onChange={this.SetContainertype}
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="ถุง Big Bag">ถุง Big Bag</MenuItem>
                                            <MenuItem value="ถังเหล็ก">ถังเหล็ก</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>


                            </Grid>

                            {/* six */}
                            <Grid container style={{ paddingTop: 'calc(3%)' }}>
                                <Grid item xs={3}>
                                    <TextField value={this.state.netwaste_update} disabled="true" label="Net Waste Weight" variant="outlined" id="netWasteWeight" />
                                </Grid>
                                <Grid item xs={6}>

                                </Grid>
                                <Grid item xs={2}>
                                    {this.state.showdot}
                                    <ButtonGroup style={{ padding: '15px' }} size="small" color="primary" aria-label="outlined secondary button group">
                                        <Button onClick={this.openCamera}>
                                            <IconButton color="primary" aria-label="upload picture" component="span" >
                                                <CameraAlt style={{ color: '#b300b3' }} />
                                            </IconButton>
                                        </Button>
                                        <Button onClick={this.uploadFileOnlocal} >
                                            <input accept=".png,.jpg" id="file" type="file" onChange={this.onFileSelect} multiple hidden />
                                            <IconButton color="primary" component="span">
                                                <CloudUpload style={{ color: '#3c00b3' }} />
                                            </IconButton>
                                        </Button>
                                    </ButtonGroup>
                                </Grid>
                            </Grid>

                            {/* </Grid> */}
                        </DialogContent>
                        <DialogActions>
                            {/* <Button onClick={this.handleClose} color="primary">Disagree</Button> */}
                            <Button onClick={this.submit} color="primary">UPDATE</Button>
                        </DialogActions>
                    </Dialog>
                </div>
            </>
        )
    }
}

export default EditWaste