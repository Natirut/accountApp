
import React from 'react';
import Grid from '@material-ui/core/Grid';

import Setroute from '../setRoute/index.component';
import { Paper, Card, CardContent, CardActions, Button, Tooltip, Popover, Typography } from '@material-ui/core';

// import Catagrory from '../components/imageCategory/index.component';

class Home extends React.Component {
    constructor() {
        super();

        this.state = {
            popverEnviroment: false,
            popverRequester: false,
            popverItc: false,
            popverAcc: false,
            anchorEl: null,
            testUrl: [
                `image.png`,
                `image.png`,
                `image.png`,
            ]
        }
        this.popverRequester = this.popverRequester.bind(this);
        this.popverEnviroment = this.popverEnviroment.bind(this);
        this.popverItc = this.popverItc.bind(this);
        this.popverAcc = this.popverAcc.bind(this);
        this.close = this.close.bind(this);
    }
    popverAcc(event) {
        this.setState({ popverAcc: true, anchorEl: event.currentTarget })
    }
    close() {
        this.setState({ popverAcc: false, popverEnviroment: false, popverRequester: false, popverItc: false, anchorEl: null, })
    }
    popverItc(event) {
        this.setState({ popverItc: true, anchorEl: event.currentTarget })
    }
    popverEnviroment(event) {
        this.setState({ popverEnviroment: true, anchorEl: event.currentTarget })
    }
    popverRequester(event) {
        this.setState({ popverRequester: true, anchorEl: event.currentTarget })
    }
    render() {
        let element;
        if (localStorage.getItem('dept') === 'FAE') {
            element = <>
                {/* <Catagrory images={this.state.testUrl} close={this.close} /> */}
                <Grid container spacing={0}
                    style={{
                        margin: 'calc(8%) 10px 20px 10px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                    <Grid item xs={5}>
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/enviroment.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #36b336',
                                                borderRadius: '10px', padding: '5px', margin: '5px', cursor: 'pointer'
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    <Tooltip title="Operations การดำเนินงานของหน่วยงานสิ่งแวดล้อม">
                                        <Button size="small" onClick={this.popverEnviroment} style={{ backgroundColor: '#bfeaff' }}>Learn More</Button>
                                    </Tooltip>
                                    <Popover
                                        open={this.state.popverEnviroment}
                                        onClose={this.close}
                                        anchorEl={this.state.anchorEl}
                                        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                    >
                                        <Typography style={{ padding: '10px' }}>Operations การดำเนินงานของหน่วยงานสิ่งแวดล้อม</Typography>
                                    </Popover>
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                    <Grid item xs={5}>
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/requester.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #ff99ff',
                                                borderRadius: '10px', padding: '5px', margin: '5px', cursor: 'pointer'
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    <Tooltip title="Requester Operations การดำเนินงานของผู้ร้องขอ">
                                        <Button size="small" onClick={this.popverRequester} style={{ backgroundColor: '#bfeaff' }}>Learn More</Button>
                                    </Tooltip>
                                    <Popover
                                        open={this.state.popverRequester}
                                        onClose={this.close}
                                        anchorEl={this.state.anchorEl}
                                        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                    >
                                        <Typography style={{ padding: '10px' }}>Requester Operations การดำเนินงานของผู้ร้องขอ</Typography>
                                    </Popover>
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                </Grid>

                <Grid container spacing={0}
                    style={{
                        margin: '0 10px 20px 10px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                    <Grid item xs={5}>
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/itc.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #ff6680',
                                                borderRadius: '10px', padding: '5px', margin: '5px', cursor: 'pointer'
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    <Tooltip title="ITC Department Operations การดำเนินงานของฝ่ายงาน ITC">
                                        <Button size="small" onClick={this.popverItc} style={{ backgroundColor: '#bfeaff' }}>Learn More</Button>
                                    </Tooltip>
                                    <Popover
                                        open={this.state.popverItc}
                                        onClose={this.close}
                                        anchorEl={this.state.anchorEl}
                                        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                    >
                                        <Typography style={{ padding: '10px' }}>ITC Department Operations การดำเนินงานของฝ่ายงาน ITC</Typography>
                                    </Popover>
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                    <Grid item xs={5} >
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/accountant.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #ceb5ff',
                                                borderRadius: '10px', padding: '5px', margin: '5px', cursor: 'pointer'
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    <Tooltip title="ACC Department Operations การดำเนินงานของฝ่ายงาน ACC">
                                        <Button size="small" onClick={this.popverAcc} style={{ backgroundColor: '#bfeaff' }}>Learn More</Button>
                                    </Tooltip>
                                    <Popover
                                        open={this.state.popverAcc}
                                        onClose={this.close}
                                        anchorEl={this.state.anchorEl}
                                        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                                    >
                                        <Typography style={{ padding: '10px' }}>ACC Department Operations การดำเนินงานของฝ่ายงาน ACC</Typography>
                                    </Popover>
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                </Grid>
            </>
        } else {
            element = <>

                <Setroute />

            </>
        }
        return element;
        // return <Verify />
    }
}

export default Home;
