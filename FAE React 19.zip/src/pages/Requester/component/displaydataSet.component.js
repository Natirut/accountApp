
import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import SwipeableViews from 'react-swipeable-views';
import DialogTitle from '@material-ui/core/DialogTitle';

import DataTable from '../../components/datatable/index.component';
import { Tabs, Paper, Grid, Slide } from '@material-ui/core';
import Tab from '@material-ui/core/Tab';
import axios from 'axios';


// PROPS CONTEXT
// tarckingId=abc
// status=aaa
// close=function
// PROPS CONTEXT

class DisplayDataset extends Component {
    constructor() {
        super();

        this.state = {
            index: 0,
            open: false,
            transition: null,
            // value:
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.rowData = this.rowData.bind(this);
    }

    componentDidMount() {
        this.setState({
            transition: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            }),
            open: true,
        });
    }


    async rowData() {
        try {
            // const body = { trackingId: this.props.trackingId, status: this.props.status };

            const body = { trackingId: this.props.trackingId, status: this.props.status };
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                }
            });
            const response = await instance.post(`/fae-part/requester/getByTracking`, body);
        } catch (err) {
            console.log(err.stack)
        }
    }
    handleClose() {

    }
    handleChange(event, newValue) {
        // console.log(event.target.value);
        this.setState({ index: newValue })
    };
    render() {
        return (
            <Dialog
                open={this.state.open}
                TransitionComponent={this.state.transition}
                keepMounted
                fullScreen
                onClose={this.handleClose}
                aria-labelledby="alert-dialog-slide-title"
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle style={{ backgroundColor: 'rgb(247 212 113)' }}>{"Requester data"}</DialogTitle>
                <DialogContent>

                    <Paper elevation={1} style={{ padding: '10px', backgroundColor: '#de609a85' }}>
                        <Tabs
                            value={this.state.index}
                            onChange={this.handleChange}
                            indicatorColor="primary"
                            textColor="primary"

                        >
                            <Tab label="Check CPT Type" />
                            <Tab label="Scrap Non-BOI" />
                            <Tab label="Scrap BOI" />

                            <Tab label="Scrap Matrial IMO" />
                            <Tab label="Scrap Matrila PMD" />
                            <Tab label="Summary BOI Weight" />
                            <Tab label="Disposal Letter" />
                        </Tabs>
                    </Paper>

                    <Grid container spacing={1} style={{ marginTop: 'calc(2%)' }}>
                        <Grid item xs={12}>
                            <SwipeableViews index={this.state.index}>
                                <><DataTable /></>
                                <>Scrap Non-BOI</>
                                <>Scrap BOI</>
                                <>Scrap Matrial IMO</>
                                <>Scrap Matrila PMD</>
                                <>Summary BOI Weight</>
                                <>Disposal Letter</>
                            </SwipeableViews>
                        </Grid>
                    </Grid>

                </DialogContent>
                <DialogActions >
                    <Button onClick={this.handleClose} color="primary" style={{ backgroundColor: 'rgb(234 42 42)', color: 'rgb(239 239 239)' }}>
                        Close
              </Button>
                </DialogActions>
            </Dialog >
        );
    }
}

export default DisplayDataset;