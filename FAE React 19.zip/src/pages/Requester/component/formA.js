import React from 'react'
import Grid from '@material-ui/core/Grid';
import './style.css'
import Typography from '@material-ui/core/Typography';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import DataTable from '../../components/datatable/index.component';
// PROPS CONTEXT
// cancle=    this.setState({ dialogDetail: false, })  
// data = [ { field: '', field: ''} ]
// PROPS CONTEXT

class FormA extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            test: null,
            slide: null,
            open: false,
            element:null,
            data:null,
            // tmp:null
        }
        this.settest = this.settest.bind(this)
        this.handleClose = this.handleClose.bind(this);
        this.rowData = this.rowData.bind(this);
        console.log("propss",this.props)
    }
    async rowData() {
        try {
            const column = [
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', },
                { field: 'date', title: <b>Date</b>, align: 'center', },
                { field: 'time', title: <b>Time</b>, align: 'center', },
                { field: 'status', title: <b>Status</b>, align: 'center', },
            ];
            const row = [];
            for (const item of this.props.data) {
                console.log("iiii",item)
                row.push(
                    {
                        lotNo: item.lotNo,
                        date: item.date,
                        time: item.time,
                        status: item.status, 
                    }
                )
            }
            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Waste on created." headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            // console.log(err.response.status)
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="Waste on created." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    handleClose(){
         this.setState({open:false})
         setTimeout(() => {
              this.props.cancle()  
         }, 200);
        
    }
    settest() {
        this.setState({
            test:
                <>

                    <tr rowspan="2" className="linee "><td>ภาชนะปนเปื้อน</td></tr>
                    <tr rowspan="2" className="linee"><td>วัสดุปนเปื้อนสารเคมี</td></tr>
                    <tr rowspan="2" className="linee"><td>สารเคมีเสื่อมสภาพ</td></tr>
                    <tr rowspan="2" className="linee"><td>น้ำปนเปื้อนน้ำมัน</td></tr>
                    <tr rowspan="2" className="linee"><td>ฝุ่นจากระบบบำบัด/ผงหมึก</td></tr>
                    <tr rowspan="2" className="linee"><td>แบตเตอรี่</td></tr>
                    <tr rowspan="2" className="linee"><td>น้ำมัน</td></tr>
                    <tr rowspan="2" className="linee"><td>ตัวทำละลายที่ใช้แล้ว(Solvent)</td></tr>
                    <tr rowspan="2" className="linee"><td>หลอดไฟ</td></tr>
                    <tr rowspan="2" className="linee"><td>เศษโลหะจากบัดกรี(Dross)</td></tr>
                    <tr rowspan="2" className="linee"><td>อื่นๆ............</td></tr>

                    <tr rowspan="2" className="linee"><td>ถังพลาสติก</td></tr>
                    <tr rowspan="2" className="linee"><td>บี๊ป</td></tr>
                    <tr rowspan="2" className="linee"><td>กระป๋องพลาสติก</td></tr>
                    <tr rowspan="2" className="linee"><td>กระป๋องอลูมิเนียม</td></tr>
                    <tr rowspan="2" className="linee"><td>ถุงพลาสติก</td></tr>
                    <tr rowspan="2" className="linee"><td>ขวดแก้ว</td></tr>
                    <tr rowspan="2" className="linee"><td>ถัง 200 ลิตร</td></tr>
                    <tr rowspan="2" className="linee"><td>อื่นๆ............</td></tr>

                </>
        })
    }
  async  componentDidMount() {
        // await this.setState({tmp:this.props.data})
        this.settest()
        await  this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await  this.setState({ open: true, })
        this.rowData()
    }
    render() {
        return (

            <>

                <Dialog
                    fullWidth="true"
                    maxWidth="lg"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >

                    <DialogTitle >Detail</DialogTitle>
                    <DialogContent>
                        <Grid container >
                            <Grid item xs={6}>
                                <Typography variant="button" display="block" gutterBottom><b>Canon</b></Typography>
                                <Typography variant="caption" display="block" gutterBottom>บริษัท แคนนอน ปราจีนบุรี (ประเทศไทย) จำกัด</Typography>
                                <Typography variant="caption" display="block" gutterBottom>
                                    วันที่ร้องขอทิ้ง 11/12/40 ชื่อผู้ขอทิ้งของเสีย MR.John ของเสีย Phase 2
                         </Typography>
                                <Typography variant="caption" display="block" gutterBottom>
                                    ฝ่ายงาน ICD ส่วนงาน CPD โทร 8122
                        </Typography>
                            </Grid>
                            <Grid item xs={1}></Grid>
                            <Grid item xs={5}>
                                <table className="linee">
                                    <tr >
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>APPROVED BY</b></Typography></center></td>
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>CHECKED BY</b></Typography></center></td>
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>PREPARED BY</b></Typography></center></td>
                                    </tr>
                                    <tr >
                                        <td className="linee"><br /><br /><br /></td>
                                        <td className="linee"><br /><br /><br /></td>
                                        <td className="linee"><br /><br /><br /></td>
                                    </tr>
                                </table>
                            </Grid>
                        </Grid>


                         <Grid container style={{ marginTop: 'calc(2%)' }}>
                                <Grid item xs = {12}>
                                    {this.state.element}
                                 </Grid>
                          </Grid>
                            {/* <Grid container style={{ marginTop: 'calc(2%)' }}>
                    <table className="linee">
                        <tr>
                            <td className="linee" colspan="27">ใบรับรองของเสียอันตราย (Request form for Hazardous waste disposal)</td>
                        </tr>

                        <tr>
                            <td rowspan="3" style={{padding:'0%'}} className="linee verticalTableHeader" >ลำดับ</td>
                            <td rowspan="3" className="linee ">ชื่อของเสีย</td>
                            <td colspan="11" className="linee">ประเภทของเสีย</td>
                            <td colspan="8" className="linee">ลักษณะบรรจุภัณฑ์ของเสีย</td>
                            <td rowspan="3" className="linee">จำนวน (ชิ้น)</td>
                            <td rowspan="3" className="linee">น้ำหนัก (กิโลกรัม)</td>
                            <td rowspan="3" className="linee">น้ำหนักรวม กิโลกรัม</td>
                            <td colspan="3" className="linee">FAE</td>
                        </tr>
                        <tr>
                            <td rowspan="2" className="linee verticalTableHeader"  style={{marginBottom:'200px'}}>ภาชนะปนเปื้อน</td>
                            <td rowspan="2" className="linee verticalTableHeader">วัสดุปนเปื้อนสารเคมี</td>
                            <td rowspan="2" className="linee verticalTableHeader">สารเคมีเสื่อมสภาพ</td>
                            <td rowspan="2" className="linee verticalTableHeader">น้ำปนเปื้อนน้ำมัน</td>
                            <td rowspan="2" className="linee verticalTableHeader">ฝุ่นจากระบบบำบัด/ผงหมึก</td>
                            <td rowspan="2" className="linee verticalTableHeader">แบตเตอรี่</td>
                            <td rowspan="2" className="linee verticalTableHeader">น้ำมัน</td>
                            <td rowspan="2" className="linee verticalTableHeader">ตัวทำละลายที่ใช้แล้ว(Solvent)</td>
                            <td rowspan="2" className="linee verticalTableHeader">หลอดไฟ</td>
                            <td rowspan="2" className="linee verticalTableHeader">เศษโลหะจากบัดกรี(Dross)</td>
                            <td rowspan="2" className="linee verticalTableHeader">อื่นๆ............</td>

                            <td rowspan="2" className="linee verticalTableHeader">ถังพลาสติก</td>
                            <td rowspan="2" className="linee verticalTableHeader">บี๊ป</td>
                            <td rowspan="2" className="linee verticalTableHeader">กระป๋องพลาสติก</td>
                            <td rowspan="2" className="linee verticalTableHeader">กระป๋องอลูมิเนียม</td>
                            <td rowspan="2" className="linee verticalTableHeader">ถุงพลาสติก</td>
                            <td rowspan="2" className="linee verticalTableHeader">ขวดแก้ว</td>
                            <td rowspan="2" className="linee verticalTableHeader">ถัง 200 ลิตร</td>
                            <td rowspan="2" className="linee verticalTableHeader">อื่นๆ............</td>
                   
  
                            <td rowspan="2" className="linee"> (/) อนุญาตให้ทิ้ง (x) ไม่อนุญาตให้ทิ้ง</td>
                            <td colspan="2" className="linee">วิธีกำจัด</td>
                        </tr>
                        <tr>
                            <td className="linee">เผาทำลาย</td>
                            <td className="linee">รีไซเคิล</td>
                        </tr>
                        <tr>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                        </tr>
                        <tr>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                        </tr>
                        <tr>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                        </tr>
                        <tr>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                            <td className="linee">#</td>
                        </tr>
                    </table>
                </Grid>  */}

                        <Grid container style={{ marginTop: 'calc(2%)' }}>
                            <Grid item xs={11}>
                                <table style={{ width: '99.2%' }} className="linee">
                                    <tr>
                                        <td className="linee" colSpan={3} style={{ backgroundColor: 'darkgray' }}><center><Typography variant="h6" >FAE</Typography></center></td>
                                        <td className="linee" style={{ width: '55%' }}>
                                            <Typography variant="caption" display="block" gutterBottom>
                                                ข้อเสนอแนะเพิ่มเติมจาก FAE
                               </Typography>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td className="linee"><center><Typography variant="button" display="block" ><b>APPROVED BY</b></Typography></center></td>
                                        <td className="linee"><center><Typography variant="button" display="block" ><b>CHECKED BY</b></Typography></center></td>
                                        <td className="linee"><center><Typography variant="button" display="block" ><b>PREPARED BY</b></Typography></center></td>
                                        <td className="linee" rowSpan={2} style={{ borderBottomLeftRadius: '1px solid black', borderCollapse: 'collapse' }}>

                                        </td>
                                    </tr>
                                    <tr >
                                        <td className="linee"><br /><br /><br /></td>
                                        <td className="linee"><br /><br /><br /></td>
                                        <td className="linee"><br /><br /><br /></td>
                                    </tr>
                                </table>
                            </Grid>
                            <Grid item xs={1}>

                            </Grid>

                        </Grid>
                    </DialogContent>
                    <DialogActions>
                        {/* <Button color="primary">UPDATE</Button> */}
                    </DialogActions>
                </Dialog>

            </>
        )
    }
}
export default FormA

