import React from 'react'
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
class Discription extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }
    componentDidMount() {

    }
    render() {
        return (
            <>
                <Grid >
                    <Card variant="outlined" style={{borderColor:'black',borderRadius:'0%'}}>
                        <CardContent >
                            <Typography variant="button" display="block" gutterBottom>
                                <b style={{textDecorationLine:'underline'}}>ขั้นตอนการทิ้ง</b>
                         </Typography>
                            <Typography variant="caption" display="block" gutterBottom>
                                1.ผู้ร้องขอทำการกรอกเอกสารส่งมายัง FAE (ภายใน 16.00 น.)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                2.FAE อนุมัติ ส่งเอกสารกลับ copy /Scan ไปยังผู้ร้องขอ (ภายใน 14.00 น.ในวันถัดไป)
                         </Typography>
                         <Typography variant="caption" display="block" gutterBottom>
                                3.เมื่อได้รับการ approve จากทาง FAE แล้วติด EF-FAE-ENV-016 Chemical Waste Label&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                4.ฝ่ายงานทำการขอขยะไปที่ Recycle center พร้อมเอกสารที่ได้รับการอนุมัติ
                         </Typography>
                         <Typography variant="caption" display="block" gutterBottom>
                                5.ก่อนทำการทิ้งต้องทำการแจ้งพนักงานดูแล Recycle center ก่อนทุกครั้งเพื่อทำการลงบันทึกทิ้งของเสียอันตราย
                         </Typography>
                         <Typography variant="caption" display="block" gutterBottom>
                                6.ช่วงเวลาการนำไปทิ้งเป็นไปตามประกาศของ FAE
                         </Typography>

                        </CardContent>
                    </Card>
                </Grid>

            </>
        )
    }
}
export default Discription

