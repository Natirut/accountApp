import React from 'react'
import Button from '@material-ui/core/Button';
import Axios from 'axios';
import CloudUpload from '@material-ui/icons/CloudUpload';
import Grid from '@material-ui/core/Grid';
import Fab from '@material-ui/core/Fab';
import Loading from '../../components/LoadingBar/index.component';
import Errorbar from '../../components/ShowErrorbar/index.component';
import Dropzone from 'react-dropzone';
class InfectiousForm extends React.Component {
    constructor(props) {
        super(props)
        this.onDrop = async (files) => {
            await this.setState({ files: files[0] })
            await this.submit()
            // console.log("test",files[0])
        };
        this.state = {
            file: null
        }

        this.onFileSelect = this.onFileSelect.bind(this);
        this.submit = this.submit.bind(this);
        this.SuccessLoadingbar = this.SuccessLoadingbar.bind(this);
        this.Errorbar = this.Errorbar.bind(this);
    }
    SuccessLoadingbar() {
        setTimeout(() => {
            this.setState({ loading: true })
        }, 300);

        setTimeout(() => {
            this.setState({ loading: false })
        }, 1800);
    }

    Errorbar() {
        this.setState({ showbar: true })
        setTimeout(() => {
            this.setState({ showbar: false })
        }, 1300);
    }

    async submit() {
        try {
            let formData = new FormData();
            formData.append('form', "Infectious");
            formData.append('file', this.state.file);


            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'multipart/form-data', accept: 'text/plain',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const response = await instance.post(`/fae-part/requester/upload`, formData);
            this.SuccessLoadingbar()
            console.log(response)
        } catch (err) {
            this.Errorbar()
        }
    }
    uploadFileOnlocal() {
        document.getElementById('file').click();
    }
    async onFileSelect(e) {
        console.log(e.target.files)
        await this.setState({ file: e.target.files })
        console.log(this.state.file)
    }

    async componentDidMount() {

    }
    render() {
        
        let loader;
        if (this.state.loading === true) {
            loader = <Loading />
        }

        let error;
        if (this.state.showbar === true) {
            error = <Errorbar />
        }
        return (
            <>{loader}{error}
                <Grid container style={{ marginTop: 'calc(3%)' }} >
                    <Grid item xs={1}>

                    </Grid>
                    {/* <Grid item xs={3}>
                        <Fab color="primary" aria-label="add" onClick={this.uploadFileOnlocal} style={{ width:' 60px',height: '60px' }} >
                            <input accept=".xlxs" id="file" type="file" onChange={this.onFileSelect} multiple hidden />
                            <CloudUpload style={{ fontSize: '25px' }} />
                         
                        </Fab>
                    </Grid> */}

                </Grid>
                {/* <Grid container style={{ marginTop: 'calc(3%)',textAlign: 'center' }}  >
                    <Grid item xs={12} >
                     <Button variant="contained" onClick={this.submit}>Upload</Button>
                     </Grid>
                </Grid> */}
                <Grid container>
                    <Grid item xs={4}></Grid>
                    <Grid item xs={4}>
                        <Dropzone onDrop={this.onDrop} className="dropzone">
                            {({ getRootProps, getInputProps }) => (
                                <section className="container">
                                    <div {...getRootProps({ className: 'dropzone' })}>
                                        <input {...getInputProps()} />
                                        <p className="fileDrop">
                                            <Grid container>
                                                <Grid item xs={12}>
                                                    <CloudUpload style={{ fontSize: '50px', color: 'darkblue' }} />
                                                </Grid>
                                            </Grid>
                                            INFECTIONUS FORM
                                        </p>
                                    </div>
                                </section>
                            )}
                        </Dropzone>
                    </Grid>
                    <Grid item xs={4}></Grid>
                </Grid>
            </>
        )
    }
}
export default InfectiousForm