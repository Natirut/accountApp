import React from 'react'
import Grid from '@material-ui/core/Grid';
import FormA from '../component/formA';
import Discription from '../component/discription';
class ShowformA extends React.Component{
     constructor(props){
          super(props)
          this.state={

          }
     }
     componentDidMount(){

     }
     render(){
         return(
             <>
             <Grid container style={{marginTop:'calc(6%)'}}>
                 <Grid item xs = {1}>

                 </Grid>
                 <Grid  item xs = {11}>
                 <FormA/>
                     </Grid>
             
             </Grid>
             <Grid container style={{marginTop:'calc(1%)',alignItems:'center'}}>
             <Grid item xs = {1}>

              </Grid>
              <Grid item xs = {10}>
                  <Discription/>
               </Grid>
             </Grid>
             </>
         )
     }
}
export default ShowformA

