import React from 'react'
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import InputFrom from './dialogInput';
import Button from '@material-ui/core/Button';
import SendIcon from '@material-ui/icons/Send';
import IconButton from '@material-ui/core/IconButton';
import ReorderIcon from '@material-ui/icons/Reorder';
import DataTable from '../../components/datatableselect/index.component'
import DialogForm from '../component/formA';
import DialogNon from '../../components/previewForm/formnon-boi/index.form'
import DialogBoi from '../../components/previewForm/formboi/index.form'
import moment from 'moment';
class Check extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            openInput: false,
            element: null,
            dialogDetail: false,
            dataimo: null,
            dataimonon: null,
            dataimoboi: null,
            dialogNon: false,
            dialogBoi: false,
            dataSelect: null
        }
        this.OpenDialog = this.OpenDialog.bind(this);
        this.openInputForm = this.openInputForm.bind(this)
        this.OpenDialog = this.OpenDialog.bind(this);
        this.cancle = this.cancle.bind(this);
        this.OpenDialogPriviewNon = this.OpenDialogPriviewNon.bind(this);
        this.OpenDialogPriviewBoi = this.OpenDialogPriviewBoi.bind(this);
        this.dataselect = this.dataselect.bind(this);
        this.SendApprove = this.SendApprove.bind(this);
        this.SendReject = this.SendReject.bind(this);

    }
    async SendReject() {
        if (this.state.dataSelect.length !== 0 && this.state.dataSelect !== null) {
            const tmp = []
            console.log("data", this.state.dataSelect)
            for (let i = 0; i < this.state.dataSelect.length; i++) {
                tmp.push(this.state.dataSelect[i].lotNo)
            }


            try {
                const body = {
                    lotNo: tmp,
                    status: "reject"
                }
                console.log(body, "bodyy")
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const res = await instance.put(`/fae-part/requester/status`, body);
                console.log(res, "resssssssssss")
                await this.setState({ element: null })
                this.rowData()
            } catch (err) {
                console.log(err)
            }
        }

    }
    async SendApprove() {
        if (this.state.dataSelect.length !== 0 && this.state.dataSelect !== null) {
            const tmp = []
            console.log("data", this.state.dataSelect)
            for (let i = 0; i < this.state.dataSelect.length; i++) {
                tmp.push(this.state.dataSelect[i].lotNo)
            }


            try {
                const body = {
                    lotNo: tmp,
                    status: "req-checked"
                }
                console.log(body, "bodyy")
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const res = await instance.put(`/fae-part/requester/status`, body);
                console.log(res, "resssssssssss")
                await this.setState({ element: null })
                this.rowData()
            } catch (err) {
                console.log(err)
            }
        }

    }
    async OpenDialogPriviewNon(data) {
        console.log(data)
        await this.setState({ dataimonon: data })
        this.setState({ dialogNon: true })
    }
    async OpenDialogPriviewBoi(data) {
        console.log(data)
        await this.setState({ dataimoboi: data })
        this.setState({ dialogBoi: true })
    }
    async OpenDialog(x) {
        console.log("open", x)
        await this.setState({ dataimo: x })
        await this.setState({ dialogDetail: true, })

    }
    dataselect(x) {
        this.setState({ dataSelect: x })
    }
    async rowData() {
        try {
            const column = [
                // {
                //     field: 'check', title: <input type="checkbox" style={{ transform: 'scale(1.5, 1.5)' }} name="checkall" ></input>, align: 'left', width: 0.5, sorting: false,
                // },
                // {
                //     field: 'reject', title: <IconButton color="primary" aria-label="upload picture" component="span">
                //         <BackspaceIcon style={{ color: '#f67280' }} />
                //     </IconButton>, align: 'left',
                // },
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'date', title: <b>Date</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'time', title: <b>Time</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'status', title: <b>Status</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'ShowBOI', title: <b>ShowBOI</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'ShowNONBOI', title: <b>ShowNON-BOI</b>, align: 'center', cellStyle: { padding: '0 14px' } }
            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/requester/req-prepared`);
            console.log("data prepared", response.data.data.scrapImo)
            this.setState({
                Alldata: response.data.data
            })

            var groupArray = require('group-array');
            var imo = groupArray(response.data.data.scrapImo, 'lotNo');
            //   console.log("group",imo['IMO-002/2021'])
            console.log("dadad", response.data.data.scrapImo)
            console.log("group", imo)
            const row = [];
            // var key = Object.keys(imo)
            // console.log("key", key)

            for (const [key, value] of Object.entries(imo)) {
                console.log(key, value[0])
                row.push(
                    {
                        // check: <>
                        //     <Grid item xs={4}>
                        //         <input type="checkbox" style={{ transform: 'scale(1.4, 1.4)' }} name="acs"></input>
                        //     </Grid>

                        // </>
                        // ,
                        // reject: <> <Grid item xs={4}>
                        //     <IconButton color="primary" aria-label="upload picture" component="span">
                        //         <BackspaceIcon style={{ color: '#f67280' }} />
                        //     </IconButton>

                        // </Grid>
                        // </>,
                        lotNo: value[0].lotNo,
                        date: moment(value[0].date).format('DD/MM/YYYY'),
                        time: value[0].time,
                        status: value[0].status,
                        ShowBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewBoi(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: '#32afa9' }} /> </Grid>
                            </IconButton>
                        </>,
                        ShowNONBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewNon(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: 'red' }} /> </Grid>
                            </IconButton>
                        </>
                    }
                )
            }


            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Requester Prepared." headers={this.state.columns} data={this.state.data} dataselect={this.dataselect} /> })
            }, 500);
        } catch (err) {
            // console.log(err.response.status)
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="Requester Prepared." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    componentDidMount() {
        this.rowData();
    }
    cancle() {
        this.setState({ openInput: false })
        this.setState({ dialogDetail: false })
        this.setState({ dialogNon: false })
        this.setState({ dialogBoi: false })
    }
    openInputForm() {
        this.setState({ openInput: true })
    }
    render() {
        let dialoginput;
        if (this.state.openInput === true) {
            dialoginput = <InputFrom cancle={this.cancle} />
        }
        let showDetail
        if (this.state.dialogDetail === true) {
            showDetail = <DialogForm cancle={this.cancle} data={this.state.dataimo} />
        }
        let showNon
        if (this.state.dialogNon === true) {
            showNon = <DialogNon cancle={this.cancle} data={this.state.dataimonon} />
        }
        let showBoi
        if (this.state.dialogBoi === true) {
            showBoi = <DialogBoi cancle={this.cancle} data={this.state.dataimoboi} />
        }
        return (
            <>{dialoginput}{showDetail}{showNon}{showBoi}
                <Grid container spacing={0} style={{ marginTop: 'calc(4%)' }}>
                    <Grid item xs={9}></Grid>
                    <Grid item xs={1} className="record-action">
                            <Button
                                variant="contained"
                                color="primary"
                                endIcon={<SendIcon />}
                                onClick={this.SendApprove}
                            >
                                Approve
                        </Button>
                    </Grid>
                    <Grid item xs={1} className="record-action">
                        <Button color="primary" variant="contained"
                            style={{ backgroundColor: 'rgb(218 37 37)', color: 'white' }}
                         onClick={this.SendReject}
                        > Reject </Button>
                    
                    </Grid>
                </Grid>
                <Grid container>
                    <Grid item xs={12} style={{ marginTop: 'calc(3%)' }}>
                        {this.state.element}
                    </Grid>
                </Grid>

            </>
        )
    }
}
export default Check

