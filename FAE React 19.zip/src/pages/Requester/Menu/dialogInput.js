import React from 'react'
import Axios from 'axios';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import DatePicker from '../../components/datepicker/index.component'
import MenuItem from '@material-ui/core/MenuItem';
import WarningIcon from '@material-ui/icons/Warning';
import SecurityIcon from '@material-ui/icons/Security';
import FormatBoldIcon from '@material-ui/icons/FormatBold';
import Fab from '@material-ui/core/Fab';
import SaveIcon from '@material-ui/icons/Save';
import CancelIcon from '@material-ui/icons/Cancel';
import Button from '@material-ui/core/Button';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Today from '@material-ui/icons/Today';
import moment from 'moment';
import Autocomplete from '@material-ui/lab/Autocomplete';
import FormControl from '@material-ui/core/FormControl';
import { Select, InputLabel } from '@material-ui/core';
import FontDownloadIcon from '@material-ui/icons/FontDownload';
// import SwipeableViews from 'react-swipeable-views';
import SwipeableViews from 'react-swipeable-views';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import IconButton from '@material-ui/core/IconButton';
import Discription from '../component/discription';
import FormHazardous from '../FormA/Hazardous.form';
import FormInfection from '../FormA/Infectious.form';
import FormIMO from '../FormB/Imo.form';
import FormPMD from '../FormB/Pmd.form';
class RequesterInput extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            valueDate: '',
            dialogDate: false,
            time: '',
            // data_deptdiv: null,
            // data_div: null,
            // show_div: null,
            // data_dept: null,
            pageA: null,
            pageB: null,
            pageC: null,
            pageD: null,

            index: 0,
            index2: 0,

            open: false,
            slide: null,

            checkstep4: null,
            checkstep3: null,

            showformone: null,
            showformtwo: null,

            dataHazardous: null,
            dataInfectious: null,
            dataIMO: null

        }
        this.openDatePicker = this.openDatePicker.bind(this)
        this.onSelectedDate = this.onSelectedDate.bind(this)
        this.Settime = this.Settime.bind(this)
        // this.SetDept = this.SetDept.bind(this)
        this.getCurren = this.getCurren.bind(this)
        this.ShowPageA = this.ShowPageA.bind(this)
        this.ShowPageB = this.ShowPageB.bind(this)
        this.ShowPageC = this.ShowPageC.bind(this)
        this.ShowPageD = this.ShowPageD.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.handleChangeIndex = this.handleChangeIndex.bind(this)
        this.handleChange2 = this.handleChange2.bind(this)
        this.handleChangeIndex2 = this.handleChangeIndex2.bind(this)
        this.handleCancle = this.handleCancle.bind(this)
        this.SentRequester = this.SentRequester.bind(this)
        this.GetRequester = this.GetRequester.bind(this)
        this.SetCompany = this.SetCompany.bind(this)
        this.ShowFormOne = this.ShowFormOne.bind(this);
        this.ShowFormTwo = this.ShowFormTwo.bind(this);

        this.GetHazardous = this.GetHazardous.bind(this);
        this.GetInfectious = this.GetInfectious.bind(this);
        this.GetIMO = this.GetIMO.bind(this);
        this.InsertRequester = this.InsertRequester.bind(this);

        // GetInfectious
        // ShowPageA
    }
    async InsertRequester() {
        const data = {
            date: "string",
            time: "string",
            hazardous: this.state.dataHazardous,
            infections: this.state.dataInfectious,
            scrapImo: this.state.dataIMO
        }
        console.log("data", data)
        try {
            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const response = await instance.post(`/fae-part/requester`, data);
            console.log("res post", response.data)
        } catch (err) {
            console.log(err)
        }
    }
    async ShowFormOne() {
        //    await this.setState({showformone:null})
        await this.setState({
            showformone: <Grid container style={{ marginTop: 'calc(3%)' }}>
                <Grid container>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid>
                        <Tabs value={this.state.index} fullWidth onChange={this.handleChange} style={{ backgroundColor: '#fff' }}>
                            <Tab label="Hazardous Waste" />
                            <Tab label="Infectious Waste" />
                        </Tabs>
                    </Grid>
                </Grid>

                <Grid container>
                    <Grid item xs={12} >

                        <SwipeableViews index={this.state.index} onChangeIndex={this.handleChangeIndex}>
                            {this.state.pageA}
                            {this.state.pageB}
                        </SwipeableViews>
                    </Grid>
                </Grid>
            </Grid>
        })
    }

    async ShowFormTwo() {
        //    await this.setState({showformone:null})
        await this.setState({
            showformone: <Grid container style={{ marginTop: 'calc(3%)' }}>
                <Grid container>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid>
                        <Tabs value={this.state.index2} fullWidth onChange={this.handleChange2} style={{ backgroundColor: '#fff' }}>
                            <Tab label="Scrap Material IMO" />
                            <Tab label="Scrap Material PMD" />
                        </Tabs>
                    </Grid>
                </Grid>

                <Grid container>
                    <Grid item xs={12} >

                        <SwipeableViews index={this.state.index2} onChangeIndex={this.handleChangeIndex2}>
                            {this.state.pageC}
                            {this.state.pageD}
                        </SwipeableViews>
                    </Grid>
                </Grid>
            </Grid>
        })
    }

    async SetCompany(e) {
        await this.setState({ company: e.target.value })
        console.log("comm", this.state.company)
    }


    async GetRequester() {
        try {
            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const response = await instance.get(`/fae-part/requester`);
            console.log("get", response.data)
        } catch (err) {
            console.log(err)
        }
    }
    async SentRequester() {
        try {
            const data = {
                "date": "now",
                "time": "now",
                "dept": "now",
                "div": "now",
                "formA": [
                    {
                        "phase": "now",
                        "wasteName": "now",
                        "wasteGroup": "now",
                        "contracterCompany": "now",
                        "bindingType": "now",
                        "cptMainType": "now",
                        "wasteType": "now",
                        "boiType": "now",
                        "partNormalType": "now",
                        "productType": "now",
                        "lotNo": "now",
                        "companyApproveNo": "now",
                        "containerType": "now",
                        "qtyOfContainer": "now",
                        "weightPerContainer": "now",
                        "totalWeight": "now"
                    }
                ],
                "fromB": [
                    {
                        "item": "now"
                    }
                ]
            }

            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const response = await instance.post(`/fae-part/requester`, data);
            console.log("res post", response.data)
        } catch (err) {
            console.log(err.stack)
        }
    }
    handleCancle() {
        this.setState({ open: false })
        this.props.cancle()
    }

    handleChange = async (event, value) => {
        console.log("valll", value)
        await this.setState({
            index: null,
        });
        this.setState({
            index: value,
        });
        this.ShowFormOne()
        // this.ShowFormOne()
    };

    handleChangeIndex = async index => {
        // console.log("index", index)
        await this.setState({
            index: null,
        });
        this.setState({
            index,
        });
        this.ShowFormOne()
    };

    handleChange2 = async (event, value) => {
        console.log("valll", value)
        await this.setState({
            index2: null,
        });
        this.setState({
            index2: value,
        });
        this.ShowFormTwo()
        // this.ShowFormOne()
    };

    handleChangeIndex2 = async index2 => {
        // console.log("index", index)
        await this.setState({
            index2: null,
        });
        this.setState({
            index2,
        });
        this.ShowFormTwo()
    };

    getCurren() {
        let datee
        let timee
        datee = moment(this.state.currenDate).format('YYYY/MM/DD')
        timee = moment(this.state.currenDate).format('HH:mm')
        this.setState({ valueDate: datee })
        this.setState({ time: timee })


    }
    ShowPageC() {
        this.setState({
            pageC: <FormIMO data={this.GetIMO} />
        })
    }
    ShowPageD() {
        this.setState({
            pageD: <FormPMD />
        })
    }
    async ShowPageB() {
        // await this.setState({pageB:null})
        await this.setState({
            pageB: <Grid container>
            <Grid item xs = {4}>
            <FormIMO data={this.GetIMO} />
            </Grid>
            <Grid item xs = {4}>
            <FormPMD />
            </Grid>
            <Grid item xs = {4}>
            {/* <FormHazardous data={this.GetHazardous} /> */}
            </Grid>
            
       </Grid>
        })
    }
    async GetHazardous(val) {
        console.log("val hazardius", val)
        await this.setState({ dataHazardous: val })

    }
    async GetInfectious(val) {
        console.log("val Infec", val)
        await this.setState({ dataInfectious: val })
    }
    async GetIMO(val) {
        console.log("val imo", val)
        await this.setState({ dataIMO: val })
    }
    async ShowPageA() {
        // await this.setState({pageA:null})
        this.setState({
            pageA: <Grid container>
                        <Grid item xs = {4}>
                        <FormHazardous data={this.GetHazardous} />
                        </Grid>
                        <Grid item xs = {4}>
                        <FormInfection data={this.GetInfectious} />
                        </Grid>
                        <Grid item xs = {4}>
                        {/* <FormHazardous data={this.GetHazardous} /> */}
                        </Grid>
                        
                   </Grid>
        })
    }
    // async SetDept(e, data) {
    //     if (data !== null) {
    //         await this.setState({ data_div: data.diV_NAME_WC })
    //         this.setState({ data_dept: data.depT_ABB_NAME })
    //         this.setState({
    //             show_div:
    //                 <TextField id="div" style={{ width: '170px' }} label="Div" variant="outlined" value={this.state.data_div} />
    //         })
    //     }
    // }

    async componentDidMount() {
        // await this.getDept()
        await this.ShowPageA()
        await this.ShowPageB()
        await this.ShowPageC()
        await this.ShowPageD()
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });

        this.setState({ open: true, })
    }
    // async getDept() {
    //     let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/service/dept`
    //     try {
    //         Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
    //             .then(async res => {
    //                 console.log("data", res.data.data)
    //                 await this.setState({ data_deptdiv: res.data.data })
    //             })


    //     } catch (err) {
    //         console.log(err.response)
    //     }
    // }
    Settime(e) {
        console.log(e.target.value)
        this.setState({ time: e.target.value })
    }
    openDatePicker() {
        this.setState({ dialogDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ valueDate: date.selectedDate })
        }
        this.setState({ dialogDate: false, })
    }
    render() {
        // const { index } = this.state;
        let datepicker;
        if (this.state.dialogDate === true) {
            datepicker = <DatePicker callBackClose={this.onSelectedDate} />
        }
        // let content_array = [this.state.pageA, this.state.pageB];
        return (
            <>
                {datepicker}
                <Dialog fullScreen open={this.state.open} onClose={this.handleCancle} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: ' #d3ffd3', color: '#424874' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleCancle}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Requester Input</Typography>
                        </Toolbar>
                    </AppBar>
                    <Grid container style={{ marginTop: 'calc(4%)' }}>
                        <Grid container >
                            <Grid container>
                                <Grid item xs={1}>

                                </Grid>
                                <Grid item xs={3}>
                                    <TextField id="date" style={{ width: '190px' }} label="Request Date" variant="outlined" value={this.state.valueDate} onClick={this.openDatePicker} />
                                </Grid>

                                <Grid item xs={3}>
                                    <TextField onChange={this.Settime} style={{ width: '180px' }} id="time" type="time" label="Request Time" variant="outlined" value={this.state.time} />
                                    <Today onClick={this.getCurren} style={{ color: '#00b300', position: 'absolute' }} />
                                </Grid>
                            </Grid>
                        </Grid>
                        {/* <Grid container style={{ marginTop: 'calc(3%)' }}>
                            <Grid item xs={1}>

                            </Grid>
                            <ButtonGroup style={{ padding: '15px' }} size="large" color="primary" aria-label="outlined secondary button group">
                                <Button color="primary" startIcon={<WarningIcon style={{ color: '#b300b3' }} />} style={{ fontSize: '20px' }} onClick={this.ShowFormOne}>
                                    Non-BOI
                                    </Button>
                                <Button startIcon={<SecurityIcon style={{ color: '#3c00b3' }} />} style={{ fontSize: '20px' }} onClick={this.ShowFormTwo}>
                                    BOI
                                    </Button>
                            </ButtonGroup>
                        </Grid> */}
                        {/* {this.state.showformone}
                        {this.state.showformtwo} */}
                        <Grid container style={{ marginTop: 'calc(3%)',textAlign:'center' }}>
                            <Grid container style={{textAlign:'center'}}>
                                <Grid item xs={1}>

                                </Grid>
                                    <Tabs value={this.state.index} fullWidth onChange={this.handleChange} style={{ backgroundColor: '#fff' }}>
                                        <Tab label="HAVE DB" />
                                        <Tab label="DON HAVE DB" />
                                    </Tabs>
                            </Grid>

                            <Grid container>
                                <Grid item xs={12} >

                                    <SwipeableViews index={this.state.index} onChangeIndex={this.handleChangeIndex}>
                                        {this.state.pageA}
                                        {this.state.pageB}
                                    </SwipeableViews>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid container style={{ marginTop: 'calc(2%)' }} >
                            <Grid item xs={1}>
                            </Grid>
                            <Grid item xs={10}>
                                <Discription />
                            </Grid>

                        </Grid>
                        <Grid container>
                            <br /><br />
                        </Grid>
                    </Grid>
                </Dialog>
            </>
        )
    }
}
export default RequesterInput

