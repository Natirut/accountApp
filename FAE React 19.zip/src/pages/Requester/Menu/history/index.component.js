import React from 'react'
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import TodayIcon from '@material-ui/icons/Today';
import Tooltip from '@material-ui/core/Tooltip';
import DatePickerRange from '../../../components/datepickerRange/index.component';
import DataTable from '../../../components/datatable/index.component';
import ReorderIcon from '@material-ui/icons/Reorder';
import IconButton from '@material-ui/core/IconButton';
import DialogNon from '../../../components/previewForm/formnon-boi/index.form'
import DialogBoi from '../../../components/previewForm/formboi/index.form'
import moment from 'moment';
class HistoryRequester extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            pickerDate: false,
            pickedDateStart: null,
            pickedDateEnd: null,
            datahistory:null,
            element:null,
            dataimonon: null,
            dataimoboi: null,
            dialogNon: false,
            dialogBoi: false,
        }
        this.openDatePicker = this.openDatePicker.bind(this);
        this.onSelectedDate = this.onSelectedDate.bind(this);
        this.gethistory = this.gethistory.bind(this);
        this.rowData = this.rowData.bind(this);
        this.OpenDialogPriviewNon = this.OpenDialogPriviewNon.bind(this);
        this.OpenDialogPriviewBoi = this.OpenDialogPriviewBoi.bind(this);
        this.cancle = this.cancle.bind(this);
    }
    cancle() {
        this.setState({ dialogNon: false })
        this.setState({ dialogBoi: false })
    }
    async OpenDialogPriviewNon(data) {
        console.log(data)
        await this.setState({ dataimonon: data })
        this.setState({ dialogNon: true })
    }
    async OpenDialogPriviewBoi(data) {
        console.log(data)
        await this.setState({ dataimoboi: data })
        this.setState({ dialogBoi: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ pickedDateStart: date.selectedDateStart })
            await this.setState({ pickedDateEnd: date.selectedDateEnd })
          //  await this.setState({ status: date.status })
            console.log("start", this.state.pickedDateStart)
            console.log("end", this.state.pickedDateEnd)
        }
        await this.setState({ pickerDate: false, })
       // if (this.state.status === true) {
            await this.gethistory();
            await this.setState({element:null})
            await this.rowData();
       // }

    }
  async gethistory(){
        try{
           const instance = axios.create({
            baseURL: process.env.REACT_APP_ENDPOINT,
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json',
            }
        });

        const dateRange = {
            startDate: this.state.pickedDateStart,
            endDate: this.state.pickedDateEnd
        }
        console.log(dateRange)
        const res = await instance.patch(`/fae-part/requester/history`, dateRange);
        console.log(res.data.data,"ress")
        await this.setState({datahistory:res.data.data})
        await  this.rowData()
        }catch(err){
            console.log(err)
        }
    }
    async rowData() {
        try {
            const column = [
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'date', title: <b>Date</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'time', title: <b>Time</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'status', title: <b>Status</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'ShowBOI', title: <b>ShowBOI</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'ShowNONBOI', title: <b>ShowNON-BOI</b>, align: 'center', cellStyle: { padding: '0 14px' } }
            ];
       
            var groupArray = require('group-array');
            var imo = groupArray(this.state.datahistory, 'lotNo');
            const row = [];
            for (const [key, value] of Object.entries(imo)) {
                console.log(key, value[0])
                row.push(
                    {
                        lotNo: value[0].lotNo,
                        date: moment(value[0].date).format('DD/MM/YYYY'),
                        time: value[0].time,
                        status: value[0].status,
                        ShowBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewBoi(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: '#32afa9' }} /> </Grid>
                            </IconButton>
                        </>,
                        ShowNONBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewNon(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: 'red' }} /> </Grid>
                            </IconButton>
                        </>
                    }
                )
            }


            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Requester History." headers={this.state.columns} data={this.state.data} dataselect={this.dataselect} /> })
            }, 500);
        } catch (err) {
            // console.log(err.response.status)
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="Requester History." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    openDatePicker(){
        this.setState({pickerDate:true})
    }
  async  componentDidMount() {
        await this.gethistory();
        await this.rowData();
    }
    render() {
        let datepicker;
        if (this.state.pickerDate === true) {
            datepicker = <DatePickerRange callBackClose={this.onSelectedDate} />
        }
        let showNon
        if (this.state.dialogNon === true) {
            showNon = <DialogNon cancle={this.cancle} data={this.state.dataimonon} />
        }
        let showBoi
        if (this.state.dialogBoi === true) {
            showBoi = <DialogBoi cancle={this.cancle} data={this.state.dataimoboi} />
        }
        return (
            <>{datepicker}{showNon}{showBoi}
                <Grid container style={{ marginTop: '80px' }}>
                    <Grid item xs={10}>
                     
                    </Grid>
                    <Grid item xs={2}>
                        <Tooltip title="Search with date range.">
                            <TodayIcon style={{ cursor: 'pointer', color: '#007d00' }} onClick={this.openDatePicker} />
                        </Tooltip>
                        Select date range
                    </Grid>

                    <Grid item xs={4}>
                    </Grid>

                </Grid>
                <Grid container>
                    <Grid item xs={12} style={{ marginTop: 'calc(3%)' }}>
                        {this.state.element}
                    </Grid>
                </Grid>
            </>
        )
    }
}
export default HistoryRequester

