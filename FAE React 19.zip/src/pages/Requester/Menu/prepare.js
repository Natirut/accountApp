import React from 'react'
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import Tooltip from '@material-ui/core/Tooltip';
import InputFrom from './dialogInput';
import DataTable from '../../components/datatable/index.component';
import IconButton from '@material-ui/core/IconButton';
import ReorderIcon from '@material-ui/icons/Reorder';
import DisplayDataset from '../component/displaydataSet.component';
import DialogForm from '../component/formA';
import DialogNon from '../../components/previewForm/formnon-boi/index.form'
import DialogBoi from '../../components/previewForm/formboi/index.form'
import Button from '@material-ui/core/Button';
import Loading from '../../components/LoadingBar/index.component'
import moment from 'moment';
class Prepare extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            openInput: false,
            element: null,
            displayDataset: false,
            dialogDetail: false,
            dataimonon: null,
            dataimoboi: null,
            dialogNon:false,
            dialogBoi:false
        }
        this.openInputForm = this.openInputForm.bind(this)
        this.cancle = this.cancle.bind(this)
        this.OpenDialog = this.OpenDialog.bind(this);
        this.OpenDialogPriviewNon = this.OpenDialogPriviewNon.bind(this);
        this.OpenDialogPriviewBoi = this.OpenDialogPriviewBoi.bind(this);
        // console.log(this.props)
    }
   async OpenDialogPriviewNon(data){
        console.log(data)
        await this.setState({ dataimonon: data })
       this.setState({dialogNon:true})
    }
    async OpenDialogPriviewBoi(data){
        console.log(data)
        await this.setState({ dataimoboi: data })
       this.setState({dialogBoi:true})
    }
    async OpenDialog(x) {
        console.log("open", x)
        await this.setState({ dataimo: x })
        await this.setState({ dialogDetail: true, })

    }
    // async cancle() {
    //     console.log("canclee")
      
    // }
    async getPrepared() {
        try {
            console.log('componentDidMount');
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    // 'Content-Type': 'application/json',
                }
            });

            const response = await instance.get(`/fae-part/requester/req-prepared`);
            console.log(response)
        } catch (error) {
            console.log(error.stack);
        }
    }
    
    async rowData() {
        try {
            const column = [
                // {
                //     field: 'check', title: <input type="checkbox" style={{ transform: 'scale(1.5, 1.5)' }} name="checkall" ></input>, align: 'left', width: 0.5, sorting: false,
                // },
                // {
                //     field: 'reject', title: <IconButton color="primary" aria-label="upload picture" component="span">
                //         <BackspaceIcon style={{ color: '#f67280' }} />
                //     </IconButton>, align: 'left',
                // },
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', cellStyle: { padding: '0 14px'}},
                { field: 'date', title: <b>Date</b>, align: 'center', cellStyle: { padding: '0 14px'}},
                { field: 'time', title: <b>Time</b>, align: 'center',cellStyle: { padding: '0 14px'} },
                { field: 'status', title: <b>Status</b>, align: 'center',cellStyle: { padding: '0 14px'} },
                { field: 'ShowBOI', title: <b>ShowBOI</b>, align: 'center',cellStyle: { padding: '0 14px'} },
                { field: 'ShowNONBOI', title: <b>ShowNON-BOI</b>, align: 'center',cellStyle: { padding: '0 14px'} }
            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/requester/req-prepared`);
            console.log("data prepared", response.data.data.scrapImo)
            this.setState({
                Alldata: response.data.data
            })

            var groupArray = require('group-array');
            var imo = groupArray(response.data.data.scrapImo, 'lotNo');
            //   console.log("group",imo['IMO-002/2021'])
            console.log("dadad",response.data.data.scrapImo)
            console.log("group", imo)
            const row = [];
            // var key = Object.keys(imo)
            // console.log("key", key)

            for (const [key, value] of Object.entries(imo)) {
                console.log(key, value[0])
                row.push(
                    {
                        // check: <>
                        //     <Grid item xs={4}>
                        //         <input type="checkbox" style={{ transform: 'scale(1.4, 1.4)' }} name="acs"></input>
                        //     </Grid>

                        // </>
                        // ,
                        // reject: <> <Grid item xs={4}>
                        //     <IconButton color="primary" aria-label="upload picture" component="span">
                        //         <BackspaceIcon style={{ color: '#f67280' }} />
                        //     </IconButton>

                        // </Grid>
                        // </>,
                        lotNo: value[0].lotNo,
                        date: moment(value[0].date).format('DD/MM/YYYY'),
                        time: value[0].time,
                        status: value[0].status,
                        ShowBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewBoi(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: '#32afa9' }} /> </Grid>
                            </IconButton>
                        </>,
                          ShowNONBOI: <>
                          <IconButton  onClick={() => this.OpenDialogPriviewNon(value)}    color="primary" aria-label="upload picture" component="span">
                              <Grid item xs={6}>  <ReorderIcon style={{ color: 'red' }} /> </Grid>
                          </IconButton>
                      </>
                    }
                )
            }


            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Requester Prepared." headers={this.state.columns} data={this.state.data} dataselect={this.dataselect} /> })
            }, 500);
        } catch (err) {
            // console.log(err.response.status)
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="Requester Prepared." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    componentDidMount() {
        this.rowData();
        this.getPrepared();
    }
    cancle() {
        this.setState({ openInput: false })
         this.setState({ dialogDetail: false })
         this.setState({ dialogNon: false })
         this.setState({ dialogBoi: false })
    }
    openInputForm() {
        this.setState({ openInput: true })
    }
    render() {
        let dialoginput; let displayDataset;
        if (this.state.openInput === true) {
            dialoginput = <InputFrom cancle={this.cancle} />
        }
        if (this.state.displayDataset === true) {
            displayDataset = <DisplayDataset />
        }
        let showDetail
        if (this.state.dialogDetail === true) {
            showDetail = <DialogForm cancle={this.cancle} data={this.state.dataimo} />
        }
        let showNon
        if (this.state.dialogNon === true){
            showNon = <DialogNon cancle={this.cancle} data={this.state.dataimonon}/>
        }
        let showBoi
        if (this.state.dialogBoi === true){
            showBoi = <DialogBoi cancle={this.cancle} data={this.state.dataimoboi}/>
        }
        return (
            <>{dialoginput}{showDetail}{showNon}{showBoi}
                <Grid container spacing={0} style={{ marginTop: 'calc(4%)' }}>
                    {displayDataset}
                    <Grid item xs={10}>
                    </Grid>
                    <Grid item xs={2} className="record-action">
                        <center>
                            <Tooltip title="Add item" aria-label="add">
                                <Fab color="secondary" style={{ backgroundColor: '#424874' }} onClick={this.openInputForm}>
                                    <AddIcon />
                                </Fab>
                            </Tooltip>
                        </center>
                    </Grid>
                </Grid>
                <Grid container>
                    <Grid item xs={12} style={{ marginTop: 'calc(3%)' }}>
                        {this.state.element}
                    </Grid>
                    {/* <Button color="primary" onClick={() => this.OpenDialogPriviewBoi(1) }  >
                                      BOI
                                    </Button> */}
                                    {/* <Button color="primary" onClick={() => this.OpenDialogPriviewNon(1) }  >
                                     NonBOI
                                    </Button> */}
                    {/* <Button onClick={this.OpenDialogPriviewNon(3)}>rrrrrrrrrr</Button> */}
                </Grid>
               

            </>
        )
    }
}
export default Prepare

