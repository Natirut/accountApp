import React from 'react'
import Axios from 'axios';
import CloudUpload from '@material-ui/icons/CloudUpload';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Fab from '@material-ui/core/Fab';
import Loading from '../../components/LoadingBar/index.component';
import Errorbar from '../../components/ShowErrorbar/index.component';
import Successbar from '../../components/ShowSuccessbar/index.component';
import Dropzone from 'react-dropzone';
import './style.css'
class ImoForm extends React.Component {
    constructor(props) {
        super(props)
        this.onDrop = async (files) => {
           await this.setState({ files:files[0] })
           await this.submit()
            // console.log("test",files[0])
        };
        this.state = {
            file: null,
            loading: false,
            showbar: false,
            showbarsuccess: false,
             files: []
        }

        this.onFileSelect = this.onFileSelect.bind(this);
        this.submit = this.submit.bind(this);
        this.SuccessLoadingbar = this.SuccessLoadingbar.bind(this);
        this.Errorbar = this.Errorbar.bind(this);
        this.Successbar = this.Successbar.bind(this);
    }
    SuccessLoadingbar() {
        setTimeout(() => {
            this.setState({ loading: true })
        }, 300);

        setTimeout(() => {
            this.setState({ loading: false })
        }, 1800);

        setTimeout(() => {
             this.Successbar()
        }, 1900);
    }

    Errorbar() {
        this.setState({ showbar: true })
        setTimeout(() => {
            this.setState({ showbar: false })
        }, 1300);
    }

    Successbar() {
        this.setState({ showbarsuccess: true })
        setTimeout(() => {
            this.setState({ showbarsuccess: false })
        }, 1300);
    }
    async submit() {
        console.log("Submit")
        try {
            let formData = new FormData();
            formData.append('form', "imo");
            formData.append('file', this.state.files);


            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'multipart/form-data', accept: 'text/plain',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const response = await instance.post(`/fae-part/requester/upload`, formData);
            await this.SuccessLoadingbar()
          
            console.log(response)
        } catch (err) {
            this.Errorbar()
        }
    }
    uploadFileOnlocal() {
        document.getElementById('file').click();
    }
    onDropFile(e,val){
        console.log(val)
    }
    async onFileSelect(e) {
        console.log(e.target.files[0])
        await this.setState({ file: e.target.files[0] })
        console.log(this.state.file)
        await this.submit()
    }

    async componentDidMount() {

    }
    render() {
        // const files = this.state.files.map(file => (
        //     <li key={file.name}>
        //         {file.name} - {file.size} bytes
        //     </li>
        // ));


        let loader;
        if (this.state.loading === true) {
            loader = <Loading />
        }
        let error;
        if (this.state.showbar === true) {
            error = <Errorbar />
        }
        let success;
        if (this.state.showbarsuccess === true) {
            success = <Successbar />
        }
        return (
            <>{loader}{error}{success}
                <Grid container style={{ marginTop: 'calc(3%)' }} >
                    <Grid item xs={1}>

                    </Grid>
                    {/* <Grid item xs={3}>
                        <Fab color="primary" aria-label="add" onClick={this.uploadFileOnlocal} style={{ width: ' 60px', height: '60px' }} >
                            <input accept=".xlxs" id="file" type="file" onChange={this.onFileSelect} multiple hidden />
                            <CloudUpload style={{ fontSize: '25px' }} />
                          
                        </Fab>
                    </Grid> */}

                </Grid>
                {/* <Grid container style={{ marginTop: 'calc(3%)', textAlign: 'center' }}  >
                    <Grid item xs={12} >
                        <Button variant="contained" onClick={this.submit}>Upload</Button>
                    </Grid>
                </Grid> */}
                <Grid container>
                <Grid item xs={4}></Grid>
                    <Grid item xs={4}>
                        <Dropzone onDrop={this.onDrop} className="dropzone">
                            {({ getRootProps, getInputProps }) => (
                                <section className="container">
                                    <div {...getRootProps({ className: 'dropzone' })}>
                                        <input {...getInputProps()} />
                                        <p className="fileDrop"> 
                                        <Grid container>
                                           <Grid item xs ={12}>
                                           <CloudUpload style={{ fontSize: '50px',color:'darkblue' }} />
                                           </Grid>
                                        </Grid>
                                           IMO FORM
                                        </p>
                                    </div>
                                </section>
                            )}
                        </Dropzone>
                    </Grid>
                    <Grid item xs={4}></Grid>
                </Grid>
            </>
        )
    }
}
export default ImoForm