
import React from 'react';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

import VerticalChart from '../../charts/verticalChart/index.component';


// PROPS FORMAT REQUEST
// header="" data=grap data
// PROPS FORMAT REQUEST
class MoreDetail extends React.Component {

    constructor() {
        super();

        this.state = {
            open: false,
        }
        this.handleClose = this.handleClose.bind(this);
    }
    componentDidMount() {
        this.setState({ open: true })
    }
    handleClose() {
        this.props.close();
    }
    render() {
        return (
            <>
                <Dialog
                    open={this.state.open}
                    onClose={this.handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title" style={{ backgroundColor: '#fef6fb'}}>{"More Detail."}</DialogTitle>
                    <DialogContent style={{ backgroundColor: '#fef6fb'}}>
                        <DialogContentText id="alert-dialog-description">
                            <VerticalChart />
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions style={{ backgroundColor: '#fef6fb'}}>
                        <Button onClick={this.handleClose} color="primary">
                            Disagree
          </Button>
                        <Button onClick={this.handleClose} color="primary" autoFocus>
                            Agree
          </Button>
                    </DialogActions>
                </Dialog>
            </>
        )
    }
}

export default MoreDetail;
