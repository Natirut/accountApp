
import React from 'react';

import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Slide from '@material-ui/core/Slide';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import Snack from '../components/successBar/index.component';
import Error from '../components/errorBar/index.component';

import axios from 'axios';

class Changepw extends React.Component {

    constructor() {
        super();

        this.state = {
            open: false,
            slide: null,
            message: '',
            snack: false,
            error: false,

        }
        this.handleclose = this.handleclose.bind(this);
        this.submit = this.submit.bind(this);
        this.passwordKeyPress = this.passwordKeyPress.bind(this);
    }

    componentDidMount() {
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
    }
    async submit() {
        try {
            const body = {
                username: document.getElementById('username').value,
                password: document.getElementById('password').value,
                newPassword: document.getElementById('newPassword').value,
                email: document.getElementById('email').value,
                tel: document.getElementById('tel').value,
            }
            console.log(body);
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            await instance.patch(`/fae-part/user/changepw`, body);

            this.setState({ snack: true, message: 'Change password success.' })
            setTimeout(() => {
                this.handleclose();
            }, 3000);

        } catch (err) {
            if (err.response.status === 404) {
                this.setState({ message: err.response.data.message, error: true, })
            }

            setTimeout(() => {
                this.setState({ error: false, })
            }, 2000);
        }
    }
    passwordKeyPress(event) {
        // console.log(event.keyCode)
        if (event.keyCode === 13) {
            this.submit();
        }
    }
    handleclose() {
        this.setState({ open: false, })
        this.props.close();
    }
    render() {
        let success; let error;
        if (this.state.snack === true) {
            success = <Snack message={this.state.message} />
        }
        if (this.state.error === true) {
            error = <Error message={this.state.message} />
        }
        return (
            <Dialog open={this.state.open} TransitionComponent={this.state.slide}>
                {success}{error}
                <AppBar style={{ position: 'relative', backgroundColor: 'rgb(16 179 5)', color: 'rgb(34 9 58)', boxShadow: '1px 1px 10px 2px rgb(77 171 123)' }}>
                    <Toolbar>
                        <Typography variant="h6">Update profile</Typography>
                    </Toolbar>
                </AppBar>
                <DialogContent style={{ height: '40%', width: '500px', overflow: 'hidden', }}>
                    <TextField
                        margin="dense"
                        id="username"
                        label="Username"
                        type="email"
                        fullWidth

                    />

                    <TextField
                        margin="dense"
                        id="tel"
                        fullWidth
                        label="Tel."
                        type="text"
                    />

                    <TextField
                        margin="dense"
                        id="email"
                        fullWidth
                        label="Email."
                        type="email"
                    />

                    <TextField
                        margin="dense"
                        id="password"
                        fullWidth
                        label="Old password"
                        type="password"
                    />
                    <TextField
                        margin="dense"
                        id="newPassword"
                        fullWidth
                        label="New password"
                        type="password"
                        onKeyDown={this.passwordKeyPress}
                    />

                    <br /> <br /> <br />
                    <Box textAlign='center'>
                        <Button variant="contained" color="secondary" style={{ backgroundColor: '#bfffbf', color: '#007d00' }} onClick={this.submit}>
                            Update
                    </Button>
                    &nbsp; &nbsp; &nbsp;
                    <Button variant="contained" color="secondary" style={{ backgroundColor: '#b31240', color: '#ffc6d6' }} onClick={this.handleclose}>
                            Close
                    </Button>
                    </Box>

                    <br /> <br /> <br />
                </DialogContent>
            </Dialog>
        )
    }
}

export default Changepw;
