import React from 'react';
import ReactDom from 'react-dom';
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Slide from '@material-ui/core/Slide';
import Button from '@material-ui/core/Button';
import Axios from 'axios';
import Box from '@material-ui/core/Box';
// import DialogRegister from '../Register/index.component';
import Changepw from './updateProfile.component';
import Atp from '../../App';
import CircularProgress from '@material-ui/core/CircularProgress';
import Error from '../components/errorBar/index.component';

class Login extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            slide: null,
            username: "",
            password: "",
            data_user: [],
            page: null,
            open_Re: false, //1,
            role: "",
            changepw: false,
            awaitloading: null,
        }

        this.register_user = this.register_user.bind(this);
        this.SetUser = this.SetUser.bind(this);
        this.SetPass = this.SetPass.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.login_user = this.login_user.bind(this);
        this.close = this.close.bind(this);
        this.passwordKeyPress = this.passwordKeyPress.bind(this);
        this.changePw = this.changePw.bind(this);
    }
    handleClose() {
        this.setState({ open: false, });
    }

    SetUser(event) {
        this.setState({
            username: event.target.value
        });
    }
    SetPass(event) {
        this.setState({
            password: event.target.value
        });
    }
    passwordKeyPress(event) {
        // console.log(event.keyCode)
        if (event.keyCode === 13) {
            this.login_user()
        }
    }
    changePw() {
        this.setState({ changepw: true, })
    }
    componentDidMount() {
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
        this.setState({ awaitloading: '' })
    }

    login_user() {
        const user = {
            username: this.state.username,
            password: this.state.password
        };

        //   let url = process.env.REACT_APP_ENDPOINT+"/fae-part/user/login"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/user/login`
        try {
            this.setState({
                awaitloading: <div style={{
                    position: 'absolute',
                    right: 'calc(5%)',
                }}>
                    <CircularProgress disableShrink style={{ color: 'aqua' }} />
                </div>
            })
            Axios.post(url, user)
                .then(res => {
                     console.log(res.data)

                    // localStorage.setItem('username', res.data.data[0].username);
                    // localStorage.setItem('dept', res.data.data[0].permission[0].dept);
                    // localStorage.setItem('action', res.data.data[0].permission[0].action);
                    // localStorage.setItem('token', res.data.token);
                
                     localStorage.setItem('username', res.data.data[0].username);
                     localStorage.setItem('dept', res.data.data[0].dept);
                     localStorage.setItem('token', res.data.token);

                    this.setState({
                        awaitloading: null,
                    })
                    ReactDom.unmountComponentAtNode(document.getElementById('root'))
                    ReactDom.render(<Atp />, document.getElementById('root'));
                }).catch((err) => {
                     console.log("errrrrrrrrrrrrrrrrrrrrrrr");
                    // if(err.response.status!==undefined){
                      if (err.response.status === 400) {
                        this.setState({ awaitloading: <Error message={err.response.data.message} /> })
                    }   
                    // }
                   
                })
        } catch (err) {
            console.log(err.response)
        }
    }

    register_user() {
        this.setState({ open_Re: true })
    }
    close() {
        this.setState({ open_Re: false, changepw: false, });
    }

    render() {
        let changepw;

        if (this.state.changepw === true) {
            changepw = <Changepw close={this.close} />
        }
        return (
            <>
                {/* {Dialog_register} */}
                {changepw}
                <Dialog open={this.state.open} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#4CAF50', boxShadow: '#006666 1px 2px 3px 1px' }}>
                        <Toolbar>
                            <Typography variant="h6">Login</Typography>
                            <img src={`${process.env.REACT_APP_FILES_PATH}/icons/recycle.png`}
                                alt="recycle"
                                style={{ position: 'absolute', width: '50px', right: 'calc(1%)'}}
                            />
                        </Toolbar>
                    </AppBar>
                    <DialogContent style={{ height: '40%', width: '500px', overflow: 'hidden', }}>
                        <TextField
                            margin="dense"
                            id="user"
                            label="Username"
                            type="email"
                            fullWidth
                            value={this.state.username}
                            onChange={this.SetUser}
                        />
                        <br />  <br />  <br />
                        <TextField
                            margin="dense"
                            id="pass"
                            fullWidth
                            label="Password"
                            type="password"
                            value={this.state.password}
                            onKeyDown={this.passwordKeyPress}
                            onChange={this.SetPass}
                        />

                        <br /> <br /> <br />
                        <Box textAlign='center'>
                            <Button variant="contained" color="secondary" style={{ backgroundColor: '#001247', color: '#bfcfff' }} onClick={this.login_user}>
                                Login
                    </Button>
                    &nbsp; &nbsp; &nbsp;
                    <Button variant="contained" color="secondary" onClick={this.changePw} style={{ backgroundColor: '#361d32' }}>
                                Update Profile
                    </Button>
                        </Box>
                        <div style={{ marginTop: 'calc(2%)'}}>
                        {this.state.awaitloading}
                        </div>
                        <br /> <br /> <br />
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}

export default Login;