
import React from 'react';
// import Snackbar from '@material-ui/core/Snackbar';
import Alert from '@material-ui/lab/Alert';


class Error extends React.Component {

    constructor() {
        super();

        this.state = {
            message: 'Loading...',
            open: true,
        }
        this.handleClose = this.handleClose.bind(this);
    }

    componentDidMount() {
        this.setState({ message: this.props.message });
    }
    handleClose() {
        this.setState({ open: false, })
    }
    render() {
        return (
            <Alert severity="error">{this.state.message}</Alert>
        )
    }
}

export default Error;