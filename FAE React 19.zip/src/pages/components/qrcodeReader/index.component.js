
import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';

import ScannerQR from './qrcodeCamera.component';

class Scanner extends React.Component {

    constructor() {
        super()

        this.state = {
            transition: null,
            open: false,
            qrResult: '',
        }
        this.handleClose = this.handleClose.bind(this);
        this.handleQrScanner = this.handleQrScanner.bind(this);
    }
    componentDidMount() {
        this.setState({
            transition: React.forwardRef(function Transition(props, ref) {
                return <Slide direction="up" ref={ref} {...props} />
            })
        })
        setTimeout(() => {
            this.setState({ open: true });
        }, 200);
    }
    handleQrScanner() {

    }
    handleClose() {
        this.props.callBackClose();

    }
    render() {
        return (
            <>
                <Dialog
                    open={this.state.open}
                    TransitionComponent={this.state.transition}
                    keepMounted
                    onClose={this.handleClose}
                    aria-labelledby="alert-dialog-slide-title"
                    aria-describedby="alert-dialog-slide-description"
                    // style={{ maxWidth: '800px'}}
                >
                    <DialogTitle id="alert-dialog-slide-title" style={{ padding: '10px 400px 10px 20px'}}>{"QR Code scanner"}</DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-slide-description">
                            Scanner
                            <ScannerQR />
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.handleClose} color="primary">
                            Disagree
          </Button>
                        <Button onClick={this.handleClose} color="primary">
                            Agree
          </Button>
                    </DialogActions>
                </Dialog>
            </>
        )
    }
}

export default Scanner;