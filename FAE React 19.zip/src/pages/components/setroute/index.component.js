
import React from 'react';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';

// PROPS CONTEXT

// close=function(datalist)

// data list format
// { step1: ['0138817'],
//   step2:['013818'], ..... 
// }
// data list format

// PROPS CONTEXT


class SetRoute extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            open: false,
            transition: null,
            data: [],
        }
        this.handleClose = this.handleClose.bind(this);
    }

    componentDidMount() {
        this.setState({
            open: true,
            transition: React.forwardRef(function Transition(props, ref) {
                return <Slide direction="up" ref={ref} {...props} />;
            })
        })
    }
    handleClose() {
        this.props.close(this.state.data);
    }
    render() {
        return (
            <Dialog fullScreen open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.transition}>
                <AppBar>
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.handleClose} aria-label="close">
                            <CloseIcon />
                        </IconButton>
                        <Typography variant="h6">
                            Sound
            </Typography>
                        <Button autoFocus color="inherit" onClick={this.handleClose}>
                            save
            </Button>
                    </Toolbar>
                </AppBar>
                <List>
                    <ListItem button>
                        <ListItemText primary="Phone ringtone" secondary="Titania" />
                    </ListItem>
                    <Divider />
                    <ListItem button>
                        <ListItemText primary="Default notification ringtone" secondary="Tethys" />
                    </ListItem>
                </List>
            </Dialog>
        )
    }
}

export default SetRoute;
