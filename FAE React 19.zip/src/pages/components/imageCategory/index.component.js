import React, { Component } from 'react';
// import ReactDOM from 'react-dom';
import Fab from '@material-ui/core/Fab';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';

// PROPS CONTEXT
// images=['imagename1', 'imagename1']
// close=Function

// PROPS CONTEXT
class DemoCarousel extends Component {

    constructor(props) {
        super(props);

        this.state = {
            open: false,
            element: null,
        }
        this.handleClose = this.handleClose.bind(this);
        this.createElementImage = this.createElementImage.bind(this);
    }
    componentDidMount() {
        this.setState({ open: true })
        this.createElementImage();
    }
    createElementImage() {
        // if(this.props.images==='art'){
        console.log("immmm", this.props.images)
        //  }
        this.setState({
            element: this.props.images.map((item) => (
                <>
                    {/* {`${process.env.REACT_APP_FILES_PATH}/files/${item}`} */}
                    {item.slice(-3) !== "jpg" && item.slice(-3) !== "png" ? (
                        <img src="http://cptsvs52t/waste/icons/noimage.png" alt="test" />

                    ) : (
                            <img src={`${process.env.REACT_APP_USERFILE}/${item}`} alt="" />

                        )}
                    {/* <img src={`${process.env.REACT_APP_FILES_PATH}/files/${item}`} alt="" /> */}
                    {/* {item.substring(item.length - 3 , item.length)} */}

                    {item.slice(-3) !== "jpg" && item.slice(-3) !== "png" ? (
                        //   <a  target="_blank" href={`${process.env.REACT_APP_FILES_PATH}/files/${item}`} >Download</a>
                        <Fab color="secondary"  style={{ backgroundColor: '#3287E6' }} >
                            <a rel="noopener noreferrer" target="_blank" href={`${process.env.REACT_APP_USERFILE}/${item}`} > <CloudDownloadIcon style={{color:'white',marginTop:'4px'}}/></a>
                        </Fab>

                    ) : (
                            <></>
                        )}
                </>
            ))
        })
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.cancle();
    }
    render() {
        return (
            <Dialog
                open={this.state.open}
                onClose={this.state.handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>
                    <Carousel infiniteLoop emulateTouch>
                        {this.state.element}
                    </Carousel>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} style={{ backgroundColor: '#1a1b4b', color: 'aliceblue' }}>Close</Button>
                </DialogActions>
            </Dialog>

        );
    }
}

export default DemoCarousel;