import React from 'react'
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
// PROPS CONTEXT
// cancle=    this.setState({ dialogDetail: false, })  
// PROPS CONTEXT

class Comment extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
        }
        this.handleClose = this.handleClose.bind(this);
        console.log("propss", this.props)
    }
    handleClose() {
        this.setState({ open: false })
        setTimeout(() => {
            this.props.cancle()
        }, 200);

    }

    async componentDidMount() {
        // await this.setState({tmp:this.props.data})
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
    }
    render() {
        return (

            <>

                <Dialog
                    fullWidth="true"
                    maxWidth="xs"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >
                    <DialogTitle >FAE Comment</DialogTitle>
                    <DialogContent>
                        <Grid container>
                            <Grid item xs={1}></Grid>
                            <Grid item xs={4} style={{ marginLeft: 'calc(2.6%)' }} >
                                <FormControl variant="outlined" >
                                    <InputLabel id="demo-simple-select-outlined-label">Allow</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="allow"
                                        style={{ width: '150px' }}
                                        // onChange={this.SetProductType}
                                        label="Allow"
                                    >
                                        <MenuItem value={true}>อนุญาตุให้ทิ้ง</MenuItem>
                                        <MenuItem value={false}>ไม่อนุญาตุให้ทิ้ง</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={4} style={{ marginLeft: 'calc(7.5%)' }}>
                                <FormControl variant="outlined" >
                                    <InputLabel id="demo-simple-select-outlined-label">Disposal</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-outlined-label"
                                        id="allow"
                                        style={{ width: '150px' }}
                                        // onChange={this.SetProductType}
                                        label="Disposal"
                                    >
                                        <MenuItem value="เผาทำลาย">เผาทำลาย</MenuItem>
                                        <MenuItem value="รีไซเคิล">รีไซเคิล</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={2}>
                            </Grid>
                        </Grid>
                        <Grid container style={{ marginTop: 'calc(4%)' }}>
                            <Grid item xs={1}>
                            </Grid>
                            <Grid item xs={11} >
                                <TextareaAutosize
                                    rowsMax={3}
                                    rowsMin={3}
                                    aria-label="maximum height"
                                    placeholder="Comment BY FAE"
                                    style = {{width: '90%'}}
                                 />
                            </Grid>
                        
                        </Grid>

                        <Grid container style={{ marginTop: 'calc(4%)' , textAlign: 'center' }}>
                            <Grid item xs={12} >
                            <Button variant="contained" onClick={this.handleClose}  style={{ backgroundColor: '#4dbc82', color: 'white' }}>
                                 Check
                              </Button>
                            </Grid>
                        
                        </Grid>

                    </DialogContent>
                    {/* <DialogActions>
                        <Button color="primary">Check</Button>
                    </DialogActions> */}
                </Dialog>

            </>
        )
    }
}
export default Comment

