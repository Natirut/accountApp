
import React from 'react';
import Webcam from "react-webcam";

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import Slide from '@material-ui/core/Slide';
import ViewImageTaked from '../../components/viewTakedImages/index.component';

import axios from 'axios'


class Capture extends React.Component {
    constructor() {
        super()

        this.state = {
            trasition: null,
            open: false,
            viewTakedImages: false,
            allImage: [],
            images: [],
            countImage: 0,
        }
        this.capture = this.capture.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.ViewImageTaked = this.ViewImageTaked.bind(this);
        this.closeViewDemoImage = this.closeViewDemoImage.bind(this);
        this.Accept = this.Accept.bind(this);
    }
    componentDidMount() {
        this.setState({
            trasition: React.forwardRef(function Transtion(props, ref) {
                return <Slide direction="up" ref={ref} {...props} />
            }),
        });

        this.setState({ open: true });
    }
    ViewImageTaked() {
        this.setState({ viewTakedImages: true, })
    }
    closeViewDemoImage(imageSelectedList) {
        // close view and recieve images on selected.
        this.setState({ viewTakedImages: false, countImage: imageSelectedList.length, allImage: imageSelectedList })
    }
    async Accept() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
            const body = {
                data: this.state.allImage,
            }
            const response = await instance.post(`/fae-part/handler/base64ToImage`, body);
            this.props.close(response.data.data);
        } catch (err) {

        }
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.close();
    }
    capture() {
        var screenshot = this.refs.webcam.getScreenshot();
        const list = this.state.images;
        list.push(screenshot)
        this.setState({
            images: list,
            countImage: this.state.countImage + 1,
            allImage: list,
        })
    }
    render() {
        let viewTakedImages;
        if (this.state.viewTakedImages === true) {
            viewTakedImages = <ViewImageTaked close={this.closeViewDemoImage} data={this.state.images} />
        }
        return (
            <>
                {viewTakedImages}
                <Dialog
                    open={this.state.open}
                    TransitionComponent={this.state.trasition}
                    keepMounted
                    onClose={this.handleClose}
                    aria-labelledby="alert-dialog-slide-title"
                    aria-describedby="alert-dialog-slide-description"
                >
                    <DialogContent>
                        <DialogContentText id="alert-dialog-slide-description">
                            <Webcam
                                audio={false}
                                height={400}
                                ref="webcam"
                                screenshotFormat="image/jpeg"
                                width={500}
                                // videoConstraints={{ facingMode: "user" }}
                            videoConstraints={{ facingMode: { exact: "environment" } }}

                            />
                            {/* <button onClick={this.capture}>Capture photo</button> */}
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <p style={{ color: 'blue' }}>Taked images:
                        <b style={{ fontSize: '20px' }}> &nbsp;{this.state.countImage} &nbsp;</b>
                        images</p>
                        <Button onClick={this.ViewImageTaked} color="primary" style={{
                            position: 'absolute',
                            left: 'calc(1%)',
                            color: 'aliceblue',
                            backgroundColor: '#1565c0'
                        }}>View images</Button>
                        <Button color="primary" onClick={this.Accept} style={{
                            position: 'absolute',
                            left: 'calc(24%)',
                            color: '#1a237e',
                            backgroundColor: '#76ff03',
                            borderRadius: '20px'
                        }}>Accept</Button>
                        <Button onClick={this.capture} color="primary" style={{
                            backgroundColor: '#f06292',
                            color: 'aliceblue',
                            boxShadow: '1px 6px 14px 4px #ff4081'
                        }}>Capture</Button>
                    </DialogActions>
                </Dialog>
            </>
        )
    }
}

export default Capture;
