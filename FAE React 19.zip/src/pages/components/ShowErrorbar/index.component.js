import React from 'react'
import Slide from '@material-ui/core/Slide';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
class RequesterCheck extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
        }
    }
    async componentDidMount() {
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
        setTimeout(() => {
            this.setState({ open: false, })
        }, 2000);
    }
    render() {
        return (
            <>
                <Dialog
                    //  fullWidth="false"
                    //    maxWidth="sm"
                    //  width="20px"
                    open={this.state.open}
                // TransitionComponent={this.state.slide}
                // onClose={this.handleClose}

                >

                    {/* <DialogTitle><center>Loading..</center></DialogTitle> */}
                    <DialogContent style={{backgroundColor:'#fdecea'}}>
                        <Grid container>
                            <Grid item xs={12} style={{ marginTop: 'calc(-10%)' }}>
                                <center>  <Typography variant="subtitle1" gutterBottom style={{fontWeight:'bold'}}>Error</Typography></center>
                            </Grid>
                        </Grid>
                        <Grid container style={{ alignItems: 'center', width: '125px', height: '90px', }} >
                            {/* <Grid item xs={1}>
                            </Grid> */}
                            <Grid item xs={12}>
                            <center>  <ErrorOutlineIcon style={{color:'red',fontSize:'90px'}}/> </center>
                            </Grid>
                            {/* <Grid item xs={1}>
                            </Grid> */}
                        </Grid>
                        <Grid container>
                       
                            <Grid item xs={12}>
                            <center>  <Typography variant="subtitle1" gutterBottom >Do Not Upload</Typography></center>
                            </Grid> 
                         
                        </Grid>
                        <br />

                        {/* <CircularProgressbar value={this.state.percentage} text={`${this.state.percentage}%`} /> */}
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}
export default RequesterCheck

