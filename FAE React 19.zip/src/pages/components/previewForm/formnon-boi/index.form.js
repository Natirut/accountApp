import React from 'react'
import Grid from '@material-ui/core/Grid';
import './style.css'
import Typography from '@material-ui/core/Typography';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import TextField from '@material-ui/core/TextField';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import IconButton from '@material-ui/core/IconButton';
class Nonboi extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            datanonboi:null,
            showhtmltable:null
        }

        this.handleClose = this.handleClose.bind(this);
        this.Tablehtml = this.Tablehtml.bind(this);
        console.log(this.props.data,"PROPP")
    }

    handleClose() {
        this.setState({ open: false })
        setTimeout(() => {
            this.props.cancle()
        }, 200);

    }

    async componentDidMount() {
        // await this.setState({tmp:this.props.data})
        var _ = require('lodash');
        var boi = _.map(this.props.data, function(o) {
            if (o.boiType == "NON BOI") return o;
        });
        boi = _.without(boi, undefined)
 
         await this.setState({datanonboi:boi})
         console.log(this.state.datanonboi)

        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
        this.Tablehtml()
    }
    Tablehtml(){
        this.setState({showhtmltable:this.state.datanonboi.map((item,index) => {
              return(
                  <tr>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{item.matrialCode}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                          <td className="linee ">{index+1}</td>
                  </tr>
              )
        })
    })
    }
    render() {
        return (
            <>
                <Dialog
                    fullWidth="true"
                    maxWidth="lg"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}
                >
                  {/* / <DialogTitle >Preview NON-BOI</DialogTitle> */}
                    <DialogTitle >
                        <Grid container>
                            <Grid item xs={11}>
                            Preview NON-BOI
                           </Grid>
                            <Grid item xs={1} >
                                <IconButton onClick={this.handleClose} component="span">
                                    <HighlightOffIcon style={{color:'red',fontSize:'30px'}} />
                                </IconButton>
                            </Grid>
                        </Grid>
                    </DialogTitle>
                    <DialogContent>
                        <Grid container>
                            <Grid item xs={7}>
                                <Typography variant="button" display="block" gutterBottom><b>Canon</b></Typography>
                                <Typography variant="caption" display="block" gutterBottom>Date ..................&emsp;&emsp;&emsp;Requester ............</Typography>
                                <Typography variant="caption" display="block" gutterBottom>Dept ............&emsp;&emsp;&emsp;Div ...........&emsp;&emsp;&emsp;Tel No ............</Typography>
                            </Grid>
                            <Grid item xs={5}>
                                <table className="linee">
                                    <tr >
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>APPROVED BY</b></Typography></center></td>
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>CHECKED BY</b></Typography></center></td>
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>PREPARED BY</b></Typography></center></td>
                                    </tr>
                                    <tr >
                                        <td className="linee"><br /><br /></td>
                                        <td className="linee"><br /><br /></td>
                                        <td className="linee"><br /><br /></td>
                                    </tr>
                                    <tr >
                                        <td className="linee"><Typography variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee"><Typography variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee"><Typography variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                    </tr>
                                </table>
                            </Grid>
                        </Grid>

                        <Grid container style={{ marginTop: 'calc(3%)' }}>
                            <Grid item xs={3}>
                                <TextField style={{ width: '90%' }} size="small" id="outlined-basic" label="CPT Main Type" variant="outlined" />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField style={{ width: '90%' }} size="small" id="outlined-basic" label="Waste Type" variant="outlined" />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField style={{ width: '90%' }} size="small" id="outlined-basic" label="BOI Type" variant="outlined" />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField style={{ width: '90%' }} size="small" id="outlined-basic" label="Parst Normal Type" variant="outlined" />
                            </Grid>


                        </Grid>


                        <Grid container style={{ marginTop: 'calc(3%)' }}>
                            <table className="linee " width="100%" >
                                <tr>
                                    <td className="linee " colspan="12" >REQUEST FORM FOR SCRAP IN CASE PARTS NON-BOI AND NOT PART</td>
                                </tr>
                                <tr>
                                    <td className="linee " rowspan="2"  >No.</td>
                                    <td className="linee " rowspan="2"   >Part no./Asset no.</td>
                                    <td className="linee " rowspan="2"  >Discription</td>
                                    <td className="linee " colspan="7"  >Meterial Type</td>
                                    <td className="linee " rowspan="2"  >Q'TY(Psc.)</td>
                                    <td className="linee " rowspan="2"   >Total Weight(kg.)</td>
                                </tr>

                                <tr>
                                    <td className="linee verticalTableHeader"   >Plastic</td>
                                    <td className="linee verticalTableHeader"   >Aluminium</td>
                                    <td className="linee verticalTableHeader"   >Metal</td>
                                    <td className="linee verticalTableHeader"  >Glass</td>
                                    <td className="linee verticalTableHeader"  >Paper</td>
                                    <td className="linee verticalTableHeader"   >Wood</td>
                                    <td className="linee verticalTableHeader"  >Others(Spacific)</td>
                                </tr>
                             
                                {this.state.showhtmltable}
                            </table>

                        </Grid>

                        <Grid container style={{ marginTop: 'calc(10%)' }} >
                            <Grid item xs={12}>
                                <table style={{ width: '99.2%' }} className="linee">
                                    <tr>
                                        <td style={{ textAlign: 'center' }} className="linee " rowspan="4"><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>ITC Confirm</Typography></td>
                                        <td style={{ textAlign: 'center' }} className="linee " colspan="6" ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>NOT PART</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="6"   >

                                            <Typography variant="caption" display="block" gutterBottom>BOIAsset&emsp;:&emsp;....................................................items&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Q'ty:..........................pcs</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="6"   >
                                            {/* <Checkbox color="secondary" /> */}
                                            <Typography variant="caption" display="block" gutterBottom>Non BOIAsset&emsp;:&emsp;....................................................items&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Q'ty:..........................pcs</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="6"   >
                                            {/* <Checkbox color="secondary" /> */}
                                            <Typography variant="caption" display="block" gutterBottom>Other&emsp;:&emsp;....................................................items&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Q'ty:..........................pcs</Typography></td>

                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="2"   ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>1) PDC</Typography></td>
                                        <td className="linee " colspan="2"  ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>2) ITC</Typography></td>
                                        <td className="linee " colspan='3'  ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>3) FAE</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee "     ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>CHECKED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>SENT BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>APPROVED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>CHECKED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>APPROVE BY:</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>CHECKED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>PREPARED BY</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee "     ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                    </tr>
                                    <tr>
                                        <td className="linee "     ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                    </tr>
                                </table>
                            </Grid>
                        </Grid>




                    </DialogContent>
                    <DialogActions>
                        {/* <Button color="primary">UPDATE</Button> */}
                    </DialogActions>
                </Dialog>

            </>
        )
    }
}
export default Nonboi

