import React from 'react'
import Grid from '@material-ui/core/Grid';
import './style.css'
import Typography from '@material-ui/core/Typography';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import DataTable from '../../datatable/index.component';
import TextField from '@material-ui/core/TextField';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import IconButton from '@material-ui/core/IconButton';
import Pdf from "react-to-pdf";
const ref = React.createRef();
// import Typography from '@material-ui/core/Typography';
class Boi extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            databoi: null,
            showhtmltable: null
        }

        this.handleClose = this.handleClose.bind(this);
        this.setfilterData = this.setfilterData.bind(this);

        console.log(this.props.data, "PROPP")
    }

    rowData() {
        const column = [
            { field: 'no', title: <b>No</b>, align: 'center' },
            { field: 'partno', title: <b>PartNo</b>, align: 'center' },
            { field: 'group', title: <b>Group</b>, align: 'center' },
            { field: 'common', title: <b>Common</b>, align: 'center' },
            { field: 'unit', title: <b>Unit</b>, align: 'center' },
            { field: 'partname', title: <b>PartName</b>, align: 'center' },
            { field: 'sumofqty', title: <b>SumOfQ'ty</b>, align: 'center' },
            { field: 'sumofqty2', title: <b>SumOfQty</b>, align: 'center' },
            { field: 'unit2', title: <b>Unit</b>, align: 'center' },
            { field: 'sumreweight', title: <b>SumOfReweight</b>, align: 'center' },
            { field: 'unitkg', title: <b>Unit(Kg./g)</b>, align: 'center' },
            { field: 'matarial', title: <b>MatarialType</b>, align: 'center' },
            { field: 'note', title: <b>Note</b>, align: 'center' },
        ]
        const row = [];
        for (const item of this.state.databoi) {
            // row.push
        }
    }

    handleClose() {
        this.setState({ open: false })
        setTimeout(() => {
            this.props.cancle()
        }, 200);

    }

    async setfilterData() {
        var _ = require('lodash');
        var boi = _.map(this.props.data, function (o) {
            if (o.boiType == "BOI") return o;
        });
        boi = _.without(boi, undefined)

        await this.setState({ databoi: boi })
        console.log(this.state.databoi)
    }
    async componentDidMount() {
        await this.setfilterData()
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
        this.Tablehtml()
    }
    Tablehtml() {
        // let rows = [];
        // // console.log(this.state.databoi.length)
        // for( var i = 0;i<this.state.databoi.length;i++){
        //     console.log(this.state.databoi.length)
        //     let rowID = `row${i}`
        //     let cell = []
        //     for (var idx = 0; idx <this.state.databoi.length; idx++){
        //         cell.push(<td >{this.state.databoi.boiType}</td>)
        //       }
        //       rows.push(<tr key={i} id={rowID}>{cell}</tr>)

        // }  
        this.setState({
            showhtmltable: this.state.databoi.map((item, index) => {
                //  if (index > 0) { 
                return (
                    <tr>
                        <td className="linee ">{index + 1}</td>
                        <td className="linee ">{item.matrialCode}</td>
                        <td className="linee ">{item.groupBoiName}</td>
                        <td className="linee ">{item.unit}</td>
                        <td className="linee ">{item.matrialName}</td>
                        <td className="linee ">{item.lotNo}</td>
                        <td className="linee ">{item.matrialName}</td>
                        <td className="linee ">{item.qtyOfContainer}</td>
                        <td className="linee ">{item.qtyOfContainer}</td>
                        <td className="linee ">{item.totalWeight}</td>
                        <td className="linee ">{item.unitPrice}</td>
                        <td className="linee ">{item.lotNo}</td>
                        <td className="linee ">{item.matrialName}</td>
                    </tr>
                )
                //   }
            })
        })
    }
    render() {
        return (
            <>
                <Dialog
                    fullWidth="true"
                    maxWidth="lg"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >

                    <DialogTitle >
                        <Grid container>
                            <Grid item xs={11}>
                                Preview BOI
                           </Grid>
                            <Grid item xs={1} >
                                <IconButton onClick={this.handleClose} component="span">
                                    <HighlightOffIcon style={{color:'red',fontSize:'30px'}} />
                                </IconButton>
                            </Grid>
                        </Grid>
                    </DialogTitle>
                    <DialogContent>

                        <Grid container style={{ marginTop: 'calc(3%)' ,width:'210mm',height: '297mm' }} ref={ref}  >
                            <table className="linee " width="100%" >
                                <tr>
                                    <td className="linee " colspan="13" ><Typography style={{ backgroundColor: '#2b6cc0', color: 'white', textAlign: 'center', fontWeight: 'bold', fontSize: '15px' }} variant="caption" display="block" gutterBottom>REQUEST  FORM  FOR  SCRAP  PART  IN  CASE  BOI <br /> LOT NO.... BOI SCRAP PARTS</Typography></td>
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>DATA BASE FROM :  DEFECT SLIP(PDC)  BOI MML(ITC)</Typography></td>
                                    <td className="linee " colspan="6" rowspan="8" align="center">
                                        <table className="linee" width="80%" >
                                            <tr >
                                                <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>APPROVED BY</b></Typography></center></td>
                                                <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>CHECKED BY</b></Typography></center></td>
                                                <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>PREPARED BY</b></Typography></center></td>
                                            </tr>
                                            <tr >
                                                <td className="linee"><br /><br /><br /><br /><br /><br /></td>
                                                <td className="linee"><br /><br /><br /><br /><br /><br /></td>
                                                <td className="linee"><br /><br /><br /><br /><br /><br /></td>
                                            </tr>

                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="linee ">&nbsp;&nbsp;</td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>SUPPORT DATE :</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>DEPARTMENT :</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>TOTAL DEFECT SLIP: 5 SLIP :</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>TOTAL PART ITEMS : 5 ITEMS</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>TOTAL UNIT ITEMS : 10 UNIT</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>TOTAL BOI GROUP : 15 GROUP</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee "></td>
                                    <td className="linee " colspan="6"><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>LOT NO : 8 LOTS</Typography></td>
                                    {/* <td className="linee " colspan="6"></td> */}
                                </tr>
                                <tr>
                                    <td className="linee " colspan="13"><br /></td>
                                </tr>
                                <tr>
                                    <td className="linee " colspan="7"><Typography style={{ backgroundColor: '#2b6cc0', color: 'white', textAlign: 'center', fontWeight: 'bold', fontSize: '13px' }} variant="caption" display="block" gutterBottom>MACRO DATA FROM DEFECT SLIP</Typography></td>
                                    <td className="linee " colspan="6"><Typography style={{ textAlign: 'center', fontWeight: 'bold', fontSize: '13px' }} variant="caption" display="block" gutterBottom>RECONFIRM FROM REQUESTER</Typography></td>
                                </tr>
                                <tr>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>No.</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Part No.</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Group</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Common</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Unit</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Part Name</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Sum of Q'ty</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Sum of Qty</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Unit</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Sum of  Reweight</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Unit(Kg./g)</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Material Type</Typography></td>
                                    <td className="linee " ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Note</Typography></td>
                                </tr>

                                {this.state.showhtmltable}
                            </table>

                        </Grid>
                    </DialogContent>
                    <DialogActions>
                        {/* <Button color="primary">UPDATE</Button> */}
                        <Pdf targetRef={ref} filename="code-example.pdf">
                    {({ toPdf }) => <button onClick={toPdf}>Generate Pdf</button>}
                </Pdf>
                    </DialogActions>
                </Dialog>

            </>
        )
    }
}
export default Boi

