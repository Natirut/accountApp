import React from 'react'
// import 'fontsource-roboto';
import PrintIcon from '@material-ui/icons/Print';
import './index.css';
import Grid from '@material-ui/core/Grid';
// import Typography from '@material-ui/core/Typography';
import Dialog from '@material-ui/core/Dialog';
// import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
// import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
// import DataTable from '../../datatable/index.component';
// import TextField from '@material-ui/core/TextField';
// import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import IconButton from '@material-ui/core/IconButton';
import Paper from '@material-ui/core/Paper';
// import ReactPDF from '@react-pdf/renderer';
// import ReactDOM from 'react-dom';
// import { PDFViewer } from '@react-pdf/renderer';
import Pdf from "react-to-pdf";
import { jsPDF } from "jspdf";
import html2canvas from 'html2canvas';
// import Button from '@material-ui/core/Button';
// import {html2canvas, jsPDF} from 'app/ext';
import { Font } from '@react-pdf/renderer';
// import { PDFDownloadLink } from "@react-pdf/renderer";
import { Table, TableCell, TableBody, DataTableCell, TableHeader, } from '@david.kucsai/react-pdf-table';
import { Page, Text, View, Document, StyleSheet } from '@react-pdf/renderer';
// import Typography from '@material-ui/core/Typography';
class ACC extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,

        }
        this.handleClose = this.handleClose.bind(this);



    }
    printDocument() {
        const input = document.getElementById('divToPrint');
        html2canvas(input)
            .then((canvas) => {
                const imgData = canvas.toDataURL('image/png');
                const pdf = new jsPDF();
                pdf.addImage(imgData, 'JPEG', 0, 0);
                // pdf.output('dataurlnewwindow');

                // pdf.addFileToVFS('Roboto-Regular.ttf', Roboto-Regular);
                // pdf.addFont('Roboto-Regular.ttf', 'Roboto-Regular', 'normal')
                // pdf.setFont('Roboto-Regular');

                // pdf.addFileToVFS('Roboto-Regular.ttf', <PlexFont />);
                // pdf.addFont('Roboto-Regular.ttf', 'PlexFont', 'normal')
                // pdf.setFont('PlexFont');

                // pdf.addFileToVFS('Roboto-Regular.ttf', yanone);
                // pdf.addFont('Roboto-Regular.ttf', 'Roboto', 'normal');
                // pdf.setFont('Roboto');  
                // pdf.text("ทดสอบ", 100, 100);
                // add the font to jsPDF
                // pdf.addFont("Roboto-Regular.ttf", "Roboto", "normal");
                // pdf.setFont("Roboto");

                pdf.save("download.pdf");
            })
            ;
    }
    handleClose() {
        this.setState({ open: false })
        setTimeout(() => {
            // this.props.cancle()
        }, 200);

    }
    async componentDidMount() {
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
    }
    test() {
        // var doc = new jsPDF();
        // doc.fromHTML(ReactDOMServer.renderToStaticMarkup(this.render()));
        // doc.save("myDocument.pdf");
    }
    render() {
        const ref = React.createRef();
        Font.register({
            family: 'Roboto-Regular',
            src: './public/Roboto-Regular.ttf'
        });
        const styles = StyleSheet.create({
            page: {
                flexDirection: 'row',
                backgroundColor: '#E4E4E4'
            },
            section: {
                margin: 10,
                padding: 10,
                flexGrow: 1
            },
            text: {
                fontFamily: 'Roboto-Regular'
            },
            title: {
                fontFamily: 'Roboto-Regular'
            }
        });

        const MyDoc = () => (
            <Document>
                <Page size="A4" style={styles.page}>
                    <View style={styles.section}>
                        <Text>สำหรับลูกค้า</Text>
                    </View>
                    <View style={styles.section}>
                        <Text>Section #2</Text>
                    </View>
                    <View style={styles.section}>
                        <Text>Section #2</Text>
                    </View>
                    <View style={styles.section}>
                        <Text>Section #2</Text>
                    </View>
                </Page>
                <Page>
                    <Table
                        data={[
                            { firstName: "John", lastName: "Smith", dob: new Date(2000, 1, 1), country: "Australia", phoneNumber: "xxx-0000-0000" }
                        ]}
                    >
                        <TableHeader>
                            <TableCell>
                                First Name
                        </TableCell>
                            <TableCell>
                                Last Name
                        </TableCell>
                            <TableCell>
                                DOB
                        </TableCell>
                            <TableCell>
                                Country
                        </TableCell>
                            <TableCell>
                                Phone Number
                        </TableCell>
                        </TableHeader>
                        <TableBody>
                            <DataTableCell getContent={(r) => r.firstName} />
                            <DataTableCell getContent={(r) => r.lastName} />
                            <DataTableCell getContent={(r) => r.dob.toLocaleString()} />
                            <DataTableCell getContent={(r) => r.country} />
                            <DataTableCell getContent={(r) => r.phoneNumber} />
                        </TableBody>
                    </Table>
                </Page>
            </Document>

        );
        return (
            <>
                <Dialog
                    // fullWidth="true"
                    // maxWidth="mg"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >
                    {/* 
                    <DialogTitle >
                        <Grid container>
                            <Grid item xs={11}>
                                Preview BOI
                           </Grid>
                            <Grid item xs={1} >
                            </Grid>
                        </Grid>
                    </DialogTitle> */}
                    <DialogContent style={{ width: '210mm', height: '297mm' }}  >
                        <div>
                            {/* <div className="mb5">
                                <button onClick={this.printDocument}>Print</button>
                            </div> */}
                            {/* <div id="divToPrint" className="mt4" style= {{
        backgroundColor: '#f5f5f5',
        width: '210mm',
        minHeight: '297mm',
        marginLeft: 'auto',
        marginRight: 'auto'
      }}>
        <div>Note: Here the dimensions of div are same as A4</div> 
        <div>You Can add any component here</div>
      </div> */}
                        </div>
                        {/* HEAD */}
                        {/* <PDFDownloadLink document={<TTT />} fileName="fee_acceptance.pdf">
  {({ blob, url, loading, error }) => (loading ? 'Loading document...' : 'Download now!')}
</PDFDownloadLink> */}
                        {/* <PDFDownloadLink document={<MyDoc />} fileName="somename.pdf">
                            {({ blob, url, loading, error }) => (loading ? 'Loading document...' : 'Download now!')}
                        </PDFDownloadLink> */}

                        <Grid container>
                            <Grid item xs={10}>

                            </Grid>
                            <Grid item xs={1}>
                              {/* <IconButton onClick={this.printDocument} color="secondary" aria-label="upload picture" component="span">
                                            <PrintIcon />
                              </IconButton> */}
                            </Grid>
                            <Grid item xs={1} >
                                <Pdf targetRef={ref} filename="code-example.pdf">
                                    {({ toPdf }) =>
                                        // <button onClick={toPdf}>Generate Pdf</button>
                                        <IconButton onClick={toPdf} color="primary" aria-label="upload picture" component="span">
                                            <PrintIcon />
                                        </IconButton>
                                    }
                                </Pdf>
                            </Grid>
                            {/* <PDFViewer>
    <MyDoc />
  </PDFViewer> */}


                        </Grid>
                        <Grid ref={ref} id="divToPrint" style={{ paddingLeft: 'calc(4%)', paddingTop: 'calc(3%)' }} >
                            <Grid container>
                                <Grid item xs={6}>
                                    <span style={{ fontSize: '20px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        Canon
                                   </span>
                                    <hr />
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={6}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }}>
                                        บริษัท แคนนอน ปราจีนบุรี (ประเทศไทย) จำกัด<br />
                              Canon Prachinburi (Thailand) Ltd.
                           </span>
                                    <hr />
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={6}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        550  Moo  7  T.Thatoom A.Srimahaphote<br />
                              เลขที่ 550 หมู่ที่ 7 ตำบล ท่าตูม อำเภอ ศรีมหาโพธิ
                           </span>
                                    <hr />
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={6}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        Prachinburi  25140, Thailand <br />
                           จังหวัดปราจีนบุรี 25140 ประเทศไทย  สำนักงานใหญ่
                           </span>
                                    <hr />
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={6}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        โทรศัพท์ +66-372-84500  Phone +66-372-84500
                           </span>
                                    <hr />
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={6}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        เลขประจำตัวผู้เสียภาษี 0145554002624  Tax ID. 0145554002624
                           </span>
                                    <hr />
                                </Grid>
                            </Grid>

                            <Grid container >
                                <Grid item xs={12}>
                                    <center><span style={{ fontSize: '20px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        TAX INVOICE / INVOICE
                           </span></center>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={12} style={{ alignItems: 'center' }}>
                                    <center><span style={{ fontSize: '15px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        ต้นฉบับใบกำกับภาษี / ต้นฉบับใบแจ้งหนี้
                           </span></center>
                                </Grid>
                            </Grid>

                            {/* MIDDLE */}
                            <Grid container>
                                <Grid item xs={8}>
                                    <Paper variant="outlined" style={{ borderColor: '#000', borderRadius: '24px', padding: '20px' }} >
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            ชื่อลูกค้า CUSTOMER NAME: <b>บริษัท สยามโพลี(ไทยแลนด์) จำกัด</b> <br />
                                        </span>
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            ที่อยู่ ADDRESS: <b>เลขที่ 40 ซ.ประวิทย์และเพื่อน 5 ถ.สุขุมวิท 103 แขวนบางจาก เขตพระโขนง กรุงเทพมหานคร 10260 01055400044902 สำนักงานใหญ่</b> <br /> <br /> <br />
                                        </span>
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            อ้างอิง ATTN: <b>นายดวงดี มหาอิด</b> <br />
                                        </span>
                                        <br />
                                    </Paper>
                                </Grid>
                                <Grid item xs={4}>
                                    <Paper variant="outlined" style={{ borderColor: 'white', borderRadius: '20px', padding: '20px' }} >
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            INVOICE NO:<b>CPT2021-0080</b> <br />
                                      เลขที่ใบกำกับภาษี
                                   </span>
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            INVOICE DATE:<b>31-Mar-2021</b> <br />
                                      วันที่
                                   </span>
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            TERMS OF PAYMENT:<b>Credit 30 days</b> <br />
                                       เงื่อนไขการชำระเงิน
                                   </span>
                                        <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            DUE DATE:<b>31-Apr-2021</b> <br />
                                       วันครบกำหนด
                                   </span>
                                    </Paper>
                                </Grid>
                            </Grid>

                            {/* DIS */}
                            <Grid container>
                                <Grid item xs={8}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        CUSTOMER CODE / รหัสลูกค้า :<b>FS030ZZ</b> <br />
                                    </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={8}>
                                    <span style={{ fontSize: '11px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        P/O No. / เลขที่ใบสั่งซื้อของลูกค้า:<b>12345678</b> <br />
                                    </span>
                                </Grid>
                            </Grid>



                            {/* TABLE */}
                            <table border="1" className="linee "  >
                                <tr>
                                    <th className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            ITEM NO.<br />ลำดับที่
                                   </span>

                                    </th>
                                    <th className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            DESCRIPTIONS<br />รายการ
                                   </span>
                                    </th>
                                    <th className="linee " >
                                        <spanp style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            QUANTITY<br />จำนวน
                                   </spanp>

                                    </th>
                                    <th className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            UNIT<br />หน่วย
                                   </span>
                                    </th>
                                    <th className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            UNIT PRICE(THB)<br />ราคาต่อหน่วย(บาท)
                                   </span>
                                    </th>
                                    <th className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            Amount(THB)<br />จำนวนเงินบาท
                                   </span>

                                    </th>
                                </tr>
                                <tr>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            <center>1</center>
                                        </span>
                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            Stainless Steel Turning Scrap
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            189.00
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            KG
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            5.00
                                 </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            945.00
                                 </span>

                                    </td>
                                </tr>
                                <tr>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            <center>2</center>
                                        </span>
                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            Brass Scrap Turning Scrap
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            350.00
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            KG
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            5.00
                                 </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            1705.00
                                 </span>

                                    </td>
                                </tr>
                                <tr>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            SUB TOTAL จำนวนเงิน
                                </span>
                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            3398.00
                                </span>

                                    </td>
                                </tr>
                                <tr>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            VAT 7% ภาษีมูลค่าเพิ่ม
                                </span>

                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            237.86
                                </span>

                                    </td>
                                </tr>
                                <tr>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " ></td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            GRAND TOTAL จำนวนเงินรวมทั้งสิ้น
                                </span>
                                    </td>
                                    <td className="linee " >
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            3652.00
                                </span>

                                    </td>
                                </tr>
                                <tr>
                                    <td className="linee " colSpan={6}>
                                        <span style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                            AMOUNT จำนวนเงินตัวอักษร  สามพันหกร้อยสามสิบบาทถ้วน
                                </span>
                                    </td>
                                </tr>

                            </table>
<br/>
                            <Grid container>
                                <Grid item xs={8}>
                                    <span style={{ fontSize: '12px', marginTop: 'calc(4%)', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        REMARK / หมายเหตุ :
                                </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={8}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        IMPORTANT CONDITION / เงื่อนไข
                                </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={12}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        1. PAY BY CHEQUE OR DRAFT. PLEASE ISSUE PAYEE ONLY TO "CANON PRACHINBURI (THAILAND) LTD.
                                </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={12}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        2. PAY BY TRANSFER BANK "SIAM COMMERCIAL BANK"  Account No.849-2482662
                                </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={12}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        1.เมื่อชำระด้วยเช็ค ดร๊าฟ โปรดสั่งจ่ายในนาม บริษัท แคนนอน ปราจีนบุรี (ประเทศไทย) จำกัด ขีดฆ่าคำว่า "หรือผู้ถือ" และขีดคร่อมเช็คด้วย
                             </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={12}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        2.เมื่อชำระด้วยการโอนเงิน โปรดโอนผ่านธนาคารไทยพาณิชย์ เลขที่บัญชี 849-2482662
                             </span>
                                </Grid>
                            </Grid>


                            {/* SING */}
                            <br/>
                            <Grid container>
                                <Grid item xs={8}></Grid>
                                <Grid item xs={4}>

                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        <hr/>
                                        <center>Sign / ลงชื่อ</center>
                                    </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={8}></Grid>
                                <Grid item xs={4}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        Date/วันที่
                             </span>
                                </Grid>
                            </Grid>
                            <Grid container>
                                <Grid item xs={8}></Grid>
                                <Grid item xs={4}>
                                    <span style={{ fontSize: '12px', fontFamily: 'Arial, Helvetica, sans-serif' }} >
                                        <center> HIDEAKI  TAKATORI<br />
                               General Manager<br />
                               Personnel And General Affairs Div.<br />
                               Canon Prachinburi (Thailand) Ltd.
                               </center>
                                    </span>
                                </Grid>
                            </Grid>
                        </Grid>

                    </DialogContent>

                </Dialog>

            </>
        )
    }
}
export default ACC

