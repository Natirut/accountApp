import React from 'react'
import Grid from '@material-ui/core/Grid';
import './style.css'
import Typography from '@material-ui/core/Typography';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import DataTable from '../../components/datatable/index.component';
class Previewimo extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
        }

        this.handleClose = this.handleClose.bind(this);


    }

    handleClose() {
        this.setState({ open: false })
        setTimeout(() => {
            this.props.cancle()
        }, 200);

    }

    async componentDidMount() {
        // await this.setState({tmp:this.props.data})

        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
    }
    render() {
        return (
            <>
                <Dialog
                    fullWidth="true"
                    maxWidth="lg"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >

                    <DialogTitle >Detail2</DialogTitle>
                    <DialogContent>
                        <Grid container>
                            <Grid item xs={7}>
                                <Typography variant="button" display="block" gutterBottom><b>Canon</b></Typography>
                                <Typography variant="caption" display="block" gutterBottom>Date ..................&emsp;&emsp;&emsp;Requester ............</Typography>
                                <Typography variant="caption" display="block" gutterBottom>Dept ............&emsp;&emsp;&emsp;Div ...........&emsp;&emsp;&emsp;Tel No ............</Typography>
                            </Grid>
                            <Grid item xs={5}>
                                <table className="linee">
                                    <tr >
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>APPROVED BY</b></Typography></center></td>
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>CHECKED BY</b></Typography></center></td>
                                        <td className="linee" style={{ padding: '3px' }}><center><Typography variant="button" display="block" ><b>PREPARED BY</b></Typography></center></td>
                                    </tr>
                                    <tr >
                                        <td className="linee"><br /><br /></td>
                                        <td className="linee"><br /><br /></td>
                                        <td className="linee"><br /><br /></td>
                                    </tr>
                                    <tr >
                                        <td className="linee"><Typography variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee"><Typography variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee"><Typography variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                    </tr>
                                </table>
                            </Grid>
                        </Grid>
                        <Grid container style={{ marginTop: 'calc(30%)' }} >
                            <Grid item xs={12}>
                                <table style={{ width: '99.2%' }} className="linee">
                                    <tr>
                                        <td style={{ textAlign: 'center' }} className="linee " rowspan="4"><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>ITC Confirm</Typography></td>
                                        <td style={{ textAlign: 'center' }} className="linee " colspan="6" ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>NOT PART</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="6"   >

                                            <Typography variant="caption" display="block" gutterBottom>BOIAsset&emsp;:&emsp;....................................................items&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Q'ty:..........................pcs</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="6"   >
                                            {/* <Checkbox color="secondary" /> */}
                                            <Typography variant="caption" display="block" gutterBottom>Non BOIAsset&emsp;:&emsp;....................................................items&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Q'ty:..........................pcs</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="6"   >
                                            {/* <Checkbox color="secondary" /> */}
                                            <Typography variant="caption" display="block" gutterBottom>Other&emsp;:&emsp;....................................................items&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Q'ty:..........................pcs</Typography></td>

                                    </tr>
                                    <tr>
                                        <td className="linee " colspan="2"   ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>1) PDC</Typography></td>
                                        <td className="linee " colspan="2"  ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>2) ITC</Typography></td>
                                        <td className="linee " colspan='3'  ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>3) FAE</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee "     ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>CHECKED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>SENT BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>APPROVED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>CHECKED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>APPROVE BY:</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>CHECKED BY</Typography></td>
                                        <td className="linee "    ><Typography style={{ textAlign: 'center', fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>PREPARED BY</Typography></td>
                                    </tr>
                                    <tr>
                                        <td className="linee "     ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                        <td className="linee "    ><br /><br /></td>
                                    </tr>
                                    <tr>
                                        <td className="linee "     ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                        <td className="linee "    ><Typography style={{ fontWeight: 'bold' }} variant="caption" display="block" gutterBottom>Date :</Typography></td>
                                    </tr>
                                </table>
                            </Grid>
                        </Grid>




                    </DialogContent>
                    <DialogActions>
                        {/* <Button color="primary">UPDATE</Button> */}
                    </DialogActions>
                </Dialog>

            </>
        )
    }
}
export default Previewimo

