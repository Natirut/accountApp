import Slide from '@material-ui/core/Slide';
import React from 'react';
import Snackbar from '@material-ui/core/Snackbar';
import './style.css';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
class Success extends React.Component {

    constructor() {
        super();

        this.state = {
            message: 'Loading...',
            open: false,
            transition: null,
        }
        this.handleClose = this.handleClose.bind(this);
    }

    componentDidMount() {
        this.setState({ open: true, })
        this.setState({ message: this.props.message });
        this.setState({
            trasition: React.forwardRef(function Transtion(props, ref) {
                return <Slide direction="right" ref={ref} {...props} />
            }),
        });
    }
    componentWillUnmount() {
        this.setState({ open: false, });
    }
    handleClose() {
        this.setState({ open: false, })
    }
    render() {
        return (
            <Snackbar
               
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                open={this.state.open}
                TransitionComponent={(props) => <><Slide direction="up" {...props} /></>}
                onClose={this.handleClose}
                message={this.state.message}
                action={
                    <div>
                        <CheckCircleOutlineIcon /> 
                    </div>
                }
            />  
        )
    }
}

export default Success;