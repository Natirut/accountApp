import React from 'react'
import Slide from '@material-ui/core/Slide';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
// import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import {
    CircularProgressbar,
    buildStyles
  } from "react-circular-progressbar";
import ChangingProgressProvider from "./ChangingProgressProvider";
class Loading extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            percentage: 100
        }
    }
    async componentDidMount() {
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
        setTimeout(() => {
            this.setState({ open: false, })
        }, 2000);
    }
    render() {
        const percentage = 66;
        return (
            <>
                <Dialog
                    //  fullWidth="false"
                    //    maxWidth="sm"
                    //  width="20px"
                    open={this.state.open}
                // TransitionComponent={this.state.slide}
                // onClose={this.handleClose}

                >

                    {/* <DialogTitle><center>Loading..</center></DialogTitle> */}
                    <DialogContent style={{backgroundColor:'#edf7ed'}}>
                        <Grid container>
                        <Grid item xs = {12} style={{marginTop:'calc(-10%)'}}>
                        <center>  <Typography  variant="subtitle1" gutterBottom>Loading..</Typography></center>
                            </Grid>
                        </Grid>
                        <Grid container style={{alignItems:'center',width:'125px',height:'90px',}} >
                        <Grid item xs = {1}>
                            </Grid>
                            <Grid item xs = {10}>
                                <ChangingProgressProvider values={[0, 100]}>
                                    {percentage => (
                                        <CircularProgressbar
                                            // background
                                            value={percentage}
                                            text={`${percentage}%`}
                                            styles={buildStyles({
                                                textSize: "14px",
                                             
                                                pathTransition:
                                                    percentage === 0 ? "none" : "stroke-dashoffset 0.5s ease 0s"
                                            })}
                                        />
                                    )}
                                </ChangingProgressProvider>
                            </Grid>
                            <Grid item xs = {1}>
                            </Grid>
                        </Grid>
                        <br/>
                    
                        {/* <CircularProgressbar value={this.state.percentage} text={`${this.state.percentage}%`} /> */}
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}
export default Loading
