

import React from 'react';
import Grid from '@material-ui/core/Grid';

import Summary from './summary/index.component';
import TabPrepare from './Waste/TabMenuPrepared';
import TabCheck from './Waste/TabMenuCheck';
import TabApprove from './Waste/TabMenuApprove';
import Manage from './Manage/index.component'
import Login from './Login/index.component'
import Register from './Register/index.component'
import Home from './home/index.component';
import History from './History/index.component';

import Invoiceprepared from './invoice/prepare/index.component';
import InvoiceCheck from './invoice/check/index.component';
import InvoiceApprove from './invoice/approve/index.component';
import MakingApprove from './invoice/makingApprove/index.component';
// import RequesterInput from './Requester/index.component';

import RequesterPrepare from './Requester/Menu/prepare';
import RequesterCheck from './Requester/Menu/check';
import RequesterApprove from './Requester/Menu/approve';
import RequesterHistory from './Requester/Menu/history/index.component';
import RequesterformA from './Requester/Menu/showformA';

import ACCPrepared from './Account/Menu/prepared';
import ACCCheck from './Account/Menu/check';
import ACCApprove from './Account/Menu/approve';
import PDCCheck from './PDC/check';
import PDCApprove from './PDC/approve';
import ITCCheck from './setRoute/itc/check.component';
import ITCApprove from './setRoute/itc/approve.component';
import InvoicePDF from './components/previewForm/Accform/index.form';
class Main extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            page: null,
        }
    }

    componentDidMount() {
        this.setState({ open_login: true })
        if (this.props.page === 'summary') {
            this.setState({ page: <Summary /> })
        } else if (this.props.page === 'recycle') {
            this.setState({ page: <TabPrepare /> })
        } else if (this.props.page === 'home') {
            this.setState({ page: <Home /> });
        }
        else if (this.props.page === 'manage') {
            this.setState({ page: <Manage /> });
        }
        else if (this.props.page === 'login') {
            this.setState({ page: <Login /> });
        }
        else if (this.props.page === 'register') {
            this.setState({ page: <Register /> });
        }
        else if (this.props.page === 'faeCheck') {
            this.setState({ page: <TabCheck /> })
        }
        else if (this.props.page === 'faeApprove') {
            this.setState({ page: <TabApprove /> })
        }
        else if (this.props.page === 'history') {
            this.setState({ page: <History /> })
        }
        else if (this.props.page === 'invoiceprepared') {
            this.setState({ page: <Invoiceprepared /> })
        }
        else if (this.props.page === 'invoicecheck') {
            this.setState({ page: <InvoiceCheck /> })
        }
        else if (this.props.page === 'invoiceapprove') {
            this.setState({ page: <InvoiceApprove /> })
        }
        else if (this.props.page === 'invoicepdf') {
            this.setState({ page: <InvoicePDF /> })
        }
        else if (this.props.page === 'makingApprove') {
            this.setState({ page: <MakingApprove /> })
        }
        // else if (this.props.page === 'requester') {
        //     this.setState({ page: <RequesterInput /> })
        // }
        else if (this.props.page === 'requesterprepare') {
            this.setState({ page: <RequesterPrepare /> })
        }
        else if (this.props.page === 'requestercheck') {
            this.setState({ page: <RequesterCheck /> })
        }
        else if (this.props.page === 'requesterapprove') {
            this.setState({ page: <RequesterApprove /> })
        }

        else if (this.props.page === 'accprepare') {
            this.setState({ page: <ACCPrepared /> })
        }
        else if (this.props.page === 'acccheck') {
            this.setState({ page: <ACCCheck /> })
        }
        else if (this.props.page === 'accapprove') {
            this.setState({ page: <ACCApprove /> })
        }
        else if (this.props.page === 'pdccheck') {
            this.setState({ page: <PDCCheck /> })
        }
        else if (this.props.page === 'pdcapprove') {
            this.setState({ page: <PDCApprove /> })
        }

        else if (this.props.page === 'requesterhistory') {
            this.setState({ page: <RequesterHistory /> })
        }
        else if (this.props.page === 'requesterformA') {
            this.setState({ page: <RequesterformA /> })
        } else if (this.props.page === 'itcCheck') {
            this.setState({ page: <ITCCheck /> })
        } else if (this.props.page === 'itcApprove') {
            this.setState({ page: <ITCApprove /> })
        }
        else if (this.props.page === 'null') {
            this.setState({ page: null });
        }

    }
    render() {
        return (
            <>
                <Grid container style={{ width: '100% !important' }}>
                    {this.state.page}
                </Grid>
            </>
        )
    }
}

export default Main;