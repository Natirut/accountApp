import React from 'react';
import DialogContent from '@material-ui/core/DialogContent';
// import IconButton from '@material-ui/core/IconButton';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { Warning } from '@material-ui/icons';
// import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import Axios from 'axios'
import { Box, Button, Slide, Grid, Checkbox, Chip, FormControlLabel, Tooltip } from '@material-ui/core';
import { HighlightOff, NotInterested } from '@material-ui/icons';
import Success from '../components/successBar/index.component';
import Error from '../components/errorBar/index.component';

class Register extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            slide: null,
            username: "",
            password: "",
            con_password: "",
            openSnack: false,
            showSuccss: false,
            showError: false,
            message: '',
            arrItem: [],
        }

        this.SetUser = this.SetUser.bind(this);
        this.SetPass = this.SetPass.bind(this);
        this.SetConPass = this.SetConPass.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.register_user = this.register_user.bind(this);
        this.check_register = this.check_register.bind(this);
    }
    handleClose() {
        //  this.setState({ open: false, });
        // window.location.reload();
        this.props.close();
    }

    async SetUser(event) {
        await this.setState({
            username: event.target.value
        });
    }
    async SetPass(event) {
        await this.setState({
            password: event.target.value
        });
    }
    async SetConPass(event) {
        await this.setState({
            con_password: event.target.value
        });
    }

    async componentDidMount() {
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="right" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
    }
    check_register() {
        if (this.state.password !== this.state.con_password) {
            this.setState({ openSnack: true })
        }
        else {

            this.register_user()
        }
    }
    register_user() {
        try {
            const body = [];

            let invoice = document.getElementsByName('invoice');
            let waste = document.getElementsByName('waste');
            let requester = document.getElementsByName('requester');
            let itc = document.getElementsByName('itc');
            let pdc = document.getElementsByName('pdc');

            waste.forEach((item) => {
                if (item.checked === true) {
                    body.push({
                        dept: 'fae',
                        feature: 'waste',
                        action: item.value
                    });
                }
            });

            requester.forEach((item) => {
                if (item.checked === true) {
                    body.push({
                        dept: 'requester',
                        feature: 'requester',
                        action: item.value
                    });
                }
            })
            invoice.forEach((item) => {
                if (item.checked === true) {
                    body.push({
                        dept: 'fae',
                        feature: 'invoice',
                        action: item.value
                    });
                }
            });
            itc.forEach((item) => {
                if (item.checked === true) {
                    body.push({
                        dept: 'itc',
                        feature: 'waste',
                        action: item.value
                    });
                }
            });

            pdc.forEach((item) => {
                if (item.checked === true) {
                    body.push({
                        dept: 'pdc',
                        feature: 'waste',
                        action: item.value
                    });
                }
            });

            const regis = {
                username: this.state.username,
                password: this.state.password,
                email: '-',
                tel: '-',
                band: '-',
                canLogin: false,
                permission: body,
            };
            // console.log(regis)
            let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/user`

            Axios.post(url, regis)
                .then(res => {
                    // console.log(res.data)
                    this.setState({ message: res.data.message, showSuccss: true, })

                    setTimeout(() => {
                        this.setState({ showSuccss: false, })
                        this.handleClose();
                    }, 2000);
                }).catch((err) => {
                    this.setState({ message: err.response.data.message, showError: true, })

                    setTimeout(() => {
                        this.setState({ showError: false, })
                    }, 2000);
                })

        } catch (err) {
            console.log(err.stack)
        }
    }


    render() {
        let success;
        if (this.state.showSuccss === true) {
            success = <Success message={this.state.message} />
        }
        let error;
        if (this.state.showError === true) {
            success = <Error message={this.state.message} />
        }

        return (
            <>
                {/* <Snackbar open={this.state.openSnack} message="Fail" autoHideDuration={1000} */}
                <Dialog open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.slide}>
                    {error}
                    <AppBar style={{ position: 'relative', backgroundColor: '#c2ffc2', color: '#300047', }}>
                        <Toolbar>
                            <HighlightOff
                                style={{
                                    position: 'absolute',
                                    right: 'calc(2%)',
                                    color: 'black',
                                    cursor: 'pointer',
                                }}

                                onClick={this.handleClose}
                            />
                            <Typography variant="h6">Register</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent style={{ width: '500px', overflow: 'scroll' }} >
                        <TextField

                            margin="dense"
                            id="user"
                            label="Username"
                            type="email"
                            fullWidth
                            value={this.state.username}
                            onChange={this.SetUser}
                        />
                        <br />  <br />
                        <TextField

                            margin="dense"
                            id="pass"
                            label="Password"
                            type="password"
                            fullWidth
                            value={this.state.password}
                            onChange={this.SetPass}
                        />
                        <TextField

                            margin="dense"
                            id="confirm_pass"
                            label="Confirm Password"
                            type="password"
                            fullWidth
                            value={this.state.con_password}
                            onChange={this.SetConPass}
                        />

                        <Grid container spacing={2} style={{ backgroundColor: '#f5e4ec', marginTop: 'calc(1%)', padding: '10px', borderRadius: '10px' }}>
                            <Grid item xs={12} style={{ textAlign: 'center' }}>
                                <p style={{ color: '#692f73', fontWeight: 'bolder'}}>
                                    PERMISSION CONTROL <Warning color="error" />
                                    </p>
                            </Grid>


                            <Grid container spacing={2}>
                                <Grid item xs={4}>
                                    <center>
                                        <Chip
                                            label={
                                                <>
                                                    FAE <br />
                                            Waste / invoice
                                            </>
                                            }
                                            icon={<><img src={`${process.env.REACT_APP_FILES_PATH}/icons/enviroment.png`} alt="fae.icon" width="25px" height="25px" /></>}
                                            color="primary"
                                            style={{ backgroundColor: '#004700' }}
                                        />
                                    </center>

                                    {/* FAE permission control */}
                                    <Grid container spacing={2}>
                                        <Grid item xs={12}>
                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to prepare">
                                                                        <p style={{ fontSize: '15px', fontFamily: 'emoji' }}>Prepare</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="invoice" value="prepare" />
                                                                    <Checkbox name="waste" value="prepare" />
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to check">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/check.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '14px', fontFamily: 'emoji' }}>Check &nbsp;&nbsp;</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="invoice" value="check" />
                                                                    <Checkbox name="waste" value="check" />

                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to Approve">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/approved.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Approve</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="invoice" value="approve" />
                                                                    <Checkbox name="waste" value="approve" />
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to Approve">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/approved.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '14px', fontFamily: 'emoji' }}>Making</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="invoice" value="making" />
                                                                    <NotInterested style={{ marginLeft: '12px', marginRight: '10px', color: 'red' }} />
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />
                                        </Grid>
                                    </Grid>
                                    {/* FAE permission control */}
                                </Grid>
                                <Grid item xs={4}>
                                    <center>
                                        <Chip
                                            label="ACC"
                                            icon={<><img src={`${process.env.REACT_APP_FILES_PATH}/icons/accountant.png`} alt="fae.icon" width="25px" height="25px" /></>}
                                            color="primary"
                                            style={{ backgroundColor: '#ff4dd3' }}
                                        />
                                    </center>
                                    {/* ACC permission control */}
                                    <Grid container spacing={2}>
                                        <Grid item xs={12}>
                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to prepare">
                                                                        <p style={{ fontSize: '15px', fontFamily: 'emoji' }}>Prepare</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox />
                                                                    <Checkbox />
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to check">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/check.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '14px', fontFamily: 'emoji' }}>Check &nbsp;&nbsp;</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox />
                                                                    <Checkbox />

                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to Approve">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/approved.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Approve</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox />
                                                                    <Checkbox />
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />
                                        </Grid>
                                    </Grid>
                                    {/* ACC permission control */}
                                </Grid>

                                {/* ITC PERMISSION CONTROL */}
                                <Grid item xs={4}>
                                    <Chip
                                        icon={
                                            <>
                                                <img src={`${process.env.REACT_APP_FILES_PATH}/icons/itc.png`} alt="fae.icon" width="25px" height="25px" />
                                            </>}
                                        label="ITC"
                                        color="primary"
                                        style={{ backgroundColor: '#64379f' }}
                                    />
                                    <Grid container spacing={2}>
                                        <Grid item xs={12}>
                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to prepare">
                                                                        <p style={{ fontSize: '15px', fontFamily: 'emoji' }}>Prepare</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="itc" value="prepare" />
                                                                    
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to check">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/check.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '14px', fontFamily: 'emoji' }}>Check &nbsp;&nbsp;</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="itc" value="check" />
                                                                    

                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />

                                            <FormControlLabel
                                                labelPlacement="end"
                                                control={
                                                    <>
                                                        <FormControlLabel
                                                            labelPlacement="start"
                                                            label={
                                                                <>
                                                                    <Tooltip title="Permission to Approve">
                                                                        {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/approved.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                        <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Approve</p>
                                                                    </Tooltip>
                                                                </>
                                                            }
                                                            control={
                                                                <>
                                                                    <Checkbox name="itc" value="approve" />
                                                                    
                                                                </>
                                                            }
                                                        />

                                                    </>
                                                }
                                            />
                                        </Grid>
                                    </Grid>
                                </Grid>


                                {/* PDC */}
                                <Grid item xs={12}>
                                    <Chip
                                        icon={
                                            <>
                                                <img src={`${process.env.REACT_APP_FILES_PATH}/icons/inventory.png`} alt="fae.icon" width="25px" height="25px" />
                                            </>}
                                        label="PDC"
                                        color="primary"
                                        style={{ backgroundColor: 'rgb(222 83 109)', marginRight: 'calc(7%)' }}
                                    />

                                    <FormControlLabel
                                        labelPlacement="end"
                                        control={
                                            <>
                                                <FormControlLabel
                                                    labelPlacement="end"
                                                    label={
                                                        <>
                                                            <Tooltip title="Permission to Check">
                                                                <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Check</p>
                                                            </Tooltip>
                                                        </>
                                                    }
                                                    control={
                                                        <>
                                                            <Checkbox name="pdc" value="check" />
                                                        </>
                                                    }
                                                />

                                            </>
                                        }
                                    />
                                    <FormControlLabel
                                        labelPlacement="end"
                                        control={
                                            <>
                                                <FormControlLabel
                                                    labelPlacement="end"
                                                    label={
                                                        <>
                                                            <Tooltip title="Permission to Approve">
                                                                <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Approve</p>
                                                            </Tooltip>
                                                        </>
                                                    }
                                                    control={
                                                        <>
                                                            <Checkbox name="pdc" value="approve" />
                                                        </>
                                                    }
                                                />

                                            </>
                                        }
                                    />
                                </Grid>

                                {/* REQUESTER */}
                                <Grid item xs={12}>
                                    <Chip
                                        icon={
                                            <>
                                                <img src={`${process.env.REACT_APP_FILES_PATH}/icons/itc.png`} alt="fae.icon" width="25px" height="25px" />
                                            </>}
                                        label="Requester"
                                        color="primary"
                                        style={{ backgroundColor: 'rgb(11 138 124)', marginRight: 'calc(7%)' }}
                                    />

                                    <FormControlLabel
                                        labelPlacement="end"
                                        control={
                                            <>
                                                <FormControlLabel
                                                    labelPlacement="end"
                                                    label={
                                                        <>
                                                            <Tooltip title="Permission to Prepare">
                                                                {/* <img src={`${process.env.REACT_APP_FILES_PATH}/icons/approved.png`} width="20px"
                                                                            height="20px"
                                                                            alt=""
                                                                        /> */}
                                                                <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Prepare</p>
                                                            </Tooltip>
                                                        </>
                                                    }
                                                    control={
                                                        <>
                                                            <Checkbox name="requester" value="prepare" />
                                                        </>
                                                    }
                                                />

                                            </>
                                        }
                                    />

                                    <FormControlLabel
                                        labelPlacement="end"
                                        control={
                                            <>
                                                <FormControlLabel
                                                    labelPlacement="end"
                                                    label={
                                                        <>
                                                            <Tooltip title="Permission to Check">
                                                                <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Check</p>
                                                            </Tooltip>
                                                        </>
                                                    }
                                                    control={
                                                        <>
                                                            <Checkbox name="requester" value="check" />
                                                        </>
                                                    }
                                                />

                                            </>
                                        }
                                    />
                                    <FormControlLabel
                                        labelPlacement="end"
                                        control={
                                            <>
                                                <FormControlLabel
                                                    labelPlacement="end"
                                                    label={
                                                        <>
                                                            <Tooltip title="Permission to Approve">
                                                                <p style={{ fontSize: '13px', fontFamily: 'emoji' }}>Approve</p>
                                                            </Tooltip>
                                                        </>
                                                    }
                                                    control={
                                                        <>
                                                            <Checkbox name="requester" value="approve" />
                                                        </>
                                                    }
                                                />

                                            </>
                                        }
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                        <br />
                        <Box textAlign='center'>
                            <Button variant="contained" color="primary" onClick={this.check_register} style={{ backgroundColor: '#001247', color: '#bfcfff' }}>
                                Register
                    </Button>
                        </Box>
                        <br /> <br /> <br />
                        {success}
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}

export default Register;
