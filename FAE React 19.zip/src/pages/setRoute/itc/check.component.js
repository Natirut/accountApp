
import React, { Component, forwardRef } from 'react';

import { Grid, Button } from '@material-ui/core';
import axios from 'axios';

import MaterialTable from 'material-table';
import Loading from '../../../loading/index.component';

import Confirm from '../../components/confirm/index.component';
import Success from '../../components/successBar/index.component';
import {
    Clear, Check, FirstPage, LastPage,
    DeleteForever, Edit, Add, NavigateNext,
    SortOutlined, Search, ArrowBackIos, Reorder
} from '@material-ui/icons';

import groupArray from 'group-array';
let dataSelection = [];

class ITCcheck extends Component {

    constructor() {
        super();

        this.state = {
            confirm: false,
            loading: false,
            success: false,
            message: '',
            rowData: [],
        };

        this.handleSelection = this.handleSelection.bind(this);
        this.submitCheck = this.submitCheck.bind(this);
        this.showConfirmReject = this.showConfirmReject.bind(this);
        this.close = this.close.bind(this);
        this.confirmResponse = this.confirmResponse.bind(this);
        this.submitReject = this.submitReject.bind(this);
    }

    handleSelection(rows) {
        dataSelection = rows
        console.log(dataSelection)
    }
    confirmResponse(confirm) {
        this.setState({ confirm: false, });

        if (confirm === true) {
            this.submitReject();
        }
    }
    showConfirmReject() {
        this.setState({ confirm: true, })
    }
    close() {
        this.setState({ confirm: false, })
    }

    componentDidMount() {
        this.getData();
    }


    async getData() {
        try {
            const instance = axios.create({
                baseURL: `${process.env.REACT_APP_ENDPOINT}`,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                },
            });
            const response = await instance.get(`/fae-part/requester/req-approved`);
            console.log(response.data);

            let data = [];
            if (response.data.data.hazadousWaste.length !== 0) {
                data.concat(groupArray(response.data.data.hazadousWaste, 'lotNo'));
            }
            if (response.data.data.infectionsWaste.length !== 0) {
                data.concat(groupArray(response.data.data.infectionsWaste, 'lotNo'));
            }
            if (response.data.data.scrapImo.length !== 0) {
                const scrapImo = groupArray(response.data.data.scrapImo, 'lotNo');

                const key = Object.keys(scrapImo)
                console.log('scrapImo: ', scrapImo);
                console.log('key: ', key);
                for (const item of key) {
                    data.push(
                        {
                            lotNo: item,
                            time: scrapImo[item][0].time,
                            moveOutDate: scrapImo[item][0].moveOutDate,
                            dept: scrapImo[item][0].dept,
                            expand: <Reorder style={{ cursor: 'pointer', color: '#4c10de' }} />
                        }
                    )
                }

            }
            this.setState({ rowData: data })

        } catch (error) {
            console.log(error.stack);
        }
    }

    async submitReject() {
        try {
            if (dataSelection.length === 0) {
                return;
            }
            this.setState({ loading: true })
            let lotItems = [];

            for (const item of dataSelection) {
                lotItems.push(item.lotNo)
            }
            const body = {
                lotNo: lotItems,
                status: 'reject',
            }

            const instance = axios.create({
                baseURL: `${process.env.REACT_APP_ENDPOINT}`,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                },
            });
            await instance.put(`/fae-part/requester/status`, body);

            this.setState({ message: 'Reject Lot success.', success: true })
            setTimeout(() => {
                this.setState({ success: false, })
                this.setState({ loading: false, });
                this.getData();
            }, 1500);
        } catch (error) {

        }
    }
    async submitCheck() {
        try {

            if (dataSelection.length === 0) {
                return;
            }
            this.setState({ loading: true })
            let lotItems = [];

            for (const item of dataSelection) {
                lotItems.push(item.lotNo)
            }
            const body = {
                lotNo: lotItems,
                status: "itc-checked"
            }
            const instance = axios.create({
                baseURL: `${process.env.REACT_APP_ENDPOINT}`,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                },
            });
            await instance.put(`/fae-part/requester/status`, body);
            this.setState({ message: 'Checked Lot success.', success: true })
            setTimeout(() => {
                this.setState({ loading: false, success: false, });
                this.getData();
            }, 1500);
        } catch (error) {
            console.log(error.stack)
        }
    }

    render() {
        let confirm; let loading; let success;

        if (this.state.confirm === true) {
            confirm = <Confirm confirmed={this.confirmResponse} content={{ header: 'Do you want to reject ?', description: 'Lot no on selection will send back to prepared' }} />
        }
        if (this.state.success === true) {
            success = <Success message={this.state.message} />
        }
        if (this.state.loading === true) {
            loading = <Loading />
        }
        return (
            <Grid container spacing={1} style={{ margin: 'calc(6%) 10px 20px 10px', }}>
                {confirm}
                <Grid container spacing={1} style={{ marginBottom: '20px' }}>
                    <Grid item xs={9}>
                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/document.png`} alt="" width="50px" />
                        ITC Checker
                    </Grid>
                    <Grid item xs={2}>
                        <Button color="primary" variant="contained"
                            style={{ backgroundColor: '#6fdc91', color: 'white', marginRight: 'calc(4%)' }}
                            onClick={this.submitCheck}> Check </Button>

                        <Button color="primary" variant="contained"
                            style={{ backgroundColor: 'rgb(218 37 37)', color: 'white' }}
                            onClick={this.showConfirmReject}
                        > Reject </Button>
                    </Grid>

                    <Grid item xs={1}>
                        {loading}
                        {success}
                    </Grid>
                </Grid>
                <MaterialTable
                    title="Data ITC check"
                    columns={
                        [
                            { title: 'Lot No', field: 'lotNo', cellStyle: { textAlign: 'center' } },
                            { title: 'Move out date', field: 'moveOutDate', cellStyle: { textAlign: 'center' } },
                            { title: 'Move out time', field: 'time', cellStyle: { textAlign: 'center' } },
                            { title: 'Department', field: 'dept', cellStyle: { textAlign: 'center' } },
                            { title: 'Expand', field: 'expand', cellStyle: { textAlign: 'center' } },
                        ]
                    }
                    icons={{
                        Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
                        Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
                        Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
                        FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
                        LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
                        NextPage: forwardRef((props, ref) => <NavigateNext {...props} ref={ref} />),
                        PreviousPage: forwardRef((props, ref) => <ArrowBackIos {...props} ref={ref} />),
                        ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
                        SortArrow: forwardRef((props, ref) => <SortOutlined {...props} ref={ref} />),
                        Delete: forwardRef((props, ref) => <DeleteForever {...props} ref={ref} />),
                        Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
                        Add: forwardRef((props, ref) => <Add {...props} ref={ref} />),
                    }}
                    data={this.state.rowData}
                    options={{
                        selection: true,
                        headerStyle: { textAlign: 'center' },
                        rowStyle: { textAlign: 'center', },
                    }}
                    style={{ width: '100%', textAlign: 'center' }}
                    onSelectionChange={(rows) => this.handleSelection(rows)}
                />
            </Grid>

        );
    }
}

export default ITCcheck;