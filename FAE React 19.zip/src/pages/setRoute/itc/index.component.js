
import React from 'react';

import { Paper, Card, CardContent, CardActions, Grid } from '@material-ui/core';

class Itc extends React.Component {
    render() {
        return (

            <>
            <Grid container spacing={1}>
                <Grid item xs={12}  style={{ margin: 'calc(5%) 10px 20px 10px',}}>
                    Welcome to Tax invoice program Your're Requester and ITC dept.   
                </Grid>
            </Grid>
                <Grid container spacing={0}
                    style={{
                        margin: '0px 10px 20px 10px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                    <Grid item xs={5}>
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/enviroment.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #36b336',
                                                borderRadius: '10px', padding: '5px', margin: '5px', opacity: 0.3
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    FAE
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                    <Grid item xs={5}>
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/requester.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #ff99ff',
                                                borderRadius: '10px', padding: '5px', margin: '5px',
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    Requester
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                </Grid>

                <Grid container spacing={0}
                    style={{
                        margin: '0 10px 20px 10px',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                    <Grid item xs={5}>
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/itc.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #ff6680',
                                                borderRadius: '10px', padding: '5px', margin: '5px',
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    ITC
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                    <Grid item xs={5} >
                        <Paper variant="outlined" square style={{ margin: '0px calc(1%) 0px calc(1%)' }}>
                            <Card raised>
                                <CardContent>
                                    <center>
                                        <img src={`${process.env.REACT_APP_FILES_PATH}/icons/accountant.png`}
                                            style={{
                                                height: 'calc(45%)', width: 'calc(45%)', boxShadow: '0px 1px 2px 2px #ceb5ff',
                                                borderRadius: '10px', padding: '5px', margin: '5px', opacity: 0.3
                                            }}
                                            alt=""
                                        />
                                    </center>
                                </CardContent>
                                <CardActions>
                                    Account
                                </CardActions>
                            </Card>
                        </Paper>
                    </Grid>
                </Grid>
            </>
        )
    }
}

export default Itc;