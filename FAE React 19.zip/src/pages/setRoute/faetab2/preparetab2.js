import React from 'react'
import DataTable from '../../components/datatableselect/index.component';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import AccountTreeIcon from '@material-ui/icons/AccountTree';
import BackspaceIcon from '@material-ui/icons/Backspace';
// import _ from 'lodash';
import IconButton from '@material-ui/core/IconButton';
import ReorderIcon from '@material-ui/icons/Reorder';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import DialogForm from '../../Requester/component/formA';
import DialogComment from '../../components/comment/index.component';
import DialogFormPreview from '../../components/previewForm/previewimo';
// import groupArray from 'group-array';
import moment from 'moment';
import { Edit, Delete, AspectRatio } from '@material-ui/icons';
import axios from 'axios';
import DialogNon from '../../components/previewForm/formnon-boi/index.form'
import DialogBoi from '../../components/previewForm/formboi/index.form';
import DialogRemask from './remask/index.compopnent'
import PDF from '../../components/previewForm/Accform/index.form'
class PreparedTab2 extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            element: null,
            Alldata: [],
            dialogDetail: false,
            dialogDetailpreview: false,
            dataimo: null,
            dialogComment:false,
            dataSelect: null,
            dataimoboi:null,
            dialogBoi:false,
            dataimonon:null,
            dialogNon:false,
            dataLotIMOall:[],
            dataLotIMOSelect:[],
            dataLotIMOUnSelect:[],
            dalogremask:false,


            openpdf:false

        }
        this.rowData = this.rowData.bind(this);
        this.OpenDialog = this.OpenDialog.bind(this);
        this.OpenDialogComment = this.OpenDialogComment.bind(this);
        this.OpenDialogPriview = this.OpenDialogPriview.bind(this);
        this.cancle = this.cancle.bind(this);
        this.SendReject = this.SendReject.bind(this);
        this.dataselect = this.dataselect.bind(this);
        this.SendApprove = this.SendApprove.bind(this);
        this.SendInvoice = this.SendInvoice.bind(this);
        this.OpenDialogPriviewBoi = this.OpenDialogPriviewBoi.bind(this);
        this.addInvoice = this.addInvoice.bind(this);
        this.Openremask = this.Openremask.bind(this);
        this.BeforAddinvoice = this.BeforAddinvoice.bind(this);
        this.OpenPDF = this.OpenPDF.bind(this);
    }
    OpenPDF(){
        this.setState({openpdf:true})
    }
  Openremask(){
     this.setState({dalogremask:true})
  }
  async BeforAddinvoice(){
    await this.addInvoice()
    await this.setState({ element: null })
    this.rowData()
  }
  async addInvoice(){
       try{
           const body={
                check:this.state.dataLotIMOSelect,
                uncheck:this.state.dataLotIMOUnSelect,
           } 
           console.log(body)
           const instance = axios.create({
               baseURL: process.env.REACT_APP_ENDPOINT,
               headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } 
           })
           const res = await instance.patch(`/fae-part/requester/invoice`,body);
           console.log(res,"ress")
       }catch(err){
           console.log(err)
       }
    }
    async OpenDialogPriviewNon(data) {
        console.log(data)
        await this.setState({ dataimonon: data })
        this.setState({ dialogNon: true })
    }
    async OpenDialogPriviewBoi(data) {
        console.log(data)
        await this.setState({ dataimoboi: data })
        this.setState({ dialogBoi: true })
    }
    SendInvoice(){
      console.log("Add Invoice")
    }
    async SendApprove() {
        if (this.state.dataSelect.length !== 0 && this.state.dataSelect !== null) {
            const tmp = []
            console.log("data", this.state.dataSelect)
            for (let i = 0; i < this.state.dataSelect.length; i++) {
                tmp.push(this.state.dataSelect[i].lotNo)
            }


            try {
                const body = {
                    lotNo: tmp,
                    status: "fae-prepared"
                }
                console.log(body, "bodyy")
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const res = await instance.put(`/fae-part/requester/status`, body);
                console.log(res, "resssssssssss")
                await this.setState({ element: null })
                this.rowData()
            } catch (err) {
                console.log(err)
            }
        }

    }
    async SendReject() {
        if (this.state.dataSelect.length !== 0 && this.state.dataSelect !== null) {
            const tmp = []
            console.log("data", this.state.dataSelect)
            for (let i = 0; i < this.state.dataSelect.length; i++) {
                tmp.push(this.state.dataSelect[i].lotNo)
            }


            try {
                const body = {
                    lotNo: tmp,
                    status: "reject"
                }
                console.log(body, "bodyy")
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const res = await instance.put(`/fae-part/requester/status`, body);
                console.log(res, "resssssssssss")
                await this.setState({ element: null })
                this.rowData()
            } catch (err) {
                console.log(err)
            }
        }

    }
    OpenDialogPriview(){
        console.log("d")
        this.setState({dialogDetailpreview:true})
    }
    OpenDialogComment(){
        this.setState({dialogComment:true})
    }
   async dataselect(x) {
      await  this.setState({ dataSelect: x })
      //  console.log("datatest", x)
        const lotselect = []

        for(let i=0;i<this.state.dataSelect.length;i++){
            lotselect.push(this.state.dataSelect[i].lotNo)
        }
        var _ = require('lodash');
        this.setState({ dataLotIMOSelect: lotselect })
        this.setState({ dataLotIMOUnSelect:  _.difference(this.state.dataLotIMOall, this.state.dataLotIMOSelect) })


     //   console.log("lotall",this.state.dataLotIMOall)
      //  console.log("lotselect",this.state.dataLotIMOSelect)
       // console.log("Unlect",this.state.dataLotIMOUnSelect)
  
    }
    async cancle() {
        console.log("cancle")
        await this.setState({ dialogDetail: false,dialogComment: false,dialogDetailpreview:false  })
        this.setState({ dialogNon: false })
        this.setState({ dialogBoi: false })
        this.setState({ dalogremask: false })
        
    }
    async OpenDialog(x) {
        console.log("open", x)
        await this.setState({ dataimo: x })
        await this.setState({ dialogDetail: true, })

    }
    async componentDidMount() {
        await this.rowData();
        // this.OpenPDF()
    }

    async rowData() {
        try {
            const column = [
                // {
                //     field: 'check', title: <input type="checkbox" style={{ transform: 'scale(1.5, 1.5)' }} name="checkall" ></input>, align: 'left', width: 0.5, sorting: false,
                // },
                // {
                //     field: 'reject', title: <IconButton color="primary" aria-label="upload picture" component="span">
                //         <BackspaceIcon style={{ color: '#f67280' }} />
                //     </IconButton>, align: 'left',
                // },
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', },
                { field: 'date', title: <b>Date</b>, align: 'center', },
                { field: 'time', title: <b>Time</b>, align: 'center', },
                { field: 'status', title: <b>Status</b>, align: 'center', },
                { field: 'ShowBOI', title: <b>ShowBOI</b>, align: 'center', },
                { field: 'ShowNONBOI', title: <b>ShowNON-BOI</b>, align: 'center', }
            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            //const response = await instance.get(`/fae-part/requester/req-approved`);
            const response = await instance.get(`/fae-part/requester/itc-approved`);
            console.log("data prepared", response.data.data.scrapImo)
            this.setState({
                Alldata: response.data.data
            })

            var groupArray = require('group-array');
            var imo = groupArray(response.data.data.scrapImo, 'lotNo');
            // this.setState({dataLotIMOall:imo})
            //   console.log("group",imo['IMO-002/2021'])
            console.log("group", imo)
            const row = [];
            const lotall = [];
            // var key = Object.keys(imo)
            // console.log("key", key)
            for (const [key, value] of Object.entries(imo)) {
                lotall.push(value[0].lotNo)
            }
            this.setState({dataLotIMOall:lotall})
            for (const [key, value] of Object.entries(imo)) {
                console.log(key, value[0])
                row.push(
                    {
                        // check: <>
                        //     <Grid item xs={4}>
                        //         <input type="checkbox" style={{ transform: 'scale(1.4, 1.4)' }} name="acs"></input>
                        //     </Grid>

                        // </>
                        // ,
                        // reject: <> <Grid item xs={4}>
                        //     <IconButton color="primary" aria-label="upload picture" component="span">
                        //         <BackspaceIcon style={{ color: '#f67280' }} />
                        //     </IconButton>

                        // </Grid>
                        // </>,
                        lotNo: value[0].lotNo,
                        date: moment(value[0].date).format('DD/MM/YYYY'),
                        time: value[0].time,
                        status: value[0].status,
                        ShowBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewBoi(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: '#32afa9' }} /> </Grid>
                            </IconButton>
                        </>,
                         ShowNONBOI: <>
                         <IconButton onClick={() => this.OpenDialogPriviewNon(value)} color="primary" aria-label="upload picture" component="span">
                             <Grid item xs={6}>  <ReorderIcon style={{ color: 'red' }} /> </Grid>
                         </IconButton>
                     </>
                    }
                )
            }


            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Fae Prepared Requester." headers={this.state.columns} data={this.state.data} dataselect={this.dataselect} /> })
            }, 500);
        } catch (err) {
            // console.log(err.response.status)
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="Fae Prepared Requester." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    render() {
        
        let showDetail
        if (this.state.dialogDetail === true) {
            showDetail = <DialogForm cancle={this.cancle} data={this.state.dataimo} />
        }
        let showComment
        if (this.state.dialogComment === true) {
            showComment = <DialogComment cancle={this.cancle} />
        }
        let showDetailp
        if (this.state.dialogDetailpreview === true) {
            showDetailp = <DialogFormPreview cancle={this.cancle}   />
        }
        let showBoi
        if (this.state.dialogBoi === true) {
            showBoi = <DialogBoi cancle={this.cancle} data={this.state.dataimoboi} />
        }
        let showNon
        if (this.state.dialogNon === true) {
            showNon = <DialogNon cancle={this.cancle} data={this.state.dataimonon} />
        }
        let showremask
        if (this.state.dalogremask === true) {
            showremask = <DialogRemask cancle={this.cancle}  beforaddinvoice={this.BeforAddinvoice}/>
        }
        let showpdf
        if (this.state.openpdf === true) {
            showpdf = <PDF/>
        }

        
        return (
            <>{showDetail}{showComment}{showDetailp}{showBoi}{showNon}{showremask}{showpdf}
                <Grid container>
                    <Grid item xs={8}></Grid>
                    {/* <Button variant="contained" onClick={this.OpenDialogComment} style={{ backgroundColor: '#6fdc91', color: 'white' }}>
                        Comment
                      </Button> */}
                      <Button onClick={this.SendApprove} variant="contained"  style={{ backgroundColor: '#6fdc91', color: 'white' }}>
                        CHECK
                      </Button>
                      <Button  onClick={this.SendReject} variant="contained" style={{ backgroundColor:  'rgb(218 37 37)', color: 'white',marginLeft: 'calc(1%)' }}>
                        Reject
                      </Button>
                      <Button  onClick={this.Openremask}  variant="contained" style={{ backgroundColor:  'teal', color: 'white',marginLeft: 'calc(1%)' }}>
                        Add Invoice
                      </Button>
                      {/* <Button  onClick={this.OpenPDF}  variant="contained" style={{ backgroundColor:  'ivory', color: 'white',marginLeft: 'calc(1%)' }}>
                        TestPDF
                      </Button> */}
                     
                </Grid>
                <Grid container>
                    <Grid item xs={12} style={{ marginTop: '20px' }}>
                        {this.state.element}
                    </Grid>
                </Grid>

            </>
        )
    }
}
export default PreparedTab2

