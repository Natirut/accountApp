import React from 'react'
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
class ShowDetail extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            slide: null,
        }
        this.handleClose = this.handleClose.bind(this);
    }
    handleClose(){
        this.props.cancle()  
    }
   async componentDidMount() {
        await  this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await  this.setState({ open: true, })
    }
    render() {
        return (
            <>
                <Dialog
                    fullWidth="true"
                    maxWidth="lg"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >

                    <DialogTitle >Detail</DialogTitle>
                    <DialogContent>
                        ทดสอบ
                    </DialogContent>
                    <DialogActions>
                        {/* <Button color="primary">UPDATE</Button> */}
                    </DialogActions>
                </Dialog>

            </>
        )
    }
}
export default ShowDetail

