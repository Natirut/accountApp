import React from 'react'
import DataTable from '../../components/datatableselect/index.component';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import BackspaceIcon from '@material-ui/icons/Backspace';
// import _ from 'lodash';
import IconButton from '@material-ui/core/IconButton';
import ReorderIcon from '@material-ui/icons/Reorder';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import DialogForm from '../../Requester/component/formA';
// import groupArray from 'group-array';
import { Edit, Delete, AspectRatio } from '@material-ui/icons';
import axios from 'axios';
import moment from 'moment';
class CheckTab2 extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            element: null,
            Alldata: [],
            dialogDetail: false,
            dataimo: null,
            dataSelect: null
        }
        this.rowData = this.rowData.bind(this);
        this.OpenDialog = this.OpenDialog.bind(this);
        this.cancle = this.cancle.bind(this);
        this.SendReject = this.SendReject.bind(this);
        this.dataselect = this.dataselect.bind(this);
        this.SendApprove = this.SendApprove.bind(this);
    }
    async SendApprove() {
        if (this.state.dataSelect.length !== 0 && this.state.dataSelect !== null) {
            const tmp = []
            console.log("data", this.state.dataSelect)
            for (let i = 0; i < this.state.dataSelect.length; i++) {
                tmp.push(this.state.dataSelect[i].lotNo)
            }


            try {
                const body = {
                    lotNo: tmp,
                    status: "fae-checked"
                }
                console.log(body, "bodyy")
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const res = await instance.put(`/fae-part/requester/status`, body);
                console.log(res, "resssssssssss")
                await this.setState({ element: null })
                this.rowData()
            } catch (err) {
                console.log(err)
            }
        }

    }

    async SendReject() {
        if (this.state.dataSelect.length !== 0 && this.state.dataSelect !== null) {
            const tmp = []
            console.log("data", this.state.dataSelect)
            for (let i = 0; i < this.state.dataSelect.length; i++) {
                tmp.push(this.state.dataSelect[i].lotNo)
            }


            try {
                const body = {
                    lotNo: tmp,
                    status: "reject"
                }
                console.log(body, "bodyy")
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const res = await instance.put(`/fae-part/requester/status`, body);
                console.log(res, "resssssssssss")
                await this.setState({ element: null })
                this.rowData()
            } catch (err) {
                console.log(err)
            }
        }

    }
    dataselect(x) {
        console.log("datatest", x)
        this.setState({ dataSelect: x })
    }
    async cancle() {
        await this.setState({ dialogDetail: false, })
    }
    async OpenDialog(x) {
        console.log("open", x)
        await this.setState({ dataimo: x })
        await this.setState({ dialogDetail: true, })

    }
    async componentDidMount() {
        await this.rowData();
    }

    async rowData() {
        try {
            const column = [
                // {
                //     field: 'check', title: <input type="checkbox" style={{ transform: 'scale(1.5, 1.5)' }} name="checkall" ></input>, align: 'left', width: 0.5, sorting: false,
                // },
                // {
                //     field: 'reject', title: <IconButton color="primary" aria-label="upload picture" component="span">
                //         <BackspaceIcon style={{ color: '#f67280' }} />
                //     </IconButton>, align: 'left',
                // },
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', },
                { field: 'date', title: <b>Date</b>, align: 'center', },
                { field: 'time', title: <b>Time</b>, align: 'center', },
                { field: 'status', title: <b>Status</b>, align: 'center', },
                { field: 'ShowDetail', title: <b>ShowDetail</b>, align: 'center', }
            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

           // const response = await instance.get(`/fae-part/requester/req-prepared`);
            const response = await instance.get(`/fae-part/requester/fae-prepared`);
            console.log("data prepared", response.data.data.scrapImo)
            this.setState({
                Alldata: response.data.data
            })

            var groupArray = require('group-array');
            var imo = groupArray(response.data.data.scrapImo, 'lotNo');
            //   console.log("group",imo['IMO-002/2021'])
            console.log("group", imo)
            const row = [];
            // var key = Object.keys(imo)
            // console.log("key", key)

            for (const [key, value] of Object.entries(imo)) {
                console.log(key, value[0])
                row.push(
                    {
                        // check: <>
                        //     <Grid item xs={4}>
                        //         <input type="checkbox" style={{ transform: 'scale(1.4, 1.4)' }} name="acs"></input>
                        //     </Grid>

                        // </>
                        // ,
                        // reject: <> <Grid item xs={4}>
                        //     <IconButton color="primary" aria-label="upload picture" component="span">
                        //         <BackspaceIcon style={{ color: '#f67280' }} />
                        //     </IconButton>

                        // </Grid>
                        // </>,
                        lotNo: value[0].lotNo,
                        date: moment(value[0].date).format('DD/MM/YYYY'),
                        time: value[0].time,
                        status: value[0].status,
                        ShowDetail: <>
                            <IconButton onClick={() => this.OpenDialog(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: '#32afa9' }} /> </Grid>
                            </IconButton>
                        </>
                    }
                )
            }


            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Fae Checked Requester." headers={this.state.columns} data={this.state.data} dataselect={this.dataselect} /> })
            }, 500);
        } catch (err) {
            // console.log(err.response.status)
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="Fae Checked Requester." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    render() {
        let showDetail
        if (this.state.dialogDetail === true) {
            showDetail = <DialogForm cancle={this.cancle} data={this.state.dataimo} />
        }
        return (
            <>{showDetail}
                <Grid container>
                    <Grid item xs={9}></Grid>
                    <Button  onClick={this.SendApprove} variant="contained" style={{ backgroundColor: '#6fdc91', color: 'white' }}>
                        Check
                      </Button>
                      <Button onClick={this.SendReject} variant="contained" style={{ backgroundColor:  'rgb(218 37 37)', color: 'white',marginLeft: 'calc(1%)' }}>
                        Reject
                      </Button>
                     
                </Grid>
                <Grid container>
                    <Grid item xs={12} style={{ marginTop: '20px' }}>
                        {this.state.element}
                    </Grid>
                </Grid>

            </>
        )
    }
}
export default CheckTab2

