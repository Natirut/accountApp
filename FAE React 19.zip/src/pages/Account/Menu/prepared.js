import React from 'react'
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import Tooltip from '@material-ui/core/Tooltip';
import DataTable from '../../components/datatable/index.component';
import IconButton from '@material-ui/core/IconButton';
import ReorderIcon from '@material-ui/icons/Reorder';
import DialogNon from '../../components/previewForm/formnon-boi/index.form'
import DialogBoi from '../../components/previewForm/formboi/index.form'
import Pdf from "react-to-pdf";
import moment from 'moment';
const ref = React.createRef();
class ACCPrepare extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            openInput: false,
            element: null,
            dialogDetail: false,
            dataimonon: null,
            dataimoboi: null,
            dialogNon: false,
            dialogBoi: false
        }
        this.cancle = this.cancle.bind(this)
        this.OpenDialogPriviewNon = this.OpenDialogPriviewNon.bind(this);
        this.OpenDialogPriviewBoi = this.OpenDialogPriviewBoi.bind(this);
        // console.log(this.props)
    }
    async OpenDialogPriviewNon(data) {
        console.log(data)
        await this.setState({ dataimonon: data })
        this.setState({ dialogNon: true })
    }
    async OpenDialogPriviewBoi(data) {
        console.log(data)
        await this.setState({ dataimoboi: data })
        this.setState({ dialogBoi: true })
    }

    async getPrepared() {
        try {
            console.log('componentDidMount');
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    // 'Content-Type': 'application/json',
                }
            });

            const response = await instance.get(`/fae-part/requester/req-prepared`);
            console.log(response)
        } catch (error) {
            console.log(error.stack);
        }
    }

    async rowData() {
        try {
            const column = [
                { field: 'lotNo', title: <b>lotNo</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'date', title: <b>Date</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'time', title: <b>Time</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'status', title: <b>Status</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'ShowBOI', title: <b>ShowBOI</b>, align: 'center', cellStyle: { padding: '0 14px' } },
                { field: 'ShowNONBOI', title: <b>ShowNON-BOI</b>, align: 'center', cellStyle: { padding: '0 14px' } }
            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/requester/req-prepared`);
            console.log("data prepared", response.data.data.scrapImo)
            this.setState({
                Alldata: response.data.data
            })

            var groupArray = require('group-array');
            var imo = groupArray(response.data.data.scrapImo, 'lotNo');
            console.log("dadad", response.data.data.scrapImo)
            console.log("group", imo)
            const row = [];
            for (const [key, value] of Object.entries(imo)) {
                console.log(key, value[0])
                row.push(
                    {
                        lotNo: value[0].lotNo,
                        date: moment(value[0].date).format('DD/MM/YYYY'),
                        time: value[0].time,
                        status: value[0].status,
                        ShowBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewBoi(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: '#32afa9' }} /> </Grid>
                            </IconButton>
                        </>,
                        ShowNONBOI: <>
                            <IconButton onClick={() => this.OpenDialogPriviewNon(value)} color="primary" aria-label="upload picture" component="span">
                                <Grid item xs={6}>  <ReorderIcon style={{ color: 'red' }} /> </Grid>
                            </IconButton>
                        </>
                    }
                )
            }
            setTimeout(async () => {
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Account Prepared." headers={this.state.columns} data={this.state.data} dataselect={this.dataselect} /> })
            }, 500);
        } catch (err) {
            console.log(err.stack)
            this.setState({ element: <DataTable title="Account Prepared." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    componentDidMount() {
        this.rowData();
        this.getPrepared();
    }
    cancle() {
        this.setState({ dialogNon: false })
        this.setState({ dialogBoi: false })
    }
    render() {
        let showNon
        if (this.state.dialogNon === true) {
            showNon = <DialogNon cancle={this.cancle} data={this.state.dataimonon} />
        }
        let showBoi
        if (this.state.dialogBoi === true) {
            showBoi = <DialogBoi cancle={this.cancle} data={this.state.dataimoboi} />
        }
        return (
            <>{showNon}{showBoi}
                <Grid container style={{ marginTop: 'calc(5%)' }}>
                    <Grid item xs={12} style={{ marginTop: 'calc(3%)' }}>
                        {this.state.element}
                    </Grid>
                </Grid>
{/* 
                <Pdf targetRef={ref} filename="code-example.pdf">
                    {({ toPdf }) => <button onClick={toPdf}>Generate Pdf</button>}
                </Pdf>
                <div style={{width: 500, height: 500, background: 'blue'}} ref={ref}>
                    <h1>Hello CodeSandbox</h1>
                    <h2>Start editing to see some magic happen!</h2>
                </div> */}

            </>
        )
    }
}
export default ACCPrepare

