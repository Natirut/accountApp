
export default function status_401(res) {
    
}

export default function status_500(res) {
    
}