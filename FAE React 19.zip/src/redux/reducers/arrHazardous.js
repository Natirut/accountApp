
export default (state, action) =>{

    switch(action.type){
        case 'arr':
            return action.x
        default:
            return []
    }
}