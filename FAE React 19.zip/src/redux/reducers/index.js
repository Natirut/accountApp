
import { combineReducers } from 'redux';

import counters from './counter';
import arrHazardous from './arrHazardous';
export default combineReducers({
    counters,
    arrHazardous
})
