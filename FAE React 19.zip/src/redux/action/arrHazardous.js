export const itemHazardous = (x) => ({
    type:'arr',
    x
})