import React from 'react'
import Grid from '@material-ui/core/Grid';
import  In from '../Menu/in';
import  Out from '../Menu/out';
import  Summary from '../Menu/summary';
class Page extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            page:null
        }
    }
    componentDidMount() {
        if (this.props.page === 'in') {
            this.setState({ page: <In /> });
        }
       else if (this.props.page === 'out') {
            this.setState({ page: <Out /> });
        }
        else if (this.props.page === 'summary') {
            this.setState({ page: <Summary /> });
        }
    }
    render() {
        return (
            <>
                <Grid container style={{ width: '100% !important' }}>
                    {this.state.page}
                </Grid> 
            </>
        )
    }
}
export default Page

