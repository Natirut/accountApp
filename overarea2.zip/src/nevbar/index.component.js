import React from 'react'
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import Atp from '../App';
import ReactDom from 'react-dom';
class NevBar extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            user: '',
            icon: ''
        }
    }
    logout() {
        localStorage.clear();
        ReactDom.unmountComponentAtNode(document.getElementById('root'))
        ReactDom.render(<Atp />, document.getElementById('root'));
      }
    componentDidMount() {
        let getUser = localStorage.getItem('username');
        if (getUser) {
            this.setState({ user: getUser, icon: <AccountCircleIcon /> })
        }
    }
    render() {
        return (
            <>
                <div style={{ flexGrow: '1' }}>
                    <AppBar position="static" style={{ backgroundColor: '#2abfc0' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" aria-label="menu">
                                {/* <MenuIcon /> */}
                            </IconButton>
                            <Typography variant="h6" style={{ flexGrow: '1' }}>
                                Over Area
                               {/* <Button variant="contained" startIcon={<AllInboxIcon />} style={{margin:'5px'}} color="primary">IN</Button>
                               <Button   variant="contained" startIcon={<DomainDisabledIcon />}  style={{margin:'5px'}} color="primary">OUT</Button>
                               <Button   variant="contained" startIcon={<DashboardIcon />} style={{margin:'5px'}} color="primary">SUMMARY</Button> */}
                            </Typography>
                            {/* <Button color="inherit">Login</Button> */}
                            {this.state.icon}
                            {this.state.user}
                            <IconButton onClick={this.logout} color="primary" aria-label="upload picture" component="span">
                                <ExitToAppIcon />
                            </IconButton>
                        </Toolbar>
                    </AppBar>
                </div>
            </>
        )
    }
}
export default NevBar

