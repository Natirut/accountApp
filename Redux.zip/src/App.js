import React from 'react';
import Navbar from './navbar/index.component';

import Footer from './footer/index.component';

import Page from './pages/index.component';
import Grid from '@material-ui/core/Grid';
import Login from './pages/Login/index.component'
class App extends React.Component {
  render() {
    let getUser = localStorage.getItem('username');
    if (getUser != null) {
      return (
        <>
          <Grid container spacing={0}>
            <Grid item xs={12}>
              <Navbar />
              <Page />
            </Grid>

            <Grid item xs={12} style={{ marginTop: 'calc(8%)'}}>
              <Footer />
            </Grid>
          </Grid>
        </>
      )
    }
    else {
      return (
        <>
          <Login />
        </>
      )
    }

  }
}

export default App;
