import React from 'react';
import Grid from '@material-ui/core/Grid';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Switch from '@material-ui/core/Switch';
import Typography from '@material-ui/core/Typography';
import { Fab, Select, MenuItem, InputLabel, FormControl } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { GetApp } from '@material-ui/icons';
import Slide from '@material-ui/core/Slide';
import DatePicker from '../../components/datepicker/index.component';
import axios from 'axios';
import ErrorBar from '../../components/errorBar/index.component';
// import SecondStep from './secondStep';
import Badge from '@material-ui/core/Badge';
import MailIcon from '@material-ui/icons/Mail';

class DialogPrepared extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            pickerDateOut: false,
            pickedDateOut: '',
            pickerDateInvoice: false,
            pickedDateInvoice: '',
            pickerDateStart: false,
            pickedDateStart: '',
            pickerDateEnd: false,
            pickedDateEnd: '',
            open: false,
            slide: false,
            // elementOnget: null,
            quotationList: null,
            getWaste: false,
            wasteList: null,
            error: false,
            message: '',
            swap: true,
            showTax: null,
            showWasteName: null,
            showAll: null,
            showButtonAll: null,
            showButtonName: null,
            showButtonGroup: null,
            //data top//
            boi: "",
            lotno: "",
            moveout: "",
            wastename: "",

            //    //data buttom//
            contractno: "",
            contractstart: "",
            contractend: "",
            partyname: "",
            phone: "",
            fax: "",
            address: "",
            partycharge: "",
            partychargePosi: "",
            invoicedate: "",

            dataStepOne: null,
            showswap: true,
            AllNameMap: [],
            datawastename: null,
            wastenameall:"",
            wastenameone:""


        }
        this.handleClose = this.handleClose.bind(this);
        this.getQuotation = this.getQuotation.bind(this);
        this.getWaste = this.getWaste.bind(this);
        this.SetBoi = this.SetBoi.bind(this);
        this.Switch = this.Switch.bind(this);
        this.openDatePickerOut = this.openDatePickerOut.bind(this);
        this.onSelectedDateOut = this.onSelectedDateOut.bind(this);
        this.openDatePickerInvoice = this.openDatePickerInvoice.bind(this);
        this.onSelectedDateInvoice = this.onSelectedDateInvoice.bind(this);
        this.openDatePickerStart = this.openDatePickerStart.bind(this);
        this.onSelectedDateStart = this.onSelectedDateStart.bind(this);
        this.openDatePickerEnd = this.openDatePickerEnd.bind(this);
        this.onSelectedDateEnd = this.onSelectedDateEnd.bind(this);
        this.SetAll = this.SetAll.bind(this);
        this.ReadyDataOne = this.ReadyDataOne.bind(this);
        this.getWasteOne = this.getWasteOne.bind(this);
        this.checknext = this.checknext.bind(this);
   //     this.GetWasteName = this.GetWasteName.bind(this);
        this.SetWasteName = this.SetWasteName.bind(this);
        this.SetWasteNameOne = this.SetWasteNameOne.bind(this);
        
     console.log(this.props.backwaste)
    }
    async checknext() {
        await this.ReadyDataOne()
        await this.props.making(this.state.AllNameMap)
        await this.props.information(this.state.dataStepOne)
        await this.props.quotation(this.state.quotationList)
        await this.props.num(1)
    }
    async getWasteOne() {

        try {
            const body = {
                wasteName: this.state.wastenameone
            }

            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                }
            })

            const response = await instance.patch(`/fae-part/waste/invoice/name`, body);

            //  console.log('data', response.data.data.length)
            this.setState({ showswap: false })

            // const tmp = []
            for (let i = 0; i < response.data.data.length; i++) {
                await this.state.AllNameMap.push(response.data.data[i])
            }

            var _ = require('lodash');

            await this.setState({
                AllNameMap: _.uniqBy(this.state.AllNameMap, '_id')
            })
            console.log("data", this.state.AllNameMap)
        } catch (err) {
            console.log(err.stack)
            let message;
            if (err.response) {
                if (err.response.status === 403) {
                    console.log('Permission denied');
                    message = 'Permission denied.'
                } else if (err.response.status === 400) {
                    message = 'Some field is empty !!!';
                }
            } else {
                message = err.message
            }
            this.setState({ error: true, message, })

            setTimeout(() => {
                this.setState({ error: false, })
            }, 3000);

        }
    }
    async onSelectedDateStart(date) {
        console.log(date)
        if (date !== false) {
            console.log("in")
            await this.setState({ pickedDateStart: date.selectedDate })
        }
        this.setState({ pickerDateStart: false, })
    }
    openDatePickerStart() {
        console.log("open")
        this.setState({ pickerDateStart: true })
    }
    async onSelectedDateEnd(date) {
        console.log(date)
        if (date !== false) {
            console.log("in")
            await this.setState({ pickedDateEnd: date.selectedDate })
        }
        this.setState({ pickerDateEnd: false, })
    }
    openDatePickerEnd() {
        console.log("open")
        this.setState({ pickerDateEnd: true })
    }
    async onSelectedDateOut(date) {
        console.log(date)
        if (date !== false) {
            console.log("in")
            await this.setState({ pickedDateOut: date.selectedDate })
            this.componentDidMount()
        }
        console.log(this.state.pickedDateOut)
        this.setState({ pickerDateOut: false, })
    }
    openDatePickerOut() {
        console.log("open")
        this.setState({ pickerDateOut: true })
    }
    async onSelectedDateInvoice(date) {
        console.log(date)
        if (date !== false) {
            console.log("in")
            await this.setState({ pickedDateInvoice: date.selectedDate })
        }
        console.log(this.state.pickedDateInvoice)
        this.setState({ pickerDateInvoice: false, })
    }
    openDatePickerInvoice() {
        console.log("open")
        this.setState({ pickerDateInvoice: true })
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.close();
    }
    async Switch(e) {
        console.log(e.target.checked)
        await this.setState({ swap: e.target.checked, })
        if (this.state.swap === true) {
            await this.setState({ showAll: this.state.showTax })
            await this.setState({ showButtonAll: this.state.showButtonGroup })
        }
        if (this.state.swap === false) {
            await this.setState({ showAll: this.state.showWasteName })
            await this.setState({ showButtonAll: this.state.showButtonName })
        }

    }
    async ReadyDataOne() {
        if (this.state.swap === true) {
            await this.setState({
                lotno: document.getElementById('lotno').value,
                moveout: document.getElementById('moveout').value,
                wastename: this.state.wastenameall
            })
        }
        if (this.state.swap === false) {
            await this.setState({
                wastename: this.state.wastenameone
            })
        }

        await this.setState({
            contractno: document.getElementById('conNo').value,
            contractstart: document.getElementById('constart').value,
            contractend: document.getElementById('conEnd').value,
            partyname: document.getElementById('conName').value,
            phone: document.getElementById('phoneNo').value,
            fax: document.getElementById('fax').value,
            address: document.getElementById('address').value,
            partycharge: document.getElementById('conChan').value,
            partychargePosi: document.getElementById('conChanPosi').value,
            invoicedate: document.getElementById('invoicedate').value,
        })

        // let sub = []
        // sub = {
        //     quotationNo: this.state.quotationList[0].quotationNo,
        //     wasteName: this.state.quotationList[0].wasteName,
        //     quantity: 0,
        //     unitPrice: this.state.quotationList[0].unitPrice,
        //     amount: 0
        // }
        let body = []

        body = {
            contractNo: this.state.contractno,
            contractStartDate: this.state.contractstart,
            contractEndDate: this.state.contractend,
            counterpartyName: this.state.partyname,
            phoneNo: this.state.phone,
            fax: this.state.fax,
            counterpartyAddress: this.state.address,
            counterpartyChange: this.state.partycharge,
            counterPartyChangePosition: this.state.partychargePosi,
            invoiceDate: this.state.invoicedate,
            typeBoi: this.state.boi,
            lotNo: this.state.lotno,
            moveOutDate: this.state.moveout,
            wasteName: this.state.wastename,
            wasteItem: null,
            subTotal: null,
            grandTotal: null
        }

        // console.log("ROWdata", body)

        this.setState({
            dataStepOne: body
        })
        console.log("dataROE", this.state.dataStepOne)
        this.componentWillUnmount()
    }

    async SetBoi(e) {
        console.log(e.target.value)
        await this.setState({ boi: e.target.value })
        this.componentDidMount()
        console.log("Boi", this.state.boi)
    }

  async  SetWasteName(e){
    console.log(e.target.value)
    await this.setState({ wastenameall: e.target.value }) 
  }

  async  SetWasteNameOne(e){
    console.log(e.target.value)
    await this.setState({ wastenameone: e.target.value }) 
  }

    async getWaste() {

        try {
            // this.setState({ elementOnget: <CircularProgress color="secondary" />, })
            const body = {
                typeBoi: this.state.boi,
                lotNo: document.getElementById('lotno').value,
                date: document.getElementById('moveout').value,
                wasteName: this.state.wastenameall
            }
            console.log(body)
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                }
            })

            const response = await instance.patch(`/fae-part/waste/invoice/all`, body);
            console.log('all: ', response.data)
            // this.setState({ AllNameMap: response.data.data });

            for (let i = 0; i < response.data.data.length; i++) {
                await this.state.AllNameMap.push(response.data.data[i])
            }

            var _ = require('lodash');

            await this.setState({
                AllNameMap: _.uniqBy(this.state.AllNameMap, '_id')
            })
            console.log("data", this.state.AllNameMap)

            // setTimeout(() => {
            //     this.setState({ elementOnget: <Check />, })
            // }, 500);
            this.setState({ getWaste: true, })
            this.setState({ showswap: false })
        } catch (err) {
            let message;
            if (err.response) {
                if (err.response.status === 403) {
                    console.log('Permission denied');
                    message = 'Permission denied.'
                } else if (err.response.status === 400) {
                    message = 'Some field is empty !!!';
                }
            } else {
                message = err.message
            }
            this.setState({ error: true, message, })

            setTimeout(() => {
                this.setState({ error: false, })
            }, 3000);
        }
    }
    async getQuotation() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    // 'Content-Type': 'application/json',
                }
            })

            const response = await instance.get(`/fae-part/quotation`);
            console.log('getQuotation: ', response.data.data)
            this.setState({ quotationList: response.data.data });
        } catch (err) {
            console.log(err.stack)
        }
    }
    async componentWillUnmount() {

        // await this.ReadyDataOne()
        console.log('Unmount');
        //return   <SecondStep making={this.state.AllNameMap} information={this.state.dataStepOne} />
        //  await  this.props.making(this.state.AllNameMap)
        //  await  this.props.information(this.state.dataStepOne)
        //  await  this.props.quotation(this.state.quotationList)
    }

    async SetAll() {
        await this.setState({
            showButtonGroup: <>  <Fab
                aria-label="save"
                color="primary"
                onClick={this.getWaste}
                style={{ position: 'absolute', marginLeft: 'calc(2%)', color: '#ea86b6', backgroundColor: '#272643' }}
            >
                {/* {(this.state.getWaste === false) ? <GetApp /> : this.state.elementOnget} */}
                <GetApp />
            </Fab>

            </>
        })
        await this.setState({
            showButtonAll: <>  <Fab
                aria-label="save"
                color="primary"
                onClick={this.getWaste}
                style={{ position: 'absolute', marginLeft: 'calc(2%)', color: '#ea86b6', backgroundColor: '#272643' }}
            >
                {/* {(this.state.getWaste === false) ? <GetApp /> : this.state.elementOnget} */}
                <GetApp />
            </Fab>

            </>
        })
        await this.setState({
            showButtonName: <>  <Fab
                aria-label="save"
                color="info"
                onClick={this.getWasteOne}
                style={{ position: 'absolute', marginLeft: 'calc(2%)', color: '#99ff99', backgroundColor: '#272643' }}
            >
                {/* {(this.state.getWaste === false) ? <GetApp /> : this.state.elementOnget} */}
                <GetApp />
            </Fab>
            </>
        })
        await this.setState({
            showWasteName: <>
                {/* <TextField
                    id="wastename"
                    label="Waste Name."
                    placeholder="Waste Name"
                    multiline
                    variant="filled"
                    style={{ margin: '5px' }}
                /> */}
                 <FormControl variant="filled">
                    <InputLabel id="demo-simple-select-filled-label">WasteName</InputLabel>
                    <Select
                        labelId="demo-simple-select-filled-label"
                        id="wastename"
                        style={{ width: '200px', marginTop: '5px' }}
                        onChange={this.SetWasteNameOne}
                    >
                       {/* {this.state.datawastename} */}
                       {this.props.backwaste}
                    </Select>
                </FormControl>
            </>
        })

        await this.setState({
            showTax: <>    <FormControl variant="filled">
                <InputLabel id="demo-simple-select-filled-label">Type of BOI/Non-BOI</InputLabel>
                <Select
                    labelId="demo-simple-select-filled-label"
                    id="demo-simple-select-filled"
                    style={{ width: '200px', marginTop: '5px' }}
                    //   value={age}
                    onChange={this.SetBoi}
                >
                    <MenuItem value="-">
                        <em>None</em>
                    </MenuItem>
                    <MenuItem value="BOI">BOI</MenuItem>
                    <MenuItem value="NON-BOI">NON-BOI</MenuItem>
                </Select>
            </FormControl>
                <TextField
                    id="lotno"
                    label="Lot No."
                    placeholder="Placeholder"
                    multiline
                    variant="filled"
                    style={{ margin: '5px' }}
                />
                <TextField
                    id="moveout"
                    label="Move Out Date"
                    value={this.state.pickedDateOut}
                    onClick={this.openDatePickerOut}
                    variant="filled"
                    style={{ margin: '5px' }}
                />
                {/* <TextField
                    id="wastenamee"
                    label="Waste Name."
                    placeholder="Waste Name"
                    multiline
                    variant="filled"
                    style={{ margin: '5px' }}
                /> */}
                  <FormControl variant="filled">
                    <InputLabel id="demo-simple-select-filled-label">WasteName</InputLabel>
                    <Select
                        labelId="demo-simple-select-filled-label"
                        id="wastenamee"
                        style={{ width: '200px', marginTop: '5px' }}
                        onChange={this.SetWasteName}
                    >
                       {/* {this.state.datawastename} */}
                       {this.props.backwaste}
                    </Select>
                </FormControl>
            </>
        })

        await this.setState({
            showAll: <>    <FormControl variant="filled">
                <InputLabel id="demo-simple-select-filled-label">Type of BOI/Non-BOI</InputLabel>
                <Select
                    labelId="demo-simple-select-filled-label"
                    id="demo-simple-select-filled"
                    style={{ width: '200px', marginTop: '5px' }}
                    value={this.state.boi}
                    onChange={this.SetBoi}
                >
                    <MenuItem value="-">
                        <em>None</em>
                    </MenuItem>
                    <MenuItem value="BOI">BOI</MenuItem>
                    <MenuItem value="NON-BOI">NON-BOI</MenuItem>
                </Select>
            </FormControl>
                <TextField
                    id="lotno"
                    label="Lot No."
                    placeholder="Placeholder"
                    multiline
                    variant="filled"
                    style={{ margin: '5px' }}
                />
                <TextField
                    id="moveout"
                    label="Move Out Date"
                    value={this.state.pickedDateOut}
                    onClick={this.openDatePickerOut}
                    variant="filled"
                    style={{ margin: '5px' }}
                />
                {/* <TextField
                    id="wastenamee"
                    label="Waste Name."
                    placeholder="Waste Name"
                    multiline
                    variant="filled"
                    style={{ margin: '5px' }}
                /> */}

                <FormControl variant="filled">
                    <InputLabel id="demo-simple-select-filled-label">WasteName</InputLabel>
                    <Select
                        labelId="demo-simple-select-filled-label"
                       // id="wastenamee"
                      //  value={this.state.setwastename}
                     
                        style={{ width: '200px', marginTop: '5px' }}
                         onChange={this.SetWasteName}
                    >
                       {/* {this.state.datawastename} */}
                      { this.props.backwaste}
                    </Select>
                </FormControl>

            </>
        })
    }
    async componentDidMount() {
        // this.setState({showswap:true})
       
        this.SetAll()


        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })

        this.getQuotation();
    }

    render() {
        let errorbar;

        if (this.state.error === true) {
            errorbar = <ErrorBar message={this.state.message} />
        }
        let datepickerout;
        if (this.state.pickerDateOut === true) {
            datepickerout = <DatePicker callBackClose={this.onSelectedDateOut} />
        }
        let datepickerinvoice;
        if (this.state.pickerDateInvoice === true) {
            datepickerinvoice = <DatePicker callBackClose={this.onSelectedDateInvoice} />
        }
        let datepickerstart;
        if (this.state.pickerDateStart === true) {
            datepickerstart = <DatePicker callBackClose={this.onSelectedDateStart} />
        }
        let datepickerend;
        if (this.state.pickerDateEnd === true) {
            datepickerend = <DatePicker callBackClose={this.onSelectedDateEnd} />
        }
        return (
            <>{datepickerout}{datepickerinvoice}{datepickerstart}{datepickerend}
                <Grid container>
                    <Grid item xs={1}>
                    </Grid>
                    <Grid item xs={10}>
                        <Card variant="outlined">
                            <CardContent >
                                {errorbar}
                                <Grid container>
                                    <Grid item xs={11}>
                                        <Typography color="textSecondary" gutterBottom style={{ fontSize: '16px', fontWeight: 'bold' }}>
                                            Tax Invoice Making Request
                                            {this.state.showswap === true ? (
                                                <Switch
                                                    checked={this.state.swap}
                                                    onChange={this.Switch}
                                                    name="checkedA"
                                                    inputProps={{ 'aria-label': 'secondary checkbox' }}
                                                />
                                            ) : (
                                                    <></>
                                                )}

                                        </Typography>
                                    </Grid>

                                    <Grid item xs={1}>
                                        <Badge badgeContent={this.state.AllNameMap.length} color="secondary">
                                            <MailIcon />
                                        </Badge>
                                    </Grid>
                                </Grid>

                                {/* <Grid item xs={2}>
        
                                </Grid> */}

                                <Grid item xs={12}>
                                    {this.state.showAll}
                                    {this.state.showButtonAll}
                                </Grid>
                                {/* <Grid item xs={2}>

                                </Grid> */}
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>
                <Grid container style={{ textAlign: "center", marginTop: '10px' }} >
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={10}>
                        <Card variant="outlined">
                            <CardContent >
                                <Typography color="textSecondary" gutterBottom style={{ fontSize: '16px', fontWeight: 'bold', marginRight: '80%' }}>
                                    Tax Invoice Information
                                </Typography>
                                {/* ROW2 */}
                                <Grid container style={{ textAlign: "center", marginTop: '10px' }} >
                                    <Grid item xs={4}>
                                        <TextField
                                            id="conNo"
                                            label="Contract No."
                                            placeholder="Placeholder"
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField
                                            id="constart"
                                            label="Contract Start Date."
                                            placeholder="Placeholder"
                                            value={this.state.pickedDateStart}
                                            onClick={this.openDatePickerStart}
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField
                                            id="conEnd"
                                            label="Contract End Dete."
                                            placeholder="Placeholder"
                                            value={this.state.pickedDateEnd}
                                            onClick={this.openDatePickerEnd}
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                </Grid>


                                {/* ROW3 */}
                                <Grid container style={{ textAlign: "center" }} >
                                    <Grid item xs={4}>
                                        <TextField
                                            id="conName"
                                            label="Conterparty Name."
                                            placeholder="Placeholder"
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField
                                            id="phoneNo"
                                            label="Phone No."
                                            placeholder="Placeholder"
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField
                                            id="fax"
                                            label="Fax."
                                            placeholder="Placeholder"
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                </Grid>

                                {/* ROW4 */}
                                <Grid container >
                                    {/* <Grid tem xs={1}>

                                        </Grid> */}
                                    <Grid item xs={10}>
                                        <TextField
                                            fullWidth='true'
                                            id="address"
                                            label="Counterparty Address"
                                            multiline
                                            rows={3}
                                            variant="outlined"
                                            style={{ marginTop: '10px', marginLeft: "8%" }}
                                        />
                                    </Grid>
                                    {/* <Grid tem xs={1}>

                                        </Grid> */}
                                </Grid>


                                {/* ROW5 */}
                                <Grid container style={{ textAlign: "center", marginTop: '10px' }} >
                                    <Grid item xs={4}>
                                        <TextField
                                            id="conChan"
                                            label="Counterparty Charge."
                                            placeholder="Placeholder"
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField
                                            id="conChanPosi"
                                            label="Counterparty Charge Position."
                                            placeholder="Placeholder"
                                            multiline
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField
                                            id="invoicedate"
                                            label="Invoice Date."
                                            placeholder="Placeholder"
                                            multiline
                                            value={this.state.pickedDateInvoice}
                                            onClick={this.openDatePickerInvoice}
                                            variant="outlined"
                                            style={{ margin: '10px' }}
                                        />
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Card>
                    </Grid>
                    {/* <button onClick={this.ReadyDataOne}>all</button> */}
                    {/* <Grid item xs={1}>
                            <Button  color="primary" onClick={this.checknext}> Next</Button>
                        </Grid> */}
                </Grid>
                <Grid container style={{ margin: "7px" }} >

                    <Grid item xs={2}>
                        <Button endIcon={<ArrowForwardIosIcon />} variant="contained" color="primary" onClick={this.checknext}> Next</Button>
                    </Grid>
                    <Grid item xs={10}>

                    </Grid>

                </Grid>
                {/* </Dialog> */}

            </>
        )
    }
}

export default DialogPrepared