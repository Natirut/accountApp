import React from 'react';
import Grid from '@material-ui/core/Grid';
import { Edit, Delete, AspectRatio } from '@material-ui/icons';
import AddIcon from '@material-ui/icons/Add';
import MenuItem from '@material-ui/core/MenuItem';
import Button from '@material-ui/core/Button';
import DialogPrepared from './main.component';
import Tooltip from '@material-ui/core/Tooltip';
import axios from 'axios';
import Axios from 'axios';
import DataTable from '../../components/datatable/index.component';
import SkeletonLoader from '../../components/skeleton/index.component'
import ViewInvoice from '../components/viewer.component';
import Confirm from '../../components/confirm/index.component';
import Skeleton from '../../components/skeleton/index.component';
import EditDialog from './dialogEditPrepare'

class RequesterPrepared extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            displayElement: null,
            columns: [],
            data: [],
            item: null,
            opendetail: false,
            confirm: false,
            deleteId: null,
            dialog_Edit: false,
            dataUpdate: [],
            datawastename:null
        }
        this.openPrepareForm = this.openPrepareForm.bind(this);
        this.rowData = this.rowData.bind(this);
        this.close = this.close.bind(this);
        this.viewInvoiceDetail = this.viewInvoiceDetail.bind(this);
        this.deleteClicked = this.deleteClicked.bind(this);
        this.deleteAction = this.deleteAction.bind(this);
        this.openEditForm = this.openEditForm.bind(this);
        this.cancle = this.cancle.bind(this);
        this.reload = this.reload.bind(this);
        this.GetWasteName = this.GetWasteName.bind(this);
        
        
    }
    async cancle() {
        await this.setState({dialog_Edit: false });
    }
    async openEditForm(item) {
        console.log(item)    
        await this.setState({ dataUpdate: item, })
        await this.setState({ dialog_Edit: true, })
    }
    close() {
        this.setState({ openForm: false, opendetail: false, confirm: false, })
    }
    async reload() {

        // console.log('ROWDATA')
        setTimeout(async () => {
            await this.setState({ displayElement: null })
            await this.setState({ displayElement: <SkeletonLoader />, })
            await this.rowData();
        }, 500);

        this.setState({ dialog_Edit: false });
    }
    viewInvoiceDetail(item) {
        this.setState({
            opendetail: true,
            item,
        })
    }
    async deleteAction(confirm) {
        try {
            if (confirm === true) {
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                })
                // console.log(this.state.deleteId)
                await instance.delete(`/fae-part/invoice/${this.state.deleteId}`);

                this.setState({ confirm: false, })

                this.rowData();
            }
        } catch (err) {
            console.log(err.stack)
            this.setState({ confirm: false, })
        }
    }
    deleteClicked(id) {
        this.setState({ confirm: true, deleteId: id });
    }

    async rowData() {
        try {
            this.setState({ displayElement: <Skeleton /> })
            const column = [
                { field: 'more', title: <b>Action</b>, align: 'center', },
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'contractNo', title: <b>Contract&nbsp;No.</b>, align: 'center', },
                { field: 'contractStartDate', title: <b>Contract&nbsp;Start.</b>, align: 'center', },
                { field: 'contractEndDate', title: <b>Contract&nbsp;End.</b>, align: 'center', },
                { field: 'counterpartyName', title:<b>Counterparty&nbsp;Name.</b> , align: 'center', },
                { field: 'phoneNo', title:<b>Phone.</b> , align: 'center', },
                { field: 'fax', title:<b>Fax.</b> , align: 'center', },
                { field: 'counterpartyAddress', title:<b>Address.</b> , align: 'center', },
                { field: 'counterpartyChange', title:<b>Counterparty&nbsp;Change.</b>, align: 'center', },
                { field: 'counterPartyChangePosition', title:<b>Counterparty&nbsp;Position.</b>, align: 'center', },
                { field: 'invoiceDate', title:<b>Invoice&nbsp;Date.</b>, align: 'center', },
                { field: 'typeBoi', title:<b>BOI.</b>, align: 'center', },
                { field: 'lotNo', title:<b>Lot&nbsp;No.</b>, align: 'center', },
                { field: 'moveOutDate', title:<b>Move&nbsp;Out&nbsp;Date.</b>, align: 'center', },
                { field: 'wasteName', title:<b>Waste&nbsp;Name.</b>, align: 'center', },

            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/invoice/prepared`);

            console.log(response.data)
            const row = [];

            // const record = new Promise((resolve) => {
            for (const item of response.data.data) {
                row.push(
                    {

                        more:
                            <>
                                <Grid container spacing={0}>
                                    <Grid item xs={12}>
                                        <Tooltip title="Expand" style={{ cursor: 'pointer', color: '#745c97' }}>
                                            <AspectRatio onClick={() => { this.viewInvoiceDetail(item) }} />
                                        </Tooltip>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Tooltip title="Edit" style={{ cursor: 'pointer', color: '#32afa9' }}>
                                        <Edit onClick={() => this.openEditForm(item)} />
                                        </Tooltip>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Tooltip title="Delete" style={{ cursor: 'pointer', color: '#f67280' }}>
                                            <Delete onClick={() => this.deleteClicked(item._id)} />
                                        </Tooltip>
                                    </Grid>
                                </Grid>
                            </>,
                        contractNo: item.contractNo,
                        contractStartDate: item.contractStartDate,
                        contractEndDate: item.contractEndDate,
                        counterpartyName: item.counterpartyName,
                        phoneNo: item.phoneNo,
                        fax: item.fax,
                        counterpartyAddress: item.counterpartyAddress,
                        counterpartyChange: item.counterpartyChange,
                        counterPartyChangePosition: item.counterPartyChangePosition,
                        invoiceDate: item.invoiceDate,
                        typeBoi: item.typeBoi,
                        lotNo: item.lotNo,
                        wasteName: item.wasteName,
                        moveOutDate: item.moveOutDate,

                    }
                )
            }
            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ displayElement: <DataTable title="Invoice on prepare" headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            console.log(err)
            if (err.response.status === 401) {

            }
            this.setState({ displayElement: <DataTable title="Invoice on prepare" headers={this.state.columns} data={[]} />, })
        }
    }
    componentDidMount() {
        this.rowData();
        this.GetWasteName()
        // this.setState({ displayElement: <DataTable headers={this.state.columns} data={this.state.data} title="Invoice on prepare" /> })
    }
    GetWasteName() {
        //  let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteName`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({
                        datawastename: res.data.data.map((item) => (
                            <MenuItem value={item.wasteName}>{item.wasteName} </MenuItem>
                        ))
                    });
                    console.log("dataa",res.data)
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    openPrepareForm() {
        this.setState({ displayElement: <DialogPrepared close={this.close} data={this.state.datawastename} /> })
    }
    render() {
        let showedit;
        if (this.state.dialog_Edit === true) {
            showedit = <EditDialog  cancle={this.cancle} data={this.state.dataUpdate} reload={this.reload} />
        }

        let opendetail; let confirm;

        if (this.state.opendetail === true) {
            opendetail = <ViewInvoice item={this.state.item} close={this.close} />
        }
        if (this.state.confirm === true) {
            confirm = <Confirm confirmed={this.deleteAction} content={{ header: "Confirm to remove this invoice.", description: "Delete this invoice and waste this invoice rollback to approve." }} />
        }
        return (
            <>
                {opendetail}{confirm}{showedit}

                <Grid container spacing={1} style={{ marginTop: 'calc(5%)' }}>
                    <Grid item xs={2}>

                    </Grid>
                    <Grid item xs={8}>

                    </Grid>
                    <Grid item xs={2}>
                        <Button
                            variant="contained"
                            color="primary"
                            size="medium"
                            startIcon={<AddIcon />}
                            style={{ backgroundColor: '#001247', color: '#bfcfff'}}
                            onClick={this.openPrepareForm}
                        >
                            Prepare
      </Button>
                    </Grid>
                    <Grid item xs={12}>
                        {this.state.displayElement}
                    </Grid>
                    {/* {dialogprepared} */}
                </Grid>
            </>
        )
    }
}

export default RequesterPrepared