import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import React from 'react'
import store from '../../redux/store'
import {nowtest} from '../../redux/action/counter'
import { name } from '../../redux/action/product'
class RequesterInput extends React.Component{
     constructor(props){
          super(props)
          this.state={

          }
        //   this.Sent = this.Sent.bind(this)
     }
     componentDidMount(){
          console.log("yjhnchyb")
     }
     Sent(){
        store.dispatch(nowtest(10))
        store.dispatch(name('now'))
     }
     Get(){
        console.log(store.getState())
        console.log( store.getState().counters)
       
     }
     render(){
         return(
             <>
              <Grid style={{marginTop:'200px'}}>
                <Button variant="contained" onClick={this.Sent}>Default</Button>
                <Button variant="contained" onClick={this.Get}>Gett</Button>
              </Grid>
             </>
         )
     }
}
export default RequesterInput

