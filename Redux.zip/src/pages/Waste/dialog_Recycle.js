
import React from 'react';
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import Button from '@material-ui/core/Button';
import Axios from 'axios';

class Recycle extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            name: null,
            open: false,
            slide: null,
            data_com: []
        }
        this.handleClose = this.handleClose.bind(this);
        this.insertCompany = this.insertCompany.bind(this);
        this.handleChange = this.handleChange.bind(this);

    }
    handleChange(event) {
        this.setState({
            name: event.target.value
        });
    }
    componentDidMount() {
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
    }
    handleClose() {
        this.props.close();
    }

    // close() {
    //     this.setState({ open_DialogRe: false, });
    // }
    async insertCompany() {
        const company = {
            companyName: this.state.name
        };
        // console.log(company)
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        // console.log(this.state.name)
        try {
              Axios.post(url,  company )
                .then( async res => {
                    console.log(res.data)
                    await this.handleClose();
                    await this.props.get();
                })
        } catch (err) {
            console.log(err.stack)
        }
      
    }
    render() {
        return (
            <>
                <Dialog open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#BEEACB', color: '#005F7E' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleClose}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Add Recycle company</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>
                        <TextField
                            autoFocus
                            margin="dense"
                            id="name"
                            label="Company"
                            type="email"
                            fullWidth
                            value={this.state.name}
                            onChange={this.handleChange}
                        />
                        <Button variant="contained" color="secondary" onClick={this.insertCompany}>
                            ADD
                    </Button>
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}
export default Recycle;