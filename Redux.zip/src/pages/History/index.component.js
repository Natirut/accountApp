import React from 'react';
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import TodayIcon from '@material-ui/icons/Today';
import { AspectRatio } from '@material-ui/icons';
import Tooltip from '@material-ui/core/Tooltip';
import DataTable from '../components/datatable/index.component'
import DatePickerRange from '../components/datepickerRange/index.component';
import Caronsol from '../components/imageCategory/index.component';

import Loading from '../../loading/index.component';

class History extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            expand: false,
            filesItem: [],
            element: null,
            pickerDate: false,
            pickedDateStart: "",
            pickedDateEnd: "",
            status: "",
            loading: false,
        }
        this.showExpand = this.showExpand.bind(this);
        this.rowData = this.rowData.bind(this);
        this.onSelectedDate = this.onSelectedDate.bind(this);
        this.openDatePicker = this.openDatePicker.bind(this);
        this.close = this.close.bind(this);
        this.cancle = this.cancle.bind(this);
    }
    close() {
        this.setState({ expand: false, });
    }
    cancle() {
        this.setState({ expand: false, });
    }
    showExpand(files) {
        console.log(files)
        this.setState({ expand: true, filesItem: files })
    }
    openDatePicker() {
        this.setState({ pickerDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ pickedDateStart: date.selectedDateStart })
            await this.setState({ pickedDateEnd: date.selectedDateEnd })
            await this.setState({ status: date.status })
            console.log("start", this.state.pickedDateStart)
            console.log("end", this.state.pickedDateEnd)
        }
        await this.setState({ pickerDate: false, })
        if (this.state.status === true) {
            await this.rowData();
        }

    }
    componentDidMount() {
        // this.rowData();
        this.setState({ element: <DataTable title="History Waste." headers={[]} data={[]} /> })
    }
    async rowData() {
        try {
            // console.log('ROWDATA')
            //  setTimeout(async () => {
            //      this.setState({element: <SkeletonLoader />,})
            //  }, 500);

            this.setState({ element: null, loading: true })
            const column = [
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'more', title:<b>Action</b> , align: 'center', },
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'typeBoi', title:<b>TypeBoi</b> , align: 'center', },
                { field: 'date', title: <b>Date</b>, align: 'center', },
                { field: 'time', title:<b>Time</b>, align: 'center', },
                { field: 'cptType', title:<b>CptType</b> , align: 'center', },
                { field: 'lotNo', title:<b>LotNo.</b> , align: 'center', },
                { field: 'companyApprove', title:<b>CompanyApprove.</b> , align: 'center', },
                { field: 'gennerateGroup', title:<b>GennerateGroup.</b> , align: 'center', },
                { field: 'wasteGroup', title:<b>WasteGroup.</b> , align: 'center', },
                { field: 'wasteName', title:<b>WasteName.</b> , align: 'center', },
                { field: 'totalWeight', title:<b>TotalWeight.</b> , align: 'center', },
                { field: 'containerWeight', title:<b>ContainerWeight.</b>, align: 'center', },
                { field: 'netWasteWeight', title:<b>NetWasteWeight.</b>, align: 'center', },
                { field: 'wasteContractor', title:<b>ContractortCompany.</b>, align: 'center', },
                { field: 'containerType', title:<b>containerType.</b>, align: 'center', },
                { field: 'phase', title:<b>Phase.</b>, align: 'center', },
                { field: 'status', title:<b>Status.</b>, align: 'center', },


            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                }
            });

            const dateRange = {
                "startDate": this.state.pickedDateStart,
                "endDate": this.state.pickedDateEnd
            }

            console.log(dateRange)
            const response = await instance.patch(`/fae-part/waste/history`, dateRange);



            const row = [];

            // const record = new Promise((resolve) => {
            for (const item of response.data.data) {
                row.push(
                    {
                        more:
                            <>
                                <Grid container spacing={0}>
                                    <Tooltip title="Expand" style={{ cursor: 'pointer', color: '#745c97' }}>
                                        <AspectRatio onClick={() => this.showExpand(item.files)} />
                                    </Tooltip>
                                </Grid>
                            </>,
                        typeBoi: item.typeBoi,
                        date: item.date,
                        time: item.time,
                        cptType: item.cptType,
                        lotNo: item.lotNo,
                        companyApprove: item.companyApprove,
                        gennerateGroup: item.gennerateGroup,
                        wasteGroup: item.wasteGroup,
                        wasteName: item.wasteName,
                        totalWeight: item.totalWeight,
                        containerWeight: item.containerWeight,
                        netWasteWeight: item.netWasteWeight,
                        wasteContractor: item.wasteContractor,
                        containerType: item.containerType,
                        phase: item.phase,
                        status: item.status,
                    }
                )
            }
            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, loading: false, })
                this.setState({ element: <DataTable title="History Waste." headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            console.log(err.stack)
            // if (err.response.status === 401) {
            //     localStorage.clear();
            //     ReactDOM.unmountComponentAtNode(document.getElementById('root'))
            //     ReactDOM.render(<Atp />, document.getElementById('root'));
            // }
            this.setState({ element: <DataTable title="History Waste." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    render() {
        let showexpand;
        if (this.state.expand === true) {
            showexpand = <Caronsol images={this.state.filesItem} close={this.close}   cancle={this.cancle} />
        }

        let datepicker;
        if (this.state.pickerDate === true) {
            datepicker = <DatePickerRange callBackClose={this.onSelectedDate} />
        }
        let loading;
        if (this.state.loading === true) {
            loading = <Loading />
        }
        return (
            <>{datepicker}{showexpand}
                <Grid container style={{ marginTop: '80px' }}>
                    <Grid item xs={10}>
                        {loading}
                    </Grid>
                    <Grid item xs={2}>
                        <Tooltip title="Search with date range.">
                            <TodayIcon style={{ cursor: 'pointer', color: '#007d00' }} onClick={this.openDatePicker} />
                        </Tooltip>
                        Select date range
                    </Grid>

                    <Grid item xs={4}>
                    </Grid>

                </Grid>
                <Grid container style={{ marginTop: '40px' }}>
                    <Grid item xs={12} >
                        {this.state.element}
                    </Grid>
                </Grid>


            </>
        )
    }
}
export default History