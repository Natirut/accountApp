

import React from 'react';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import Toolbar from '@material-ui/core/Toolbar';
import AppBar from '@material-ui/core/AppBar';
import Typography from '@material-ui/core/Typography';


// PROPS CONTEXT

// confirmed=function to call back(bool? confirm)
// content={ header:"", description: ""}

// PROPS CONTEXT

class Confirmation extends React.Component {

    constructor(props) {
        super(props);
        console.log(props)
        this.state = {
            open: false,
            fullScreen: null,
            header: props.content.header,
            description: props.content.description,
        }
        this.handleClose = this.handleClose.bind(this);
    }
    componentDidMount() {
        this.setState({
            open: true,
            // fullScreen: useMediaQuery(useTheme().breakpoints.down('sm'))
        })
    }
    handleClose(onconfirm) {
        this.setState({ open: false, })
        this.props.confirmed(onconfirm);
    }
    render() {
        return (
            <Dialog open={this.state.open} TransitionComponent={this.state.slide}>
                <AppBar style={{ position: 'relative', backgroundColor: '#dcd6f7', color: '#424874' }}>
                    <Toolbar>
                        <Typography variant="h6">{this.state.header}</Typography>
                    </Toolbar>
                </AppBar>
                <DialogContent style={{ height: '50px', width: '400px', overflow: 'hidden', }}>
                    <DialogContentText>{this.state.description}</DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => this.handleClose(true)} style={{ backgroundColor: '#e36387', color: 'aliceblue'}}>Yes</Button>
                    <Button onClick={() => this.handleClose(false)} style={{ backgroundColor: '#555555', color: 'aliceblue'}}>No</Button>
                </DialogActions>
            </Dialog>
        )
    }
}

export default Confirmation;