
import Axios from 'axios';
// import Button from '@material-ui/core/Button';
import React, { forwardRef } from 'react';
import MaterialTable from "material-table";
import ClearIcon from '@material-ui/icons/Clear';
import { MoreHoriz, Edit, DeleteForever } from '@material-ui/icons';
import CheckIcon from '@material-ui/icons/Check';
import SearchIcon from '@material-ui/icons/Search';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import LastPageIcon from '@material-ui/icons/LastPage';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import SortOutlinedIcon from '@material-ui/icons/SortOutlined';
import AddIcon from '@material-ui/icons/Add';

import { Tooltip } from '@material-ui/core';
// import MenuItem from '@material-ui/core/MenuItem';
// import InputLabel from '@material-ui/core/InputLabel';
import Grid from '@material-ui/core/Grid';
class Manage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            data_com: []
        }
    }
    componentDidMount() {
        this.GetCompany()
    }
    GetCompany() {
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    // this.setState({ data_com: res.data.data })
                    const data = [];
                    for (const item of res.data.data) {
                        item.action =
                            <Grid container spacing={1} style={{ textAlign: 'center' }}>
                                <Grid item xs={4}>
                                    <Tooltip title="Show waste name">
                                        <MoreHoriz style={{ cursor: 'pointer', color: '#46ca10' }} />
                                    </Tooltip>
                                </Grid>

                                <Grid item xs={4}>
                                <Tooltip title="Update">
                                    <Edit style={{ cursor: 'pointer', color: '#1d4980' }} />
                                    </Tooltip>
                                </Grid>
                                <Grid item xs={4}>
                                <Tooltip title="Delete">
                                    <DeleteForever style={{ cursor: 'pointer', color: '#e23a3a' }} />
                                    </Tooltip>
                                </Grid>
                            </Grid>

                        data.push(item);
                    }

                    this.setState({ data_com: data, },);
                }).catch((err) => {
                    console.log(err.stack);
                    if (err.response.status === 401) {
                        localStorage.clear();
                        window.history.pushState({}, document.title, '/waste');
                        window.location.reload();
                    }
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    delete(newdata) {
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company/"+newdata._id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company/${newdata._id}`
        Axios.delete(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
            .then(res => {
                this.componentDidMount()
                console.log(res);
                console.log(res.data);
            })
    }

    update(newdata) {
        console.log(newdata)
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company/"+newdata._id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company/${newdata._id}`
        Axios.put(url, newdata, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
            .then(res => {
                this.componentDidMount()
                console.log(res);
                console.log(res.data);
            })
    }
    async insert(newdata) {
        // let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        // console.log(this.state.name)
        try {
            Axios.post(url, newdata, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(async res => {
                    console.log(res.data)
                    this.componentDidMount()
                }).catch((err) => {
                    if (err.response.status === 401) {
                        localStorage.clear();
                        window.history.pushState({}, document.title, '/waste');
                        window.location.reload();
                    }
                })
        } catch (err) {
            if (err.response.status === 401) {
                localStorage.clear();
                window.history.pushState({}, document.title, '/waste');
                window.location.reload();
            }
        }
    }

    render() {
        return (
            <>
                <MaterialTable
                    icons={{
                        Clear: forwardRef((props, ref) => <ClearIcon {...props} ref={ref} />),
                        Check: forwardRef((props, ref) => <CheckIcon {...props} ref={ref} />),
                        Search: forwardRef((props, ref) => <SearchIcon {...props} ref={ref} />),
                        FirstPage: forwardRef((props, ref) => <FirstPageIcon {...props} ref={ref} />),
                        LastPage: forwardRef((props, ref) => <LastPageIcon {...props} ref={ref} />),
                        NextPage: forwardRef((props, ref) => <NavigateNextIcon {...props} ref={ref} />),
                        PreviousPage: forwardRef((props, ref) => <ArrowBackIosIcon {...props} ref={ref} />),
                        ResetSearch: forwardRef((props, ref) => <ClearIcon {...props} ref={ref} />),
                        SortArrow: forwardRef((props, ref) => <SortOutlinedIcon {...props} ref={ref} />),
                        Add: forwardRef((props, ref) => <AddIcon {...props} ref={ref} />),
                    }}
                    columns={[
                        { title: 'Company Name.', field: 'companyName', headerStyle: { textAlign: 'center', backgroundColor: 'rgb(255 152 0 / 38%)' }},
                        { title: 'Action.', field: 'action', headerStyle: { textAlign: 'center', backgroundColor: 'rgb(255 152 0 / 38%)' } },

                    ]}
                    style={{ maxWidth: '100%' }}
                    data={this.state.data_com}
                    title="Company"
                    localization={{

                    }}
                    options={{
                        rowStyle: { backgroundColor: 'rgb(158 158 158 / 15%)'},
                    }}
                // editable={{
                //     onRowUpdate: (newData, oldData) =>
                //         new Promise((resolve) => {
                //             setTimeout(() => {
                //                 this.update(newData);
                //                 resolve();
                //             }, 600);
                //         }),
                //     onRowDelete: (newData, oldData) =>
                //         new Promise((resolve) => {
                //             setTimeout(() => {
                //                 this.delete(newData);
                //                 resolve();
                //             }, 600);
                //         }),
                //     onRowAdd: (newData, oldData) =>
                //         new Promise((resolve) => {
                //             setTimeout(() => {
                //                 this.insert(newData);
                //                 resolve();
                //             }, 600);
                //         }),

                // }}

                />
            </>


        )
    }
}
export default Manage
