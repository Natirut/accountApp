
import React, { Component } from 'react';

import { Button, Grid, AppBar, Typography, Toolbar, IconButton, Checkbox } from '@material-ui/core';
import { NavigateNext, ArrowForward, Add, Delete, FastForward, FastRewind } from '@material-ui/icons';
import { Dialog, List, ListItem, ListItemText, ListItemSecondaryAction, ListItemIcon } from '@material-ui/core';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';

import Success from '../../../components/successBar/index.component';

import axios from 'axios';
import _ from 'lodash';

// import store from '../../../../redux/store';
// import { increment, decrement } from '../../../../redux/action/counter';

const data = {};

export default class AddwasteGroup extends Component {

    constructor() {
        super();

        this.state = {
            open: false,
            groupName: '',
            wastenameElement: null,
            subordinateElement: null,
            memberElement: null,
            memberList: [],
            subordinateList: [],
            subordinate: '',
            memberSelection: 'default',
            wasteNameData: [],
            wasteNameData_tmp: [],
            checkedItems: [],
            dataMapping: {},
            success: false,
        }
        this.getwasteName = this.getwasteName.bind(this);
        this.addSubordinate = this.addSubordinate.bind(this);
        this.checkSubordinate = this.checkSubordinate.bind(this);
        this.removeSubordinate = this.removeSubordinate.bind(this);
        this.create = this.create.bind(this);
        this.setGroupname = this.setGroupname.bind(this);
        this.memberSelection = this.memberSelection.bind(this);
        this.createWasteBox = this.createWasteBox.bind(this);
        this.handleMoveAll = this.handleMoveAll.bind(this);
        this.createMemberBox = this.createMemberBox.bind(this)
        this.create = this.create.bind(this);
        this.removeOneMember = this.removeOneMember.bind(this);
        this.handleBackAll = this.handleBackAll.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleChecked = this.handleChecked.bind(this);
        this.handleAddChecked = this.handleAddChecked.bind(this);
    }

    componentDidMount() {
        this.setState({ open: true, });

        // REDUX USAGE
        // console.log(store);
        // store.dispatch(increment(3))
        // store.getState().counters
        // REDUX USAGE
        this.getwasteName();
    }
    handleClose() {
        this.props.close();
    }
    componentWillUnmount() {
        this.setState({ open: false, })
    }
    async create() {
        try {
            const mappingKey = Object.keys(this.state.dataMapping);

            const subordnate = [];
            for (const key of mappingKey) {
                const subordnate_obj = {};
                subordnate_obj.subordnatewaste = key;
                const subordnateWastename = [];
                for (const item of this.state.dataMapping[key]) {
                    subordnateWastename.push(item.wasteName)
                }
                subordnate_obj.wasteName = subordnateWastename;
                subordnate.push(subordnate_obj);
            }

            const wasteName = [];

            for (const item of subordnate) {
                for (const waste of item.wasteName) {
                    wasteName.push(waste)
                }
            }
            const body = {
                groupName: this.state.groupName,
                wasteName: _.uniqBy(wasteName),
                subordnate,

            }
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, },
            });

            await instance.post(`/fae-part/wasteGroup`, body);

            this.setState({ success: true, })

            setTimeout(() => {
                this.handleClose();
            }, 2000);
            // console.log(response);

            console.log('BODY: ', body);
        } catch (error) {
            console.log(error.stack);
        }
    }
    async removeOneMember(record) {
        const onelementMember = this.state.memberList.filter(item => item.wasteName !== record.wasteName);

        await this.setState({ memberList: onelementMember });

        this.state.wasteNameData.push(record);

        // update dataMapping
        const removeFormmapping = this.state.dataMapping[this.state.memberSelection].filter(item => item.wasteName !== record.wasteName);

        this.state.dataMapping[this.state.memberSelection.toString()] = removeFormmapping;
        // update dataMapping

        await this.createWasteBox();
        await this.createMemberBox();
    }
    async memberSelection(event) {
        try {
            await this.setState({ memberSelection: event.target.value });
            await this.setState({ wasteNameData: this.state.wasteNameData_tmp });

            if (this.state.dataMapping[this.state.memberSelection] !== undefined) {
                this.setState({
                    wasteNameData: _.differenceWith(this.state.wasteNameData, this.state.dataMapping[this.state.memberSelection], _.isEqual),
                    // wasteNameData: this.state.dataMapping[this.state.memberSelection]
                    memberList: this.state.dataMapping[this.state.memberSelection],
                });
                // await this.createMemberBox();
            } else {
                if (this.state.dataMapping[this.state.memberSelection] !== undefined) {
                    await this.setState({ memberList: this.state.dataMapping[this.state.memberSelection] })
                    await this.setState({ wasteNameData: this.state.wasteNameData.filter(val => !this.state.dataMapping[this.state.memberSelection].includes(val)) });
                } else {
                    await this.setState({ memberList: [] })
                }
            }
            await this.createWasteBox();
            await this.createMemberBox();
        } catch (err) {
            console.log(err.stack);
        }

    }
    async handleMoveAll() {
        data[this.state.memberSelection] = this.state.wasteNameData
        // = this.state.wasteNameData;

        await this.setState({ dataMapping: data })

        if (this.state.memberList.length === 0) {
            await this.setState({ memberList: this.state.wasteNameData })
        } else {
            const mergeRighttoLeft = this.state.memberList.concat(this.state.wasteNameData);
            this.setState({ memberList: mergeRighttoLeft })
        }
        await this.setState({ wasteNameData: [], })

        await this.createWasteBox();
        await this.createMemberBox();

    }
    async handleBackAll() {
        await this.setState({ wasteNameData: this.state.wasteNameData_tmp });
        await delete this.state.dataMapping[this.state.memberSelection];
        await this.setState({ memberList: [], });

        await this.createWasteBox();
        await this.createMemberBox();
    }
    async handleAddChecked() {
        if (this.state.dataMapping[this.state.memberSelection] && this.state.dataMapping[this.state.memberSelection].length !== 0) {
            const dataMapping = this.state.dataMapping;

            dataMapping[this.state.memberSelection] = _.uniqBy([].concat(this.state.dataMapping[this.state.memberSelection], this.state.checkedItems), 'wasteName');
            await this.setState({ dataMapping, });
            await this.setState({ wasteNameData: _.differenceWith(this.state.dataMapping[this.state.memberSelection], this.state.wasteNameData_tmp, _.isEqual) })

            await this.setState({ memberList: _.differenceWith(this.state.dataMapping[this.state.memberSelection], this.state.wasteNameData, _.isEqual) })
        } else {
            const dataMapping = this.state.dataMapping;
            dataMapping[this.state.memberSelection] = this.state.checkedItems;
            await this.setState({ memberList: this.state.checkedItems });
            await this.setState({ dataMapping, });
            await this.setState({ wasteNameData: _.differenceWith(this.state.wasteNameData_tmp, this.state.dataMapping[this.state.memberSelection], _.isEqual) })
        }
        await this.setState({ checkedItems: [] });
        await this.createMemberBox();
        await this.createWasteBox();

        document.getElementsByName('wastename').forEach((item) => {
            item.checked = false;
        })
    }
    handleChecked(event, item) {
        if (event.target.checked === true) {
            this.state.checkedItems.push(item);
        } else {
            this.setState({
                checkedItems: this.state.checkedItems.filter(row => row.wasteName !== item.wasteName),
            });
        }
    }
    setGroupname(event) {
        this.setState({ groupName: event.target.value });
    }
    checkSubordinate(event) {
        if (event.keyCode === 13) {
            this.addSubordinate();
            return;
        }
        this.setState({ subordinate: event.target.value });
    }
    async removeSubordinate(value) {
        console.log('removeSubordinate: ', value);
        await this.setState({ subordinateList: this.state.subordinateList.filter(item => item !== value) })
        await this.addSubordinate();

    }
    addSubordinate() {
        if (this.state.subordinate !== '') {
            this.state.subordinateList.unshift(this.state.subordinate);
        }
        this.setState({
            subordinateElement: this.state.subordinateList.map((item) => (
                <ListItem>
                    <ListItemText primary={item} />
                    <ListItemSecondaryAction>
                        <IconButton edge="end" aria-label="delete">
                            <Delete onClick={() => this.removeSubordinate(item)} style={{ color: '#f95757' }} />
                        </IconButton>
                    </ListItemSecondaryAction>
                </ListItem>
            ))
        });
        this.setState({ subordinate: '' });
        document.getElementById('subordinateWaste').value = '';
    }
    async getwasteName() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, },
            });
            const response = await instance.get(`/fae-part/wasteName`);

            this.setState({ wasteNameData_tmp: response.data.data });
            this.setState({ wasteNameData: response.data.data });
            this.createWasteBox();

        } catch (error) {
            console.log(error.stack);
        }
    }

    createWasteBox() {
        this.setState({ checkedItems: [] });
        this.setState({ wastenameElement: '...', })
        this.setState({
            wastenameElement: this.state.wasteNameData.map((item) => (
                <ListItem>
                    <ListItemIcon>
                        <Checkbox
                            name="wastename"
                            value={item.wasteName}
                            onChange={(e) => this.handleChecked(e, item)}
                        />
                    </ListItemIcon>
                    <ListItemText primary={item.wasteName} />
                </ListItem >
            ))
        })
    }
    createMemberBox() {
        this.setState({ memberElement: '...' });
        this.setState({
            memberElement: this.state.memberList.map((item) => (
                <ListItem>
                    <ListItemText primary={item.wasteName} />
                    <ListItemSecondaryAction>
                        <IconButton edge="end" aria-label="delete" onClick={() => this.removeOneMember(item)}>
                            <Delete style={{ color: '#f95757' }} />
                        </IconButton>
                    </ListItemSecondaryAction>
                </ListItem>
            ))
        })
    }
    render() {
        let success;

        if (this.state.success === true) {
            success = <Success message="Create group success" />
        }
        return (
            <>
            {success}
                <Dialog open={this.state.open} onClose={this.handleClose}>
                    <AppBar style={{ position: 'relative', backgroundColor: 'rgb(2 4 43)', }}>
                        <Toolbar>
                            <Typography variant="h6">Create waste group</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent style={{ height: '620px', width: '500px', overflow: 'hidden', }}>

                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField
                                    margin="dense"
                                    label="Group name"
                                    type="text"
                                    fullWidth
                                    required
                                    onChange={this.setGroupname}
                                    value={this.state.groupName}
                                />
                            </Grid>
                        </Grid>

                        {/* subordinate waste */}
                        <Grid container spacing={1}>
                            <Grid item xs={11}>
                                <TextField
                                    margin="dense"
                                    id="subordinateWaste"
                                    label="subordinate waste"
                                    type="text"
                                    fullWidth
                                    onKeyDown={this.checkSubordinate}
                                    onChange={this.checkSubordinate}
                                />
                            </Grid>

                            <Grid item xs={1}>
                                <IconButton> <Add /> </IconButton>
                            </Grid>

                            <Grid container spacing={1}>

                                <Grid item xs={12} style={{ borderStyle: 'solid', padding: '10px', borderColor: 'rgb(25 4 76 / 82%)', height: '200px', overflow: 'scroll' }}>
                                    <List>
                                        {this.state.subordinateElement}
                                    </List>
                                </Grid>

                            </Grid>
                        </Grid>



                        {/* TRANFER LIST */}
                        <Grid container spacing={1} style={{ marginTop: 'calc(2%)' }}>
                            <Grid item xs={5} style={{ textAlign: 'center' }}>
                                <Typography>Waste name</Typography>
                            </Grid>
                            <Grid item xs={2} style={{ textAlign: 'center' }}>
                                <ArrowForward style={{ color: '#3e12ab' }} />
                            </Grid>
                            <Grid item xs={5} style={{ textAlign: 'center' }}>
                                {/* <Typography>Member</Typography> */}
                                <select onChange={this.memberSelection}>
                                    <option value={this.state.groupName}>
                                        {(this.state.groupName === '' ? 'Please input group name' : this.state.groupName)}
                                    </option>
                                    {/* <option value="subordinate">subordinate name</option> */}
                                    {this.state.subordinateList.map((item) => (
                                        <option value={item}>{item}</option>
                                    ))}
                                </select>
                            </Grid>
                        </Grid>

                        <Grid container spacing={2} style={{ marginTop: 'calc(2%)' }}>

                            <Grid container spacing={1}>
                                <Grid item xs={5} style={{ borderStyle: 'solid', borderColor: '#0790839e', height: '250px', overflow: 'scroll' }}>
                                    <List>
                                        {this.state.wastenameElement}
                                    </List>
                                </Grid>
                                <Grid item xs={2} style={{ textAlign: 'center', alignSelf: 'center' }}>
                                    <IconButton onClick={this.handleMoveAll}> <FastForward style={{ color: '#5bc518' }} /> </IconButton>
                                    <IconButton onClick={this.handleAddChecked}> <NavigateNext style={{ color: '#795548' }} /> </IconButton>
                                    <IconButton onClick={this.handleBackAll}> <FastRewind style={{ color: '#e44040' }} /> </IconButton>
                                </Grid>
                                <Grid item xs={5} style={{ borderStyle: 'solid', padding: '10px', borderColor: '#266296b8' }}>
                                    <List>
                                        {this.state.memberElement}
                                    </List>
                                </Grid>
                            </Grid>
                        </Grid>
                    </DialogContent>
                    <DialogActions>
                        <Button color="primary" style={{ backgroundColor: '#880e0e', color: 'aliceblue' }} onClick={this.handleClose}>
                            Close
          </Button>
                        <Button color="primary" style={{ backgroundColor: '#0f0946', color: 'aliceblue' }} onClick={this.create}>
                            Save
          </Button>
                    </DialogActions>
                </Dialog>
            </>
        )
    }
}
