

import React, { Component } from 'react';

import { Button, Grid, AppBar, Typography, Toolbar, } from '@material-ui/core';
// import { NavigateNext, ArrowForward, Add, Delete, FastForward, FastRewind } from '@material-ui/icons';
import { Dialog, List, ListItemText, ListItem, ListItemSecondaryAction, IconButton, } from '@material-ui/core';
import { Delete } from '@material-ui/icons'
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import { Autocomplete } from '@material-ui/lab';
import axios from 'axios';
import Success from '../../../components/successBar/index.component';

export default class CreateWasteName extends Component {
    constructor() {
        super();

        this.state = {
            open: false,
            success: false,
            wastename: '',
            groupName: '',
            groupData: [],
            companyData: [],
            companySelected: [
            ],
            companySelectedEle: null,
        };
        this.changedWasteName = this.changedWasteName.bind(this);
        this.getCompany = this.getCompany.bind(this);
        this.getGroupList = this.getGroupList.bind(this);
        this.companySelectedDisplay = this.companySelectedDisplay.bind(this);
        this.removeOneMember = this.removeOneMember.bind(this);
        this.create = this.create.bind(this);
        this.onSelectGroup = this.onSelectGroup.bind(this);
        this.handleClose = this.handleClose.bind(this);
    }
    componentDidMount() {
        this.setState({ open: true })
        this.getGroupList();
        this.getCompany();
    }
    componentWillUnmount() {
        this.setState({ open: false, })
    }
    async create() {
        try {
            const body = {
                wasteName: this.state.wastename,
                biddingType: document.getElementById('biddingType').value,
                wasteGroup: this.state.groupName,
                company: this.state.companySelected
            }
            console.log('BODY: ', body);
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            await instance.post(`/fae-part/wasteName`, body);

            this.setState({ success: true, })
            setTimeout(() => {
                this.setState({ success: false, })
            }, 2000);
        } catch (error) {
            console.log(error.stack);
        }
    }
    onSelectGroup(event, data) {
        console.log(data);
        if (data !== null) {
            this.setState({ groupName: data.groupName });
        }
    }
    async onSelectComapny(event, data) {
        console.log(data);
        if (data !== null) {

            await this.setState({ companyData: this.state.companyData.filter(item => item.companyName !== data.companyName) })
            await this.state.companySelected.push(data.companyName);
            await this.companySelectedDisplay()
        }
    }
    async getCompany() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/company`);
            this.setState({ companyData: response.data.data })

        } catch (error) {
            console.log(error.stack);
        }
    }
    changedWasteName(event) {
        this.setState({ wastename: event.target.value })
    }
    async removeOneMember(companyName) {
        const company = this.state.companyData;

        company.unshift({ companyName, });
        await this.setState({ companyData: company });
        await this.setState({ companySelected: this.state.companySelected.filter(item => item !== companyName) })
        this.companySelectedDisplay();
    }
    companySelectedDisplay() {
        this.setState({
            companySelectedEle: this.state.companySelected.map((item) => (
                <ListItem>
                    <ListItemText primary={item} />
                    <ListItemSecondaryAction>
                        <IconButton edge="end" aria-label="delete" onClick={() => this.removeOneMember(item)}>
                            <Delete style={{ color: '#f95757' }} />
                        </IconButton>
                    </ListItemSecondaryAction>
                </ListItem>
            ))
        })
    }
    async getGroupList() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/wasteGroup`);
            this.setState({ groupData: response.data.data })
        } catch (error) {
            console.log(error.stack);
        }
    }
    handleClose() {
        this.props.close();
    }
    componentWillUnmount() {
        this.setState({ open: false, })
    }
    render() {
        let success;

        if (this.state.success === true) {
            success = <Success message="Create waste name success" />
        }
        return (
            <Dialog open={this.state.open} onClose={this.handleClose}>
                {success}
                <AppBar style={{ position: 'relative', backgroundColor: 'rgb(3 78 8)', }}>
                    <Toolbar>
                        <Typography variant="h6">Create waste name</Typography>
                    </Toolbar>
                </AppBar>
                <DialogContent style={{ height: '450px', width: '500px', overflow: 'hidden', }}>

                    <Grid container spacing={2}>
                        <Grid item xs={6}>
                            <TextField
                                margin="dense"
                                label="waste name"
                                type="text"
                                fullWidth
                                required
                                onChange={this.changedWasteName}
                                value={this.state.wastename}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <TextField
                                margin="dense"
                                label="Bidding type"
                                type="text"
                                id="biddingType"
                                fullWidth
                                required
                            />
                        </Grid>
                    </Grid>

                    {/* SELECTED GROUP */}
                    <Grid container spacing={2} style={{ marginTop: 'calc(2%)' }}>
                        <Grid item xs={12}>
                            <Autocomplete
                                options={this.state.groupData}
                                getOptionLabel={(option) => option.groupName}
                                style={{ width: '100%' }}
                                onChange={(event, newValue) => {
                                    this.onSelectGroup(event, newValue)
                                }}
                                renderInput={(params) => <TextField {...params} label="select group" variant="outlined" />}
                            />
                        </Grid>
                    </Grid>


                    {/* COMPANY TRANFER */}
                    <Grid container spacing={1} style={{ marginTop: 'calc(4%)' }}>

                        <Grid item xs={6}>
                            <Autocomplete
                                options={this.state.companyData}
                                getOptionLabel={(option) => option.companyName}
                                style={{ width: 200 }}
                                disableCloseOnSelect
                                onChange={(event, newValue) => {
                                    this.onSelectComapny(event, newValue)
                                }}
                                renderInput={(params) => <TextField {...params} label="select Company" variant="outlined" />}
                            />
                        </Grid>
                        <Grid item xs={6} style={{ borderStyle: 'solid', borderColor: 'rgb(227 228 236)', height: '200px', overflow: 'scroll', borderRadius: '8px' }}>
                            <List>
                                {this.state.companySelectedEle}
                            </List>
                        </Grid>
                    </Grid>

                </DialogContent>
                <DialogActions>
                    <Button color="primary" style={{ backgroundColor: '#880e0e', color: 'aliceblue' }} onClick={this.handleClose}>
                        Close
          </Button>
                    <Button color="primary" style={{ backgroundColor: '#0f0946', color: 'aliceblue' }} onClick={this.create}>
                        Save
          </Button>
                </DialogActions>
            </Dialog>
        )
    }
}
