import React from 'react'
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import Checkbox from '@material-ui/core/Checkbox';
import Grid from '@material-ui/core/Grid';
import Axios from 'axios';
import ListItem from '@material-ui/core/ListItem';
// import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import { ListItemIcon } from '@material-ui/core';
import { NavigateNext,  ArrowForward, FastForward, FastRewind,  Delete } from '@material-ui/icons';
class addCompany extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            slide: null,
            datawastename: null,
            datalist: null,
            datalistgroup: null,
            body: [],
            bodyone: [],
            bodygroup: [],
            value: null,
            bodytmp: [],
            tmpPassOne:[],
            tmpDif:[],
            rowdata:[],
            rowdata2:[]
        }
        console.log(this.props)
        this.handleCancle = this.handleCancle.bind(this);
        this.getWastename = this.getWastename.bind(this);
        this.SetListWastename = this.SetListWastename.bind(this);
        this.PassOne = this.PassOne.bind(this);
        this.SetbodyToArr = this.SetbodyToArr.bind(this);
        this.PassAll = this.PassAll.bind(this);
        this.BackAll = this.BackAll.bind(this);
       
        this.removeOneMember = this.removeOneMember.bind(this);
        this.Write_Wastename = this.Write_Wastename.bind(this);
        this.Write_Group = this.Write_Group.bind(this);
        

    }
  async  removeOneMember(data){
         var _ = require('lodash');
         await this.state.rowdata.push(data)
        //  await this.state.rowdata2.push(_.difference(this.state.bodygroup,_.uniq(this.state.rowdata)))
      
         //this.setState({})
        //  await this.setState({})
        // left
        //  console.log("Group",this.state.bodygroup)
        //   console.log("tr",_.difference(this.state.bodygroup,_.uniq(this.state.rowdata)))
          
         await this.setState({ body: _.uniq(this.state.rowdata) })
        //  await this.setState({ bodygroup:  _.uniq(this.state.rowdata2)})
         this.Write_Wastename()
        //  this.Write_Group()
        //  console.log("remove one",data)
        //  console.log("all",this.state.bodytmp)
        //  const test =  this.state.bodytmp.filter(item => item !== data);
       
        //  console.log("d",test)
       
    }
    Write_Wastename(){
        this.setState({
            datalist: this.state.body.map((item) => (
                <ListItem key={item} role="listitem" button >
                    <ListItemIcon>
                        <Checkbox
                            disableRipple
                            name="wastename"
                            value={item}
                            // onChange={e => this.CheckOne(e, item)}
                        />
                    </ListItemIcon>
                    <ListItemText id={item} primary={item} />
                </ListItem>
            ))
        })
    }
    Write_Group() {
        this.setState({
            datalistgroup: this.state.bodygroup.map((item) => (
                <ListItem key={item} role="listitem" button>
                    <ListItemText primary={item} />
                    <IconButton edge="end" aria-label="delete" onClick={() => this.removeOneMember(item)}>
                        <Delete style={{ color: '#f95757' }} />
                    </IconButton>
                </ListItem>
            ))
        })
    }
    async PassAll() {
        console.log("All")
        await this.setState({ bodygroup: this.state.bodytmp })
        await this.setState({ body: [] })
        await this.Write_Group()
        this.setState({
            datalist: []
        })
    }
    async BackAll() {
        console.log("Back")
        this.setState({ tmpPassOne:[]})
        await this.setState({ bodygroup: [] })
        await this.setState({ body: this.state.bodytmp })
        await this.Write_Wastename()
        this.setState({
            datalistgroup: []
        })
    }
  async  PassOne() {
     await this.setState({
            datalistgroup: this.state.tmpPassOne.map((item) => (
                <ListItem key={item} role="listitem" button >
                    <ListItemText id={item} primary={item} />
                    {/* <ListItemSecondaryAction> */}
                    <IconButton edge="end" aria-label="delete" onClick={() => this.removeOneMember(item)}>
                            <Delete style={{ color: '#f95757' }} />
                        </IconButton>
                    {/* </ListItemSecondaryAction>  */}
                </ListItem>
            ))
        })
        var _ = require('lodash');
        // console.log("dif",_.difference(this.state.bodytmp,this.state.tmpPassOne))
        await  this.setState({
             tmpDif: _.difference(this.state.bodytmp,this.state.tmpPassOne)
           })

           await  this.setState({
            datalist: this.state.tmpDif.map((item) => (
                <ListItem key={item} role="listitem" button >
                    <ListItemIcon>
                        <Checkbox
                            disableRipple
                            name="wastename"
                            value={item}
                            onChange={e => this.CheckOne(e, item)}
                        />
                    </ListItemIcon>
                    <ListItemText id={item} primary={item} />
                </ListItem>
            ))
        })



    }
    async CheckOneeeee(e, data) {
        //  await this.setState({value:e.target.value})
        console.log("check", e.target.checked)
        console.log("val", e.target.value)
        if (e.target.checked) {
            this.setState({
                bodygroup: this.state.bodygroup.concat([e.target.value])
            })
            // var _ = require('lodash');
            let tmp = []

            tmp = this.state.body.splice(e.target.value)
            console.log("tm", tmp)
        }
        else {
            let filteredArray = await this.state.bodygroup.filter(item => item !== data)
            await this.setState({
                bodygroup: filteredArray
            });
        }

        // else {
        //     let filtered = await this.state.bodygroup.filter(item => item !== data)
        //     await this.setState({
        //         body: filtered
        //     });
        // }
        //     var _ = require('lodash');
        //     this.setState({
        //         body: _.difference(this.state.body,this.state.bodygroup)
        //    })

        //    console.log("body new",this.state.body)

        console.log("body", this.state.bodyone)
        console.log("bodygroup", this.state.bodygroup)
    }
   async  CheckOne(e, data) {
        if (e.target.checked) {
           await this.setState({
                tmpPassOne: this.state.tmpPassOne.concat([e.target.value])
            })
            
        }else{
            let filteredArray = await this.state.tmpPassOne.filter(item => item !== data)
            await this.setState({
                tmpPassOne: filteredArray
            });
        }
        console.log("tmp",this.state.tmpPassOne)
        
    }

    SetListWastename() {
        this.setState({
            datalist: this.state.body.map((item) => (
                <ListItem key={item} role="listitem" button >
                    <ListItemIcon>
                        <Checkbox
                            disableRipple
                            name="wastename"
                            value={item}
                            onChange={e => this.CheckOne(e, item)}
                        />
                    </ListItemIcon>
                    <ListItemText id={item} primary={item} />
                </ListItem>
            ))
        })


    }
    async getWastename() {
        try {
            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                }
            })

            const response = await instance.get(`/fae-part/wasteName`);
            console.log("lll", response.data.data)
            this.setState({ datawastename: response.data.data })
            console.log("response", this.state.datawastename)
        } catch (err) {
            console.log(err.stack)
        }

    }
    SetbodyToArr() {
        for (let i = 0; i < this.state.datawastename.length; i++) {
            this.state.bodytmp.push(this.state.datawastename[i].wasteName)
        }

        this.setState({ body: this.state.bodytmp })

        console.log("ooo", this.state.body)
    }
    async componentDidMount() {
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
        await this.getWastename()
        await this.SetbodyToArr()
        this.SetListWastename()
    }
    handleCancle() {
        // this.setState({ open: false, })
        this.props.cancle();
    }
    render() {
        return (
            <>
                <Dialog open={this.state.open} onClose={this.handleCancle} fullWidth="true"
                    maxWidth="sm" TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#BEEACB', color: '#005F7E' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleCancle}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Add Company</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent style={{ height: '400px', overflow: 'hidden', }}>

                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField
                                    margin="dense"
                                    id="companyname"
                                    label="Company name"
                                    type="text"
                                    fullWidth
                                    required
                                />
                            </Grid>
                        </Grid>
                        <Grid container spacing={1} style={{ marginTop: 'calc(2%)' }}>
                            <Grid item xs={5} style={{ textAlign: 'center' }}>
                                <Typography>Waste name</Typography>
                            </Grid>
                            <Grid item xs={2} style={{ textAlign: 'center' }}>
                                <ArrowForward style={{ color: '#3e12ab' }} />
                            </Grid>
                            <Grid item xs={5} style={{ textAlign: 'center' }}>
                                <Typography>This group</Typography>
                            </Grid>
                        </Grid>

                        <Grid container spacing={2} style={{ marginTop: 'calc(2%)' }}>

                            <Grid container spacing={1}>
                                <Grid item xs={5} style={{ borderStyle: 'solid', padding: '10px', borderColor: '#0790839e', height: '200px', overflow: 'scroll' }}>
                                    {this.state.datalist}
                                </Grid>
                                <Grid item xs={2} style={{ textAlign: 'center' }}>
                                    <IconButton onClick={this.PassAll}> <FastForward /> </IconButton>
                                    <IconButton onClick={this.PassOne}> <NavigateNext /> </IconButton>
                                    {/* <IconButton> <NavigateBefore /> </IconButton> */}
                                    <IconButton onClick={this.BackAll}> <FastRewind /> </IconButton>
                                </Grid>
                                <Grid item xs={5} style={{ borderStyle: 'solid', padding: '10px', borderColor: '#266296b8', height: '200px', overflow: 'scroll' }}>
                                    {this.state.datalistgroup}
                                </Grid>
                            </Grid>
                        </Grid>
                        {/* <Button variant="contained" color="secondary" >
                            ADD Company
                    </Button> */}
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}
export default addCompany

