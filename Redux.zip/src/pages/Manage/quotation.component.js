
import React from 'react';

import DataTable from '../components/datatable/index.component';
import axios from 'axios';


class Quotation extends React.Component {
    constructor() {
        super();

        this.state = {
            headers: [
                { title: 'Quotation no.', field: 'quotationNo' },
                { title: 'Waste name', field: 'wasteName' },
                { title: 'Unit price', field: 'unitPrice' },
            ],
            data: [],
            element: null,
        }
        this.rowData = this.rowData.bind(this)
        this.addData = this.addData.bind(this)
        this.deleteData = this.deleteData.bind(this);
        this.updateData = this.updateData.bind(this);
    }
    componentDidMount() {
        this.rowData();
    }
    async addData(data) {
        const body = {
            quotationNo: data.quotationNo,
            wasteName: data.wasteName,
            unitPrice: parseFloat(data.unitPrice),
        }
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
            await instance.post(`/fae-part/quotation`, body)
            this.setState({ element: null, })
            this.rowData();

        } catch (err) {
            console.log(err.stack)
        }
    }
    async updateData(data) {
        try {
            data.unitPrice = parseFloat(data.unitPrice);
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
            await instance.put(`/fae-part/quotation/${data._id}`, data)
            this.setState({ element: null, })
            this.rowData();

        } catch (err) {
            console.log(err.stack)
        }

    }
    async deleteData(data) {
        // console.log('On delete: ', data)
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    // 'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
            await instance.delete(`/fae-part/quotation/${data._id}`)
            this.setState({ element: null, })
            this.rowData();

        } catch (err) {
            console.log(err.stack)
        }
    }
    async rowData() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    // 'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            });
            const response = await instance.get(`/fae-part/quotation`);

            // console.log(response.data.data)
            this.setState({ data: response.data.data })

            this.setState({
                element:
                    <DataTable headers={this.state.headers}
                        data={this.state.data}
                        title="Quotations"
                        onUpdate={this.updateData}
                        onDelete={this.deleteData}
                        onInsert={this.addData}
                        editable={true}
                    />
            })
        } catch (err) {
            console.log(err.stack)
        }
    }
    render() {
        return (
            <>
                {this.state.element}
            </>
        )
    }
}

export default Quotation;
