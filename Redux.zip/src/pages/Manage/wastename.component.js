
import React, { Component } from 'react';

import Datatable from '../components/datatable/index.component';
import { Edit, DeleteForever } from '@material-ui/icons';
import { Grid } from '@material-ui/core';
import axios from 'axios';

class WasteName extends Component {

    constructor(props) {
        super(props);

        this.state = {
            header: [
                { title: 'Waste name', field: 'wasteName', headerStyle: { backgroundColor: 'rgb(255 152 0 / 38%)' } },
                { title: 'Waste Group', field: 'wasteGroup', headerStyle: { backgroundColor: 'rgb(255 152 0 / 38%)' } },
                { title: 'Company', field: 'company', headerStyle: { backgroundColor: 'rgb(255 152 0 / 38%)' } },
                { title: 'Action', field: 'action', headerStyle: { textAlign: 'center', backgroundColor: 'rgb(255 152 0 / 38%)' }},
            ],
            rowData: [],
            element: null,
        }
        this.rowData = this.rowData.bind(this);
        this.insert = this.insert.bind(this);
        this.update = this.update.bind(this);
        this.delete = this.delete.bind(this);
    }

    componentDidMount() {
        this.rowData();
    }

    async delete(data) {
        const instance = axios.create({
            baseURL: process.env.REACT_APP_ENDPOINT,
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            }
        })
        await instance.delete(`/fae-part/wasteName/${data._id}`);
        this.setState({ element: '' });
        await this.rowData();
    }
    async insert(data) {
        const instance = axios.create({
            baseURL: process.env.REACT_APP_ENDPOINT,
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            }
        })
        await instance.post(`/fae-part/wasteName`, data);
        this.setState({ element: '' });
        await this.rowData();
    }
    async update(data) {
        const instance = axios.create({
            baseURL: process.env.REACT_APP_ENDPOINT,
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            }
        })
        await instance.put(`/fae-part/wasteName/${data._id}`, data);
        this.setState({ element: '' });
        await this.rowData();
    }
    async rowData() {
        try {
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`
                }
            })

            const response = await instance.get(`/fae-part/wasteName`);

            // const data = [];

            for (const item of response.data.data) {
                item.action = <Grid container spacing={0}>
                    <Grid item xs={6} style={{ textAlign: 'center'}}>
                        <Edit />
                    </Grid>
                    <Grid item xs={6} style={{ textAlign: 'center'}}>

                        <DeleteForever />
                    </Grid>
                </Grid>
            }
            this.setState({ rowData: response.data.data });
            this.setState({
                element: <Datatable
                    headers={this.state.header}
                    data={this.state.rowData}
                    title="Waste name"
                    onDelete={this.delete}
                    onInsert={this.insert}
                    onUpdate={this.update}
                    // editable={true}
                />
            })

        } catch (err) {
            console.log(err.stack)
        }
    }

    render() {
        return (
            <>
                {this.state.element}
            </>
        );
    }
}

export default WasteName;