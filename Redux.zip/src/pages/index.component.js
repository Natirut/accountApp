

import React from 'react';
import Grid from '@material-ui/core/Grid';

import Summary from './summary/index.component';

import Waste from './Waste/index.component';
import Manage from './Manage/index.component'
import Login from './Login/index.component'
import Register from './Register/index.component'
import Home from './home/index.component';
import FaeCheck from './setRoute/fae/check.component';
import FaeApprove from './setRoute/fae/approve.component';
import History from './History/index.component';

import Prepared from './invoice/prepare/index.component';
import RequesterCheck from './invoice/check/index.component';
import RequesterApprove from './invoice/approve/index.component';
import MakingApprove from './invoice/makingApprove/index.component';
import RequesterInput from './Requester/index.component';
class Main extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            page: null,
        }
    }

    componentDidMount() {
        this.setState({ open_login: true })
        if (this.props.page === 'summary') {
            this.setState({ page: <Summary /> })
        } else if (this.props.page === 'recycle') {
            this.setState({ page: <Waste /> })
        } else if (this.props.page === 'home') {
            this.setState({ page: <Home /> });
        }
        else if (this.props.page === 'manage') {
            this.setState({ page: <Manage /> });
        }
        else if (this.props.page === 'login') {
            this.setState({ page: <Login /> });
        }
        else if (this.props.page === 'register') {
            this.setState({ page: <Register /> });
        }
        else if (this.props.page === 'faeCheck') {
            this.setState({ page: <FaeCheck /> })
        }
        else if (this.props.page === 'faeApprove') {
            this.setState({ page: <FaeApprove /> })
        }
        else if (this.props.page === 'history') {
            this.setState({ page: <History /> })
        }
        else if (this.props.page === 'prepared') {
            this.setState({ page: <Prepared /> })
        }
        else if (this.props.page === 'requestercheck') {
            this.setState({ page: <RequesterCheck /> })
        }
        else if (this.props.page === 'requesterapprove') {
            this.setState({ page: <RequesterApprove /> })
        }
        else if (this.props.page === 'makingApprove') {
            this.setState({ page: <MakingApprove /> })
        }
        else if (this.props.page === 'requester') {
            this.setState({ page: <RequesterInput /> })
        }
        else if (this.props.page === 'null') {
            this.setState({ page: null });
        }

    }
    render() {
        return (
            <>
                <Grid container style={{ width: '100% !important' }}>
                    {this.state.page}
                </Grid>
            </>
        )
    }
}

export default Main;