
import React from 'react';
import { Button } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

class CreateRequester extends React.Component {

    constructor() {
        super();

        this.state = {
            open: false,
        }
        this.handleClose = this.handleClose.bind(this);
    }
    componentDidMount() {
        this.setState({ open: true });
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.close();
    }
    render() {
        return (
            <Dialog open={this.state.open} onClose={this.handleClose}>
                <DialogTitle>{"Use Google's location service?"}</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Let Google help apps determine location. This means sending anonymous location data to
                        Google, even when no apps are running.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} color="primary">Disagree</Button>
                    <Button onClick={this.handleClose} color="primary">Agree</Button>
                </DialogActions>
            </Dialog>
        )
    }
}

export default CreateRequester;