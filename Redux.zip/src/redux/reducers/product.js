
export default (state = '', action) => {
    switch (action.type) {
      case 'create':
        return state + action.x
      default:
        return state
    }
  }