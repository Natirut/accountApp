
import { combineReducers } from 'redux';

import counters from './counter';
import producx from './product'

export default combineReducers({
    counters,
    producx
})
