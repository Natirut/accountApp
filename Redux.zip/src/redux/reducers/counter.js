
export default (state = 0, action) => {
    switch (action.type) {
      case 'INCREMENT':
        return state + action.score
      case 'DECREMENT':
        return state - action.score
        case 'NUMBER':
          return state + action.x
      default:
        return state
    }
  }