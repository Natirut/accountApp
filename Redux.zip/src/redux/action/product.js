export const name = (x) => ({
    type: 'create',
    x
  })

  export const a = 1