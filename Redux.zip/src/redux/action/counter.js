export const increment = (score) => ({
    type: 'INCREMENT',
    score
  })
  export const decrement = (score) => ({
    type: 'DECREMENT',
    score
  })

  export const nowtest = (x) => ({
    type: 'NUMBER',
    x
  })