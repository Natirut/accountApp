
import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

class Loading extends React.Component {

    render() {
        return (
            <>
                <CircularProgress
                    variant="indeterminate"
                    disableShrink
                    size={80}
                    style={{
                        position: 'absolute',
                        top: 'calc(8%)',
                        height: '40px',
                        width: '40px',
                        right: 'calc(2%)',
                        color: '#00b300'
                    }} />
            </>
        )
    }
}

export default Loading;
