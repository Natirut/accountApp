
import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

class Loading extends React.Component {

    render() {
        return (
            <>
                <CircularProgress
                    variant="indeterminate"
                    disableShrink
                    size={80}
                    style={{
                        position: 'absolute',
                        marginTop: '40px',
                        height: '80px',
                        width: '80px',
                        right: 'calc(5%)',
                    }} />
            </>
        )
    }
}

export default Loading;
