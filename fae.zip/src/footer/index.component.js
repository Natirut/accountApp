

import React from 'react';

import './style.css'

import Grid from '@material-ui/core/Grid';

class Footer extends React.Component {

    render () {
        return (
            <>
            <footer className="footer">
                <Grid container spacing={0}>
                    <Grid item xs={4}>
                            COM1
                    </Grid>
                    <Grid item xs={4}>
                            COM2
                    </Grid>
                    <Grid item xs={4}>
                            COM3
                    </Grid>
                </Grid>
            </footer>
            </>
        )
    }
}


export default Footer;