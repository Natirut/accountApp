/* eslint-disable jsx-a11y/anchor-is-valid */


import React from 'react';
import './style.css';
import ReactDom from 'react-dom';

import QRScanner from '../pages/components/qrcodeReader/index.component';

import PageSelecter from '../pages/index.component';

class NavBar extends React.Component {
  constructor() {
    super();

    this.state = {
      openScanner: false,
    }
    this.close = this.close.bind(this);
    this.openScanner = this.openScanner.bind(this);
    this.summary = this.summary.bind(this);
    this.recyclegarbage = this.recyclegarbage.bind(this);
    this.disposalWaste = this.disposalWaste.bind(this);
  }
  openScanner() {
    this.setState({ openScanner: true })
  }
  componentDidMount() {
    // this.setState({ pageHTML: <PageSelecter page='summary'/> });
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='home' />, document.getElementById('space'));
  }
  summary() {
    // this.setState({ pageHTML: <PageSelecter page='summary'/> });
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='summary' />, document.getElementById('space'));
  }
  recyclegarbage() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='recycle' />, document.getElementById('space'));
    // this.setState({ pageHTML: <PageSelecter page='recordData'/> });
  }
  disposalWaste() {
    // alert('wait')
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='disposal' />, document.getElementById('space'));
  }
  close() {
    this.setState({ openScanner: false, })
  }
  render() {
    // console.log('ENV: ', process.env.REACT_APP_ENDPOINT)
    let qrScanner;
    if (this.state.openScanner === true) {
      qrScanner = <QRScanner callBackClose={this.close} />
    }

    return (
      <>
        <div className="nav">
          <input type="checkbox" id="nav-check" />
          <div className="nav-header">
            <div className="nav-title">
              Project
        </div>
          </div>
          <div className="nav-btn">
            <label for="nav-check">
              <span></span>
              <span></span>
              <span></span>
            </label>
          </div>

          <div className="nav-links">
            <a onClick={this.recyclegarbage}>Recycle Waste</a>
            <a onClick={this.disposalWaste}>Disposal Waste</a>
            <a onClick={this.summary}>Summary Data</a>
            <a onClick={this.openScanner}>Scaner QR</a>
          </div>
        </div>
        {qrScanner}
        <div id="space"></div>
      </>
    )
  }
}

export default NavBar;
