
import React from 'react';
import Snackbar from '@material-ui/core/Snackbar';
import './style.css';

class Success extends React.Component {

    constructor() {
        super();

        this.state = {
            message: '',
            open: true,
        }
        this.handleClose = this.handleClose.bind(this);
    }

    componentDidMount() {
        this.setState({ message: this.props.message });
    }
    handleClose() {
        this.setState({ open: false, })
    }
    render() {
        return (
            <Snackbar
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                open={this.state.open}
                // style={{ backgroundColor: '#a5d6a7', color: '#1a237e'}}
                onClose={this.handleClose}
                message="props message success"
            />
        )
    }
}

export default Success;