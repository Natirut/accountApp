
import React from 'react';
import Grid from '@material-ui/core/Grid';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import PostAddIcon from '@material-ui/icons/PostAdd';

import DataTable from '../components/datatable/index.component';
import CreateDisposal from './createForm.component';

class Disposal extends React.Component {

    constructor() {
        super()

        this.state = {
            openCreate: false,
        }
        this.close = this.close.bind(this);
        this.openCreate = this.openCreate.bind(this);
    }
    openCreate() {
        this.setState({ openCreate: true, })
    }

    close() {
        this.setState({ openCreate: false, })
    }
    render() {
        let create;
        if (this.state.openCreate === true) {
            create = <CreateDisposal close={this.close} />
        }
        return (
            <>
            {create}
            <Grid container spacing={0}>
                    <Grid item xs={10}>
                        <p style={{
                            fontSize: '18px', padding: '10px', position: 'absolute',
                            color: '#4E2388',
                            boxShadow: '#138715 2px 1px 3px 0px',
                            borderRadius: '8px',
                            backgroundColor: '#B5EAD7'
                        }}>
                            Disposal Waste
                            </p>
                    </Grid>
                    <Grid item xs={2} className="record-action">
                        <center>
                            <Tooltip title="Add item" aria-label="add">
                                <Fab color="secondary" style={{ backgroundColor: '#424874' }} onClick={this.openCreate}>
                                    <AddIcon />
                                </Fab>
                            </Tooltip>
                            <Tooltip title="Create Invoice">
                                <Fab color="secondary" style={{ backgroundColor: '#f19292', marginLeft: '10px' }}>
                                    <PostAddIcon />
                                </Fab>
                            </Tooltip>
                        </center>
                    </Grid>
                    <Grid item xs={12} style={{ marginTop: '20px'}}>
                        <DataTable />
                    </Grid>
                </Grid>
                </>
        )
    }
}

export default Disposal;