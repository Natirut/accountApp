
import React from 'react';

import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import CameraAltIcon from '@material-ui/icons/CameraAlt';
import IconButton from '@material-ui/core/IconButton';
import Camera from '../components/captureImages/captureImages.component';
import Button from '@material-ui/core/Button';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';

class RecordRecycleType extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            captureImage: false,
            allWeight: '',
            containerWeight: '',
            pureWeight: '',
        };
        this.openCamera = this.openCamera.bind(this);
        this.closeThisComponent = this.closeThisComponent.bind(this);
        this.setAllweight = this.setAllweight.bind(this);
        this.setContainerweight = this.setContainerweight.bind(this);
    }
    closeThisComponent() {
        this.setState({ captureImage: false, })

    }
    openCamera() {
        this.setState({ captureImage: true })
    }
    componentWillUnmount() {
        console.log('unmount RecordRecycleType ==> submited')
    }
    setAllweight(event) {
        console.log('setAllweight: ',event.target.value)
        this.setState({
            allWeight: event.target.value,
        })
    }
    setContainerweight(event) {
        this.setState({
            containerWeight: event.target.value,
            pureWeight: (parseFloat(this.state.allWeight) - parseFloat(event.target.value)).toFixed(3).toString(),
        });
    }
    render() {
        let camera;
        if (this.state.captureImage === true) {
            camera = <Camera close={this.closeThisComponent} />
        }
        return (

            <Grid container spacing={0} style={{ marginTop: '30px',}}>
                {camera}
                <Grid item xs={12}>
                    <Grid container spacing={0}>
                        <Grid item xs={2} style={{ padding: '20px'}}>
                            <FormControl style={{ marginRight: '10px' }}>
                                <InputLabel id="demo-simple-select-helper-label" style={{ width: '150px' }}>Select West type</InputLabel>
                                <Select
                                    labelId="demo-simple-select-helper-label"
                                    id="demo-simple-select-helper"
                                    style={{ width: '150px' }}
                                //   value={age}
                                //   onChange={handleChange}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value={10}>Recycle</MenuItem>
                                    <MenuItem value={20}>Bottle</MenuItem>
                                    <MenuItem value={30}>Dross</MenuItem>
                                    <MenuItem value={30}>PMD</MenuItem>
                                    <MenuItem value={30}>MCS</MenuItem>
                                    <MenuItem value={30}>IMO</MenuItem>
                                    <MenuItem value={30}>Part</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={2} style={{ padding: '20px'}}>
                            {/* <TextField id="factory" label="Select Factory" variant="outlined" style={{ margin: '15px' }} /> */}
                            <FormControl style={{ marginRight: '10px' }}>
                                <InputLabel id="demo-simple-select-helper-label" style={{ width: '150px' }}>Select Factory</InputLabel>
                                <Select
                                    labelId="demo-simple-select-helper-label"
                                    id="demo-simple-select-helper"
                                    style={{ width: '150px' }}
                                //   value={age}
                                //   onChange={handleChange}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value={10}>Recycle</MenuItem>
                                    <MenuItem value={20}>Bottle</MenuItem>
                                    <MenuItem value={30}>Dross</MenuItem>
                                    <MenuItem value={40}>PMD</MenuItem>
                                    <MenuItem value={50}>MCS</MenuItem>
                                    <MenuItem value={60}>IMO</MenuItem>
                                    <MenuItem value={70}>Part</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={2}>
                            <center>
                            <TextField id="weightWithCar" value={this.state.allWeight} label="All weight" variant="outlined" style={{ margin: '15px' }} onChange={this.setAllweight} />
                            </center>
                        </Grid>

                        <Grid item xs={4}>
                            <center>
                            <label htmlFor="icon-button-file">
                                <IconButton color="primary" aria-label="upload picture" component="span" onClick={this.openCamera}>
                                    <CameraAltIcon />
                            Capture images
                        </IconButton>
                                <center>
                                    <Button variant="contained" color="primary" style={{ backgroundColor: '#039be5'}}> Add</Button>
                                </center>
                            </label>
                            </center>
                        </Grid>
                    </Grid>



                    {/* <p>All weight - container</p> */}
                </Grid>
            </Grid>
        )
    }
}

export default RecordRecycleType;
