
import React from 'react';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';

import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';

import SubForm from './subCreateDisposal.component';

class CreateDisposal extends React.Component {
    constructor() {
        super()

        this.state = {
            transition: null,
            open: false,
            SubForm: null,
        }
        this.handleClose = this.handleClose.bind(this);
    }
    componentDidMount() {
        this.setState({ open: true, })

        this.setState({
            transition: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        })
        this.setState({ subForm: <SubForm /> })
    }
    handleClose() {
        this.props.close();
    }
    render() {
        return (
            <>
                <Dialog fullScreen open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.transition}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#1c2a48' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleClose}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Create Disposal Waste</Typography>
                        </Toolbar>
                    </AppBar>
                    {/* <BarChart /> <PieChart /> */}
                    <Grid container style={{ marginTop: 'calc(2%)'}}>
                        <Grid item xs={2}>
                            {/* {datepicker} */}
                        </Grid>
                        <Grid item xs={12} style={{ paddingLeft: 'calc(10%)'}}>
                            <TextField id="disposalCompany" label="Company" variant="outlined" style={{ margin: '15px' }} />

                            <FormControl style={{ marginRight: '10px', paddingTop: '20px' }}>
                                <InputLabel id="demo-simple-select-helper-label" style={{ width: '150px', paddingTop: '20px' }}>Type of car</InputLabel>
                                <Select
                                    labelId="demo-simple-select-helper-label"
                                    id="carType"
                                    style={{ width: '150px' }}
                                //   value={age}
                                //   onChange={handleChange}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value={10}>Recycle</MenuItem>
                                    <MenuItem value={20}>Bottle</MenuItem>
                                    <MenuItem value={30}>Dross</MenuItem>
                                    <MenuItem value={40}>PMD</MenuItem>
                                    <MenuItem value={50}>MCS</MenuItem>
                                    <MenuItem value={60}>IMO</MenuItem>
                                    <MenuItem value={70}>Add...</MenuItem>
                                </Select>
                            </FormControl>

                            <FormControl style={{ marginRight: '10px', paddingTop: '20px' }}>
                                <InputLabel id="demo-simple-select-helper-label" style={{ width: '120px', paddingTop: '20px' }}>Type of wast</InputLabel>
                                <Select
                                    labelId="demo-simple-select-helper-label"
                                    id="demo-simple-select-helper"
                                    style={{ width: '120px' }}
                                //   value={age}
                                //   onChange={handleChange}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value={10}>Recycle</MenuItem>
                                    <MenuItem value={20}>Bottle</MenuItem>
                                    <MenuItem value={30}>Dross</MenuItem>
                                    <MenuItem value={40}>PMD</MenuItem>
                                    <MenuItem value={50}>MCS</MenuItem>
                                    <MenuItem value={60}>IMO</MenuItem>
                                    <MenuItem value={70}>Add...</MenuItem>
                                </Select>
                            </FormControl>
                            <TextField id="date" label="Tranfer date" variant="outlined" style={{ margin: '15px' }} value={this.state.pickedDate} onClick={this.openDatePicker} />
                            <TextField id="time" type="time" label="Time" variant="outlined" style={{ margin: '15px', width: '200px' }} />
                            {/* <TextField id="company" label="Select Company" variant="outlined" style={{ margin: '15px', }} /> */}

                            <Grid container>
                                <Grid item xs={1}>

                                </Grid>
                                <Grid item xs={12}>
                                    {this.state.subForm}
                                </Grid>
                            </Grid>
                            <Grid container spacing={0}>
                                <Grid item xs={4}>

                                </Grid>
                                <Grid item xs={6} style={{ marginTop: '20px' }}>

                                    <Button variant="contained" color="primary" onClick={this.submit}>submit</Button>
                                    <Button variant="contained" color="secondary" onClick={this.cancle} style={{ marginLeft: '10px' }}>cancle</Button>

                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid item xs={2}>
                        </Grid>
                    </Grid>
                </Dialog>
            </>
        )
    }
}

export default CreateDisposal;
