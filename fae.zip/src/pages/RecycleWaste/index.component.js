
import React from 'react';
import Grid from '@material-ui/core/Grid';

import DataTable from '../components/datatable/index.component';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import './style.css';

import Success from '../components/successBar/index.component';

import Create from './createForm.component';
import PostAddIcon from '@material-ui/icons/PostAdd';

class RecordData extends React.Component {

    constructor() {
        super();

        this.state = {
            openForm: false,
        }
        this.openCreateForm = this.openCreateForm.bind(this);
        this.close = this.close.bind(this);
    }
    close() {
        this.setState({ openForm: false, });
    }
    async openCreateForm() {
        console.log('OPEN CREATE')
        await this.setState({ openForm: true, })
    }
    render() {
        let create;
        if (this.state.openForm === true) {
            create = <Create close={this.close} />
        }
        return (
            <>
                <Success />
                {create}
                <Grid container spacing={0}>
                    <Grid item xs={10}>
                        <p style={{
                            fontSize: '18px', padding: '10px', position: 'absolute',
                            color: 'darkmagenta',
                            boxShadow: '#fecf39 2px 1px 3px 0px',
                            borderRadius: '8px',
                            backgroundColor: '#FDF2F0'
                        }}>
                            Recycle Waste
                            </p>
                    </Grid>
                    <Grid item xs={2} className="record-action">
                        <center>
                            <Tooltip title="Add item" aria-label="add">
                                <Fab color="secondary" style={{ backgroundColor: '#cddc39' }} onClick={this.openCreateForm}>
                                    <AddIcon />
                                </Fab>
                            </Tooltip>
                            <Tooltip title="Create Invoice">
                                <Fab color="secondary" style={{ backgroundColor: '#1de9b6', marginLeft: '10px' }}>
                                    <PostAddIcon />
                                </Fab>
                            </Tooltip>
                        </center>
                    </Grid>
                    <Grid item xs={12} style={{ marginTop: '20px'}}>
                        <DataTable />
                    </Grid>
                </Grid>

            </>
        )
    }
}

export default RecordData;