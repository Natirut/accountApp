
import React from 'react';
import Grid from '@material-ui/core/Grid';
import './style.css'

class Home extends React.Component {
    constructor() {
        super();

        this.state = {
            color: 'red'
        }
        this.change = this.change.bind(this);
    }
    change() {
        this.setState({ color: 'pink'})
    }
    render() {
        return (
            <>
               
                
                <Grid container spacing={0}>
                
                    <Grid item xs={12} >
                    <img src={require('./trash.jpg')} height="450" width="900 " class = "mar3"  />
                    </Grid>
                </Grid>

                <Grid container spacing={0}>
                    <Grid item xs={12} >
                        <p class = "fontsizeS ">Waste Management</p>
                    </Grid>
                </Grid>
            </>
        )
    }
}

export default Home;
