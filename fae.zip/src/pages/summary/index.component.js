
import React from 'react';

import Disposal from './disposalWaste.component';
import Recycle from './recycleWaste.component';

import Grid from '@material-ui/core/Grid';

import Button from '@material-ui/core/Button';

class MainSummary extends React.Component {
    constructor() {
        super();

        this.state = {
            element: <Recycle />,
            buttonMessage: 'Go to Disposal',
            valPage: 'disposal',
        }

        this.switchPage = this.switchPage.bind(this);
    }
    switchPage(value) {
        if (value === 'disposal') {
            this.setState({ element: <Disposal />, buttonMessage: 'Go to Recycle', valPage: 'recycle' })
        } else {
            this.setState({ element: <Recycle />, buttonMessage: 'Go to Disposal', valPage: 'disposal' })
        }
    }
    render() {
        return (
            <>
                <Button
                    variant="contained"
                    style={{ position: 'absolute', right: 'calc(1%)', marginTop: '20px', color: '#9656a1', backgroundColor: '#eab0d9' }}
                    onClick={() => this.switchPage(this.state.valPage)}
                >
                    {this.state.buttonMessage}
                </Button>
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        {this.state.element}
                    </Grid>
                </Grid>
            </>
        )
    }
}

export default MainSummary;
