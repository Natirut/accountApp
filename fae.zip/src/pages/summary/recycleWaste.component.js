
import React from 'react';
import Grid from '@material-ui/core/Grid';
// import DataTable from '../components/datatable/index.component';
import PieChart from '../../charts/pieChart/index.component';
import Barchart from '../../charts/barChart/index.component';
import VerticalChart from '../../charts/verticalChart/index.component';

// import Loading from '../../loading/index.component';
import './style.css';

class Summary extends React.Component {

    constructor() {
        super();

        this.state = {
            recycleUseprocess: null,
            recycleUnuseprocess: null,
            boi: null,
            noneBoi: null,
        }
        this.genrecycleUseprocess = this.genrecycleUseprocess.bind(this);
    }

    componentDidMount() {
        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#B21F00', '#C9DE00', '#2FDE00'],
                    data: [65, 59, 80,]
                },
                text: 'Recycle from process',
            }, 'recycleUseprocess');

        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#B21F00', '#C9DE00', '#2FDE00'],
                    data: [20, 60, 80,]
                },
                text: 'Recycle unuse process',
            }, 'recycleUnuseprocess');

        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#B21F00', '#C9DE00', '#2FDE00'],
                    data: [40, 30, 30,]
                },
                text: 'BOI',
            }, 'boi');

        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#B21F00', '#C9DE00', '#2FDE00'],
                    data: [25, 30, 80,]
                },
                text: 'NON-BOI',
            }, 'noneBoi');
    }
    genrecycleUseprocess(value, state) {
        const data = {
            labels: value.labels,
            datasets: [
                {
                    backgroundColor: value.datasets.backgroundColor,
                    data: value.datasets.data,
                }
            ],
            text: value.text
        }
        const stateSet = {}
        stateSet[state] = data
        this.setState(stateSet)
    }
    render() {
        let recycleUseprocess;

        if (this.state.recycleUseprocess !== null) {
            recycleUseprocess = <PieChart data={this.state.recycleUseprocess} />
        }
        let recycleUnuseprocess;

        if (this.state.recycleUnuseprocess !== null) {
            recycleUnuseprocess = <PieChart data={this.state.recycleUnuseprocess} />
        }
        let boi;

        if (this.state.boi !== null) {
            boi = <PieChart data={this.state.boi} />
        }
        let noneBoi;

        if (this.state.noneBoi !== null) {
            noneBoi = <PieChart data={this.state.noneBoi} />
        }
        return (
            <>
                <Grid container spacing={0}>
                    <Grid item xs={6}>
                        <center>
                            <Barchart />
                        </center>
                    </Grid>
                    <Grid item xs={6}>
                        <Barchart />
                    </Grid>

                    <Grid item xs={3}>
                        {recycleUseprocess}
                    </Grid>
                    <Grid item xs={3}>
                        {recycleUnuseprocess}
                    </Grid>
                    <Grid item xs={3}>
                        {boi}
                    </Grid>
                    <Grid item xs={3}>
                        {noneBoi}
                        <button style={
                            {
                                position: 'absolute', right: 'calc(3%)',
                                borderBottomColor: 'brown',
                                padding: '5px',
                                backgroundColor: 'darkgray'
                            }}>More detail</button>
                    </Grid>
                    <VerticalChart />
                </Grid>
            </>
        )
    }
}

export default Summary;