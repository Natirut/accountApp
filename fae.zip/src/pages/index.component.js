

import React from 'react';
import Grid from '@material-ui/core/Grid';

import Summary from './summary/index.component';

import RecycleWaste from './RecycleWaste/index.component';
import DisposalWaste from './DisposalWaste/index.component';

import Home from './home/index.component';


class Main extends React.Component {

    constructor(props) {
        super(props);
        // console.log('PAGE: ', props)
        this.state = {
            page: null,
        }
    }

    componentDidMount() {
        if (this.props.page === 'summary') {
            this.setState({ page: <Summary /> })
        } else if (this.props.page === 'recycle') {
            this.setState({ page: <RecycleWaste /> })
        } else if (this.props.page === 'disposal') {
            this.setState({ page: <DisposalWaste /> })
        } else if (this.props.page === 'home') {
            this.setState({ page: <Home /> });
        }
    }
    render() {
        return (
            <>

                <Grid container style={{ width: '100% !important' }}>
                    {this.state.page}
                </Grid>
            </>
        )
    }
}

export default Main;