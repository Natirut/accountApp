import React from 'react';
import Navbar from './navbar/index.component';

import Footer from './footer/index.component';

import Page from './pages/index.component';
import Grid from '@material-ui/core/Grid';

class App extends React.Component {
  render() {
    return (
      <>
        <Grid container spacing={0}>
          <Grid item xs={12}>
            <Navbar />
            <Page />
        <Footer />
          </Grid>
        </Grid>
      </>
    )
  }
}

export default App;
