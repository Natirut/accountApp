
import Axios from 'axios';
// import Button from '@material-ui/core/Button';
import React, { forwardRef } from 'react';
import MaterialTable from "material-table";
import Edit from '@material-ui/icons/Edit';
import ClearIcon from '@material-ui/icons/Clear';
import CheckIcon from '@material-ui/icons/Check';
import SearchIcon from '@material-ui/icons/Search';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import LastPageIcon from '@material-ui/icons/LastPage';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import SortOutlinedIcon from '@material-ui/icons/SortOutlined';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import AddIcon from '@material-ui/icons/Add';
// import MenuItem from '@material-ui/core/MenuItem';
// import InputLabel from '@material-ui/core/InputLabel';
// import Grid from '@material-ui/core/Grid';
class Manage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            data_com: []
        }
    }
    componentDidMount() {
        this.GetCompany()
    }
    GetCompany() {
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(res => {
                    this.setState({ data_com: res.data.data })
                }).catch((err) => {
                    if (err.response.status === 401) {
                        localStorage.clear();
                        window.history.pushState({}, document.title, '/waste');
                        window.location.reload();
                    }
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    delete(newdata) {
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company/"+newdata._id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company/${newdata._id}`
        Axios.delete(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
            .then(res => {
                this.componentDidMount()
                console.log(res);
                console.log(res.data);
            })
    }

    update(newdata) {
        console.log(newdata)
        //let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company/"+newdata._id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company/${newdata._id}`
        Axios.put(url, newdata, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
            .then(res => {
                this.componentDidMount()
                console.log(res);
                console.log(res.data);
            })
    }
    async insert(newdata) {
        // let url = process.env.REACT_APP_ENDPOINT+"/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        // console.log(this.state.name)
        try {
            Axios.post(url, newdata, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(async res => {
                    console.log(res.data)
                    this.componentDidMount()
                }).catch((err) => {
                    if (err.response.status === 401) {
                        localStorage.clear();
                        window.history.pushState({}, document.title, '/waste');
                        window.location.reload();
                    }
                })
        } catch (err) {
            if (err.response.status === 401) {
                localStorage.clear();
                window.history.pushState({}, document.title, '/waste');
                window.location.reload();
            }
        }
    }

    render() {
        return (
            <>
                <MaterialTable
                    icons={{
                        Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
                        Clear: forwardRef((props, ref) => <ClearIcon {...props} ref={ref} />),
                        Check: forwardRef((props, ref) => <CheckIcon {...props} ref={ref} />),
                        Search: forwardRef((props, ref) => <SearchIcon {...props} ref={ref} />),
                        FirstPage: forwardRef((props, ref) => <FirstPageIcon {...props} ref={ref} />),
                        LastPage: forwardRef((props, ref) => <LastPageIcon {...props} ref={ref} />),
                        NextPage: forwardRef((props, ref) => <NavigateNextIcon {...props} ref={ref} />),
                        PreviousPage: forwardRef((props, ref) => <ArrowBackIosIcon {...props} ref={ref} />),
                        ResetSearch: forwardRef((props, ref) => <ClearIcon {...props} ref={ref} />),
                        SortArrow: forwardRef((props, ref) => <SortOutlinedIcon {...props} ref={ref} />),
                        Delete: forwardRef((props, ref) => <DeleteForeverIcon {...props} ref={ref} />),
                        Add: forwardRef((props, ref) => <AddIcon {...props} ref={ref} />),
                    }}
                    columns={[
                        { title: 'Company Name.', field: 'companyName', },
                    ]}
                    style={{ maxWidth: '100%' }}
                    data={this.state.data_com}
                    title="Company"
                    localization={{

                    }}
                    editable={{
                        onRowUpdate: (newData, oldData) =>
                            new Promise((resolve) => {
                                setTimeout(() => {
                                    this.update(newData);
                                    resolve();
                                }, 600);
                            }),
                        onRowDelete: (newData, oldData) =>
                            new Promise((resolve) => {
                                setTimeout(() => {
                                    this.delete(newData);
                                    resolve();
                                }, 600);
                            }),
                        onRowAdd: (newData, oldData) =>
                            new Promise((resolve) => {
                                setTimeout(() => {
                                    this.insert(newData);
                                    resolve();
                                }, 600);
                            }),

                    }}

                />
            </>


        )
    }
}
export default Manage
