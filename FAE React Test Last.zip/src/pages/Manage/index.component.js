import React from 'react';
import RecycleCom from '../Manage/recycleCompany'
import RecycleCar from '../Manage/recycleCar';
import Quotation from './quotation.component';
import Grid from '@material-ui/core/Grid';
import Zoom from '@material-ui/core/Zoom';

class Manage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: ""
        }
    }
    render() {
        return (
            <>
                <Grid container spacing={0} alignItems="center" justify="center" style={{ maxHeight: "50%", marginTop: 'calc(5%)' }}>
                    <Zoom in={true} style={{ transitionDelay: '300ms' }}>
                        <Grid item xs={5} style={{ margin: 10 }}>
                            <RecycleCom />
                        </Grid>
                    </Zoom>
                    <Zoom in={true} style={{ transitionDelay: '700ms' }}>
                        <Grid item xs={5} style={{ margin: 10 }}>
                            <RecycleCar />
                        </Grid>
                    </Zoom>
                    <Zoom in={true} style={{ transitionDelay: '1000ms' }}>
                        <Grid item xs={5}>
                            <Quotation />
                        </Grid>
                    </Zoom>
                </Grid>

            </>
        )
    }
}
export default Manage
