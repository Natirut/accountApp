import React from 'react';
import DialogContent from '@material-ui/core/DialogContent';
import IconButton from '@material-ui/core/IconButton';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import Axios from 'axios'
import MenuItem from '@material-ui/core/MenuItem';
import { InputLabel, FormControl, Select, Box, Button, Slide } from '@material-ui/core';
import { HighlightOff } from '@material-ui/icons';
import Success from '../components/successBar/index.component';
import Error from '../components/errorBar/index.component';

class Register extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            slide: null,
            username: "",
            password: "",
            role: "",
            con_password: "",
            openSnack: false,
            showSuccss: false,
            showError: false,
            message: '',
            position: "",
            feture: "",
            arrItem: [],
            arrrowItem: [],
        }

        this.SetUser = this.SetUser.bind(this);
        this.SetPass = this.SetPass.bind(this);
        this.SetConPass = this.SetConPass.bind(this);
        this.SetRole = this.SetRole.bind(this);
        this.SetPosition = this.SetPosition.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.register_user = this.register_user.bind(this);
        this.check_register = this.check_register.bind(this);
        this.SetFeture = this.SetFeture.bind(this);
        this.addItem = this.addItem.bind(this);
    }
    handleClose() {
        //  this.setState({ open: false, });
        // window.location.reload();
        this.props.close();
    }
    async SetFeture(event) {
        console.log("laste", event.target.value)
        await this.setState({
            feture: event.target.value
        });
    }

    async SetUser(event) {
        await this.setState({
            username: event.target.value
        });
    }
    async SetPass(event) {
        await this.setState({
            password: event.target.value
        });
    }
    async SetConPass(event) {
        await this.setState({
            con_password: event.target.value
        });
    }
    async SetRole(event) {
        await this.setState({
            role: event.target.value
        });
    }
    async SetPosition(event) {
        await this.setState({
            position: event.target.value
        })
    }
    async submit() {
        try {
            const body = [];

            let dept = document.getElementsByName('dept');
            let future = document.getElementsByName('feture');
            let action = document.getElementsByName('action');
            console.log("dd", dept)
            dept.forEach((item, index) => {
                if (item.value !== '') {
                    body.push({
                        dept: item.value,
                        feature: future[index].value,
                        action: action[index].value
                    })
                }
            })
            // console.log("dept", body)

        } catch (err) {

        }
    }

    async addItem() {
        let tmp = this.state.arrrowItem

        tmp.push(<> <FormControl style={{ marginRight: '20px', paddingTop: '20px' }}>
            <InputLabel id="dept" style={{ width: '100px', paddingTop: '20px' }}>Dept</InputLabel>
            <Select
                labelId="dept"
                id="dept"
                name="dept"
                style={{ width: '120px' }}

            >

                <MenuItem value="FAE">FAE</MenuItem>
                <MenuItem value="ACC">ACC</MenuItem>
            </Select>
        </FormControl>
            <FormControl style={{ marginRight: '20px', paddingTop: '20px' }}>
                <InputLabel id="feture" style={{ width: '100px', paddingTop: '20px' }}>Feture</InputLabel>
                <Select
                    labelId="feture"
                    id="feture"
                    name="feture"
                    style={{ width: '120px' }}

                >
                    <MenuItem value="NON">NON</MenuItem>
                    <MenuItem value="waste">Waste</MenuItem>
                    <MenuItem value="invoice">Invoice</MenuItem>
                </Select>
            </FormControl>
            <FormControl style={{ marginRight: '20px', paddingTop: '20px' }}>
                <InputLabel id="action" style={{ width: '100px', paddingTop: '20px' }}>Action</InputLabel>
                <Select
                    labelId="action"
                    id="action"
                    name="action"
                    style={{ width: '120px' }}

                >
                    <MenuItem value="NON">NON</MenuItem>
                    <MenuItem value="prepare">Prepare</MenuItem>
                    <MenuItem value="check">Check</MenuItem>
                    <MenuItem value="approve">Approve</MenuItem>

                    <MenuItem value="tax-approve">Tax invoice making approve</MenuItem>
                </Select>
            </FormControl> </>)
        await this.setState({
            arrrowItem: tmp
        })
    }
    async componentDidMount() {
        let tmp = this.state.arrrowItem

        console.log("tm", tmp)

        tmp.push(<> <FormControl style={{ marginRight: '20px', paddingTop: '20px' }}>
            <InputLabel id="dept" style={{ width: '100px', paddingTop: '20px' }}>Dept</InputLabel>
            <Select
                labelId="dept"
                id="dept"
                name="dept"
                style={{ width: '120px' }}

            >
                <MenuItem value="FAE">FAE</MenuItem>
                <MenuItem value="ACC">ACC</MenuItem>
            </Select>
        </FormControl>

            <FormControl style={{ marginRight: '20px', paddingTop: '20px' }}>
                <InputLabel id="feture" style={{ width: '100px', paddingTop: '20px' }}>Feture</InputLabel>
                <Select
                    labelId="feture"
                    id="feture"
                    style={{ width: '120px' }}
                    name="feture"

                >
                    <MenuItem value="NON">NON</MenuItem>
                    <MenuItem value="waste">Waste</MenuItem>
                    <MenuItem value="invoice">Invoice</MenuItem>
                </Select>
            </FormControl>

            <FormControl style={{ marginRight: '20px', paddingTop: '20px' }}>
                <InputLabel id="action" style={{ width: '100px', paddingTop: '20px' }}>Action</InputLabel>
                <Select
                    labelId="action"
                    id="action"
                    name="action"
                    style={{ width: '120px' }}

                >
                    <MenuItem value="NON">NON</MenuItem>
                    <MenuItem value="prepare">Prepare</MenuItem>
                    <MenuItem value="check">Check</MenuItem>
                    <MenuItem value="approve">Approve</MenuItem>

                    <MenuItem value="tax-approve">Tax invoice making approve</MenuItem>
                </Select>
            </FormControl> </>)
        await this.setState({
            arrrowItem: tmp
        })
        console.log("ff", this.state.arrrowItem)

        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
    }
    check_register() {
        if (this.state.password !== this.state.con_password) {
            this.setState({ openSnack: true })
        }
        else {
            this.register_user()
        }
    }
    register_user() {
        try {
            const body = [];

            let dept = document.getElementsByName('dept');
            let future = document.getElementsByName('feture');
            let action = document.getElementsByName('action');
            dept.forEach((item, index) => {
                body.push({
                    dept: item.value,
                    feature: future[index].value,
                    action: action[index].value
                })
            })

            const regis = {
                username: this.state.username,
                password: this.state.password,
                permission: body,
            };
            let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/user`
            console.log("dept", regis)

            Axios.post(url, regis)
                .then(res => {
                    // console.log(res.data)
                    this.setState({ message: res.data.message, showSuccss: true, })

                    setTimeout(() => {
                        this.setState({ showSuccss: false, })
                        this.handleClose();
                    }, 2000);
                }).catch((err) => {
                    this.setState({ message: err.response.data.message, showError: true, })

                    setTimeout(() => {
                        this.setState({ showError: false, })
                    }, 2000);
                })

        } catch (err) {
            console.log(err.stack)
        }
    }

    render() {
        let success;
        if (this.state.showSuccss === true) {
            success = <Success message={this.state.message} />
        }
        let error;
        if (this.state.showError === true) {
            success = <Error message={this.state.message} />
        }

        return (
            <>
                {/* <Snackbar open={this.state.openSnack} message="Fail" autoHideDuration={1000} */}
                <Dialog open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.slide}>
                    {error}
                    <AppBar style={{ position: 'relative', backgroundColor: '#383e56', color: '#f6def6' }}>
                        <Toolbar>
                            <HighlightOff
                                style={{
                                    position: 'absolute',
                                    right: 'calc(2%)',
                                    color: 'red',
                                    cursor: 'pointer',
                                }}

                                onClick={this.handleClose}
                            />
                            <Typography variant="h6">Register</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent >
                        <TextField

                            margin="dense"
                            id="user"
                            label="Username"
                            type="email"
                            fullWidth
                            value={this.state.username}
                            onChange={this.SetUser}
                        />
                        <br />  <br />
                        <TextField

                            margin="dense"
                            id="pass"
                            label="Password"
                            type="password"
                            fullWidth
                            value={this.state.password}
                            onChange={this.SetPass}
                        />
                        <TextField

                            margin="dense"
                            id="confirm_pass"
                            label="Confirm Password"
                            type="password"
                            fullWidth
                            value={this.state.con_password}
                            onChange={this.SetConPass}
                        />
                        {this.state.arrrowItem.map((item) => (
                            <>
                                {item}
                            </>
                        ))}
                        <IconButton onClick={this.addItem} color="primary" style={{ marginRight: '20px', marginTop: '30px' }} >
                            <AddCircleOutlineIcon style={{ color: '#170a19', cursor: 'pointer'}} />
                        </IconButton>
                        <br /> <br /> <br />
                        <Box textAlign='center'>
                            <Button variant="contained" color="primary" onClick={this.check_register} style={{ backgroundColor: '#aeeff0', color: '#264e70'}}>
                                Register
                    </Button>
                        </Box>
                        <br /> <br /> <br />
                        {success}
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}

export default Register;
