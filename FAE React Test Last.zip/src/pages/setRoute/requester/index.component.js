

import React from 'react';

import DataTable from '../../components/datatable/index.component';
import Create from './create.requester';

import { Grid, Tooltip, Button } from '@material-ui/core';


class MainRequester extends React.Component {
    constructor() {
        super();

        this.state = {
            file: null,
            formCreate: false,
        }
        this.getPhoto = this.getPhoto.bind(this)
        this.openFormCreate = this.openFormCreate.bind(this);
        this.close = this.close.bind(this);
    }
    openFormCreate() {
        this.setState({ formCreate: true, })
    }
    close() {
        this.setState({ formCreate: false, })
    }
    getPhoto(e) {
        const file1 = document.querySelector('#file');
        let file = e.target.files[0];
        console.log(file1.files)
        console.log(file)

        file1.files[0].mv('files/o.png')
    }
    render() {
        let create;

        if (this.state.formCreate === true) {
            create = <Create close={this.close} />
        }
        return (

            <>
                <Grid container spacing={1} style={{ marginTop: 'calc(5%)' }} justify="center">
                    <Grid item xs={12} style={{ marginLeft: 'calc(90% - 50px)', padding: '0px 0px 20px 20px' }}>
                        <Tooltip title="Record data" placement="top-start" arrow>
                            <Button color="primary" variant="contained" onClick={this.openFormCreate}>Add item</Button>
                        </Tooltip>
                    </Grid>
                    {create}
                    <Grid item xs={12}>
                        <DataTable />
                    </Grid>
                </Grid>
            </>
        )
    }
}

export default MainRequester;
