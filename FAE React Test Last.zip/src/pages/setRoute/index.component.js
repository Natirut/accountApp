
import React from 'react';

import Requester from './requester/index.component';
import Itc from './itc/index.component';

class SetRoute extends React.Component {

    render() {
        let role = localStorage.getItem('dept');
        
        let element;
        if (role === 'ITC') {
            element = <Itc />
        } else if (role === 'REQ') {
            element = <Requester />
        }
        return (
            <>
                {element}
            </>
        )
    }
}

export default SetRoute;