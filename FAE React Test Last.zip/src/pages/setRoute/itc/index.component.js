
import React from 'react';

import DataTable from '../../components/datatable/index.component';

import { Grid, Tooltip, Button } from '@material-ui/core';

class Itc extends React.Component {
    render() {
        return (
            <>
                <Grid container spacing={1} style={{ marginTop: 'calc(2%)' }} justify="center">

                    <Grid item xs={12} style={{ marginLeft: 'calc(90% - 50px)', padding: '0px 0px 20px 20px' }}>
                        <Tooltip title="Record data" placement="top-start" arrow>
                            <Button>Add item</Button>
                        </Tooltip>
                    </Grid>

                    <Grid item xs={12}>
                        <DataTable />
                    </Grid>
                </Grid>
            </>
        )
    }
}

export default Itc;