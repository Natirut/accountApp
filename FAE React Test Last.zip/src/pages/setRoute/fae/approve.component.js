import React from 'react';
// import { PostAdd, Edit, Delete, AspectRatio } from '@material-ui/icons';
import { Edit, Delete, AspectRatio } from '@material-ui/icons';
import { Checkbox } from '@material-ui/core';
import Tooltip from '@material-ui/core/Tooltip';
import DataTable from '../../components/datatable/index.component'
import Grid from '@material-ui/core/Grid';
import SendIcon from '@material-ui/icons/Send';
import Button from '@material-ui/core/Button';
import Axios from 'axios';
import SkeletonLoader from '../../components/skeleton/index.component';
import Caronsol from '../../components/imageCategory/index.component';
import Confirm from '../../components/confirm/index.component'
import EditDialog from './dialog_EditApprove';
import ErrorBar from '../../components/errorBar/index.component';

class FaeApprove extends React.Component {
    constructor() {
        super();
        this.state = {
            loader: true,
            data: [],
            element: null,
            columns: [],
            body: [],
            expand: false,
            filesItem: [],
            deleteId: "",
            confirm: false,
            dialog_Edit: false,
            dataUpdate: [],
            message: '',
            confirmapprove: false,
        }
        this.rowData = this.rowData.bind(this);
        this.CheckData = this.CheckData.bind(this);
        this.CheckAll = this.CheckAll.bind(this);
        this.SendApprove = this.SendApprove.bind(this);
        this.showExpand = this.showExpand.bind(this);
        this.close = this.close.bind(this);
        this.cancle = this.cancle.bind(this);
        this.onRecordDelete = this.onRecordDelete.bind(this);
        this.confirmDelete = this.confirmDelete.bind(this);
        this.openEditForm = this.openEditForm.bind(this);
        this.confirmApprove = this.confirmApprove.bind(this);
    }
    async confirmApprove(x){
        try {
            if(x===true){
                 if (this.state.body && this.state.body.length) {
                const data = {
                    status: "approved",
                    body: this.state.body
                }
                const instance = Axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                await instance.put(`/fae-part/waste/status`, data);
                setTimeout(async () => {
                    await this.setState({ element: null })
                    await this.setState({ element: <SkeletonLoader />, })
                    this.rowData();
                }, 500);
            }
            }
            else{
                this.setState({confirmapprove:false})
            }
           
        } catch (err) {
            if (err.response.status === 403) {
                this.setState({ message: 'Permission denied.' });

                setTimeout(() => {
                    this.setState({ message: '' });
                }, 4000);
            }
            this.setState({confirmapprove:false})
        }
    }
    async openEditForm(item) {
        console.log(item)
        await this.setState({ dataUpdate: item, })
        await this.setState({ dialog_Edit: true, })
    }
    async confirmDelete(x) {
        try {
            if (x === true) {
                console.log(x)
                const instance = Axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                });

                const response = await instance.delete(`/fae-part/waste/${this.state.deleteId}`);

                console.log(response)
                await this.setState({ confirm: false, })
                await setTimeout(async () => {
                    this.setState({ element: null })
                    this.setState({ element: <SkeletonLoader />, })
                    await this.rowData();
                }, 500);


            } else {
                this.setState({ confirm: false, })
            }
        } catch (err) {
            this.setState({ confirm: false, })
        }
    }
    onRecordDelete(id) {
        console.log(id)
        this.setState({
            deleteId: id,
            confirm: true,
        })
    }
    showExpand(files) {
        console.log(files)
        this.setState({ expand: true, filesItem: files })
    }
    componentDidMount() {
        this.rowData();

    }
    async SendApprove() {
        await this.setState({ confirmapprove: true })
       await this.setState({ confirmapprove: null })
       await this.setState({ confirmapprove: true })

    }
    async CheckAll(e) {
        let items = document.getElementsByName('acs');
        // console.log(items[0].value)
        if (e.target.checked) {
            for (let i = 0; i < items.length; i++) {
                await this.state.body.push(items[i].value)
                items[i].checked = true;
            }
        }
        else {
            await this.setState({ body: [] })
            for (var i = 0; i < items.length; i++) {
                items[i].checked = false;
            }
        }
        var _ = require('lodash');
        await this.setState({
            body: _.uniq(this.state.body, '_id')
        })
        console.log("all", this.state.body)
    }
    async CheckData(e, data) {
        let checkall = document.getElementsByName('checkall');
        //console.log(data._id)
        if (e.target.checked) {
            await this.setState({
                body: this.state.body.concat([data._id])
            })
        }
        else {
            let filteredArray = await this.state.body.filter(item => item !== data._id)
            await this.setState({
                body: filteredArray
            });
        }
        console.log("result", this.state.body)
        if(this.state.body.length===this.state.data.length){
            checkall[0].checked=true
         }
         else if(this.state.body.length!==this.state.data.length){
            checkall[0].checked=false
         }
    }
    async rowData() {
        try {
            const column = [
                {
                    field: 'check', title:  <input type="checkbox" style={{transform: 'scale(1.5, 1.5)'}} onChange={this.CheckAll}  name="checkall" ></input>, align: 'center', width: 2, sorting: false,
                },
                { field: 'more', title:<b>Action</b> , align: 'center', },
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'typeBoi', title:<b>TypeBoi</b> , align: 'center', },
                { field: 'date', title: <b>Date</b>, align: 'center', },
                { field: 'time', title:<b>Time</b>, align: 'center', },
                { field: 'cptType', title:<b>CptType</b> , align: 'center', },
                { field: 'lotNo', title:<b>LotNo.</b> , align: 'center', },
                { field: 'companyApprove', title:<b>CompanyApprove.</b> , align: 'center', },
                { field: 'gennerateGroup', title:<b>GennerateGroup.</b> , align: 'center', },
                { field: 'wasteGroup', title:<b>WasteGroup.</b> , align: 'center', },
                { field: 'wasteName', title:<b>WasteName.</b> , align: 'center', },
                { field: 'totalWeight', title:<b>TotalWeight.</b> , align: 'center', },
                { field: 'containerWeight', title:<b>ContainerWeight.</b>, align: 'center', },
                { field: 'netWasteWeight', title:<b>NetWasteWeight.</b>, align: 'center', },
                { field: 'wasteContractor', title:<b>ContractortCompany.</b>, align: 'center', },
                { field: 'containerType', title:<b>containerType.</b>, align: 'center', },
                { field: 'phase', title:<b>Phase.</b>, align: 'center', },

            ];
            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/waste/approve`);

            const row = [];

            // const record = new Promise((resolve) => {
            for (const item of response.data.data) {
                row.push(
                    {
                        check: <>
                            <input type="checkbox" style={{transform: 'scale(1.4, 1.4)'}} value={item._id} name="acs" onChange={e => this.CheckData(e, item)}></input>
                        </>,

                        more:
                            <>
                                <Grid container spacing={0}>
                                    <Grid item xs={12}>
                                        <Tooltip title="Edit" style={{ cursor: 'pointer', color: '#745c97' }}>
                                            <AspectRatio onClick={() => this.showExpand(item.files)} />
                                        </Tooltip>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Tooltip title="Delete" style={{ cursor: 'pointer', color: '#32afa9' }}>
                                            <Edit onClick={() => this.openEditForm(item)} />
                                        </Tooltip>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Tooltip title="Expand" style={{ cursor: 'pointer', color: '#f67280' }}>
                                            <Delete onClick={() => this.onRecordDelete(item._id)} />
                                        </Tooltip>
                                    </Grid>
                                </Grid>
                            </>,
                        typeBoi: item.typeBoi,
                        date: item.date,
                        time: item.time,
                        cptType: item.cptType,
                        lotNo: item.lotNo,
                        companyApprove: item.companyApprove,
                        gennerateGroup: item.gennerateGroup,
                        wasteGroup: item.wasteGroup,
                        wasteName: item.wasteName,
                        totalWeight: item.totalWeight,
                        containerWeight: item.containerWeight,
                        netWasteWeight: item.netWasteWeight,
                        wasteContractor: item.wasteContractor,
                        containerType: item.containerType,
                        phase: item.phase,

                    }
                )
            }
            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, loader: false, })
                this.setState({ element: <DataTable title="FAE Approve" headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            console.log(err)
            if (err.response.status === 401) {
                localStorage.clear();
                window.history.pushState({}, document.title, '/waste');
                window.location.reload();
            }
            this.setState({ element: <DataTable title="FAE Approve" headers={this.state.columns} data={[]} />, loader: false, })
        }

    }
    async cancle() {
        await this.setState({ expand: false, dialog_Edit: false });
    }
    async close() {
        setTimeout(async () => {
            await this.setState({ element: null })
            await this.setState({ element: <SkeletonLoader />, })
            await this.rowData();
        }, 500);

        this.setState({ expand: false, dialog_Edit: false });
    }
    render() {
        let loader;
        if (this.state.loader === true) {
            loader = <SkeletonLoader />
        }
        let showexpand;
        if (this.state.expand === true) {
            showexpand = <Caronsol images={this.state.filesItem} close={this.close} cancle={this.cancle} />
        }
        let confirm;
        if (this.state.confirm === true) {
            confirm = <Confirm content={{ header: "Do you want to delete this row ?", description: "This record will remove from this table please confirm.", }} confirmed={this.confirmDelete} />
        }
        let confirmapprove;
        if (this.state.confirmapprove === true) {
            confirmapprove = <Confirm content={{ header: "Do you want to Approve ?", description: "Call item you select to Approve.", }} confirmed={this.confirmApprove} />
        }
        let showedit;
        if (this.state.dialog_Edit === true) {
            showedit = <EditDialog close={this.close} data={this.state.dataUpdate} cancle={this.cancle} />
        }
        let error;
        if (this.state.message !== '') {
            error = <ErrorBar message={this.state.message}/>
        }
        return (
            <>{showexpand}{confirm}{showedit}{confirmapprove}
                <Grid container style={{ marginTop: '80px' }}>
                    <Grid item xs={10}>
                        
                    </Grid>
                    <Grid item xs={2}>
                        <Button
                            variant="contained"
                            color="primary"
                            endIcon={<SendIcon />}
                            onClick={this.SendApprove}
                        >
                            Approve
                        </Button>
                    </Grid>
                </Grid>
                <Grid item xs={12} style={{ marginTop: '20px' }}>
                    {loader}
                    {error}
                    {this.state.element}
                </Grid>


            </>
        )
    }
}

export default FaeApprove
