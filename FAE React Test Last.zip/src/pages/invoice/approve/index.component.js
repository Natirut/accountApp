import React from 'react'
import { Edit, Delete, AspectRatio } from '@material-ui/icons';
import { Checkbox } from '@material-ui/core';
import Tooltip from '@material-ui/core/Tooltip';
import DataTable from '../../components/datatable/index.component'
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import SendIcon from '@material-ui/icons/Send';
import SkeletonLoader from '../../components/skeleton/index.component';
import Axios from 'axios';
import Confirm from '../../components/confirm/index.component';
import Skeleton from '../../components/skeleton/index.component';
import EditDialog from './dialogEditApprove'
import ViewInvoice from '../components/viewer.component';

class InvoiceApprove extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            loader: true,
            data: [],
            element: null,
            columns: [],
            dataShow: "",
            dataCheck: [],
            body: [],
            expand: false,
            filesItem: [],
            deleteId: "",
            confirm: false,
            dialog_Edit: false,
            dataUpdate: [],
            opendetail: false,
            confirmapprove: false,
        }
        this.rowData = this.rowData.bind(this);
        this.CheckData = this.CheckData.bind(this);
        this.CheckAll = this.CheckAll.bind(this);
        this.SendApprove = this.SendApprove.bind(this);
        this.deleteClicked = this.deleteClicked.bind(this);
        this.deleteAction = this.deleteAction.bind(this);
        this.viewInvoiceDetail = this.viewInvoiceDetail.bind(this);
        this.close = this.close.bind(this);
        this.cancle = this.cancle.bind(this);
        this.openEditForm = this.openEditForm.bind(this);
        this.reload = this.reload.bind(this);
        this.confirmApprove = this.confirmApprove.bind(this);
    }
    async confirmApprove(x){
        try {
            if(x===true){
                if (this.state.body && this.state.body.length) {
                const data = {
                    "status": "approved",
                    "body": this.state.body
                }
                console.log(data)
                const instance = Axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                const response =  await instance.patch(`/fae-part/invoice/status`, data);
                console.log("res",response.data)

                setTimeout(async () => {
                    await this.setState({ element: null })
                    await this.setState({ element: <SkeletonLoader />, })
                    await this.rowData();
                }, 500);
            }  
            } else{
                this.setState({confirmapprove:false})
            }
           
        } catch (err) {
            console.log(err.stack)
            this.setState({confirmapprove:false})
        }
    }
    async openEditForm(item) {
        console.log(item)    
        await this.setState({ dataUpdate: item, })
        await this.setState({ dialog_Edit: true, })
    }
    async cancle() {
        await this.setState({dialog_Edit: false });
    }
    async reload() {

        // console.log('ROWDATA')
        setTimeout(async () => {
            await this.setState({ element: null })
            await this.setState({ element: <SkeletonLoader />, })
            await this.rowData();
        }, 500);

        this.setState({ dialog_Edit: false });
    }
    componentDidMount() {
        this.rowData();

    }
    close() {
        this.setState({ confirm: false, opendetail: false, })
    }
    async SendApprove() {
        await this.setState({ confirmapprove: true })
        await this.setState({ confirmapprove: null })
        await this.setState({ confirmapprove: true })
    }
    async CheckData(e, data) {
        let checkall = document.getElementsByName('checkall');
        //console.log(data._id)
        if (e.target.checked) {
            await this.setState({
                body: this.state.body.concat([data._id])
            })
        }
        else {
            let filteredArray = await this.state.body.filter(item => item !== data._id)
            await this.setState({
                body: filteredArray
            });
        }
        console.log("result", this.state.body)
        if(this.state.body.length===this.state.data.length){
            checkall[0].checked=true
         }
         else if(this.state.body.length!==this.state.data.length){
            checkall[0].checked=false
         }
    }
    async CheckAll(e) {
        let items = document.getElementsByName('acs');
        // console.log(items[0].value)
        if (e.target.checked) {
            for (let i = 0; i < items.length; i++) {
                await this.state.body.push(items[i].value)
                items[i].checked = true;
            }
        }
        else {
            await this.setState({ body: [] })
            for (var i = 0; i < items.length; i++) {
                items[i].checked = false;
            }
        }
      
        var _ = require('lodash');

        await this.setState({
            body: _.uniq(this.state.body, '_id')
        })
        console.log("all", this.state.body)

    }
    async deleteAction(confirm) {
        try {
            if (confirm === true) {
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                })
                // console.log(this.state.deleteId)
                await instance.delete(`/fae-part/invoice/${this.state.deleteId}`);

                this.setState({ confirm: false, })

                this.rowData();
            }
            this.setState({ confirm: false, })
        } catch (err) {
            console.log(err.stack)
            this.setState({ confirm: false, })
        }
    }
    deleteClicked(id) {
        this.setState({ confirm: true, deleteId: id });
    }
    viewInvoiceDetail(item) {
        this.setState({
            opendetail: true,
            item,
        })
    }
    async rowData() {
        //   await  this.setState({element: null,})
        try {
            this.setState({ element: <Skeleton /> });
            const column = [
                {
                    field: 'check', title: <input type="checkbox" style={{transform: 'scale(1.5, 1.5)'}} onChange={this.CheckAll}  name="checkall" ></input>, align: 'center', width: 2, sorting: false,
                },
                { field: 'more', title: <b>Action</b>, align: 'center', },
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'contractNo', title: <b>Contract no.</b>, align: 'center', },
                { field: 'contractStartDate', title: <b>Contract start.</b>, align: 'center', },
                { field: 'contractEndDate', title: <b>Contract end.</b>, align: 'center', },
                { field: 'counterpartyName', title:<b>Counterparty name.</b> , align: 'center', },
                { field: 'phoneNo', title:<b>Phone.</b> , align: 'center', },
                { field: 'fax', title:<b>Fax.</b> , align: 'center', },
                { field: 'counterpartyAddress', title:<b>Address.</b> , align: 'center', },
                { field: 'counterpartyChange', title:<b>Counterparty change.</b>, align: 'center', },
                { field: 'counterPartyChangePosition', title:<b>Counterparty position.</b>, align: 'center', },
                { field: 'invoiceDate', title:<b>Invoice date.</b>, align: 'center', },
                { field: 'typeBoi', title:<b>BOI.</b>, align: 'center', },
                { field: 'lotNo', title:<b>Lot no.</b>, align: 'center', },
                { field: 'moveOutDate', title:<b>Move out date.</b>, align: 'center', },
                { field: 'wasteName', title:<b>Wastename.</b>, align: 'center', },


            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/invoice/checked`);

            const row = [];

            // const record = new Promise((resolve) => {
            for (const item of response.data.data) {
                row.push(
                    {
                        check: <>
                            <input type="checkbox" style={{transform: 'scale(1.4, 1.4)'}} value={item._id} name="acs" onChange={e => this.CheckData(e, item)}></input>
                        </>
                        ,

                        more:
                            <>
                                <Grid container spacing={0}>
                                    <Grid item xs={12}>
                                        <Tooltip title="Expand" style={{ cursor: 'pointer', color: '#745c97' }}>
                                            <AspectRatio onClick={() => { this.viewInvoiceDetail(item) }} />
                                        </Tooltip>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Tooltip title="Edit" style={{ cursor: 'pointer', color: '#32afa9' }}>
                                        <Edit onClick={() => this.openEditForm(item)} />
                                        </Tooltip>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <Tooltip title="Delete" style={{ cursor: 'pointer', color: '#f67280' }}>
                                            <Delete onClick={() => this.deleteClicked(item._id)} />
                                        </Tooltip>
                                    </Grid>
                                </Grid>
                            </>,
                        contractNo: item.contractNo,
                        contractStartDate: item.contractStartDate,
                        contractEndDate: item.contractEndDate,
                        counterpartyName: item.counterpartyName,
                        phoneNo: item.phoneNo,
                        fax: item.fax,
                        counterpartyAddress: item.counterpartyAddress,
                        counterpartyChange: item.counterpartyChange,
                        counterPartyChangePosition: item.counterPartyChangePosition,
                        invoiceDate: item.invoiceDate,
                        typeBoi: item.typeBoi,
                        lotNo: item.lotNo,
                        wasteName: item.wasteName,
                        moveOutDate: item.moveOutDate,

                    }
                )
            }
            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, loader: false, })
                this.setState({ element: <DataTable title="Invoice Approve" headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            if (err.response.status === 401) {
                localStorage.clear();
                window.history.pushState({}, document.title, '/waste');
                window.location.reload();
            }
            this.setState({ element: <DataTable title="Invoice Approve" headers={this.state.columns} data={[]} />, loader: false, })
        }

    }
    render() {
        let confirmapprove;
        if (this.state.confirmapprove === true) {
            confirmapprove = <Confirm content={{ header: "Do you want to Approve ?", description: "Call item you select to Approve.", }} confirmed={this.confirmApprove} />
        }
        let loader;
        if (this.state.loader === true) {
            loader = <SkeletonLoader />
        }
        let confirm;
        if (this.state.confirm === true) {
            confirm = <Confirm confirmed={this.deleteAction} content={{ header: "Confirm to remove this invoice.", description: "Delete this invoice and waste this invoice rollback to approve." }} />
        }
        let opendetail;
        if (this.state.opendetail === true) {
            opendetail = <ViewInvoice item={this.state.item} close={this.close} />
        }
        let showedit;
        if (this.state.dialog_Edit === true) {
            showedit = <EditDialog  cancle={this.cancle} data={this.state.dataUpdate} reload={this.reload} />
        }
        return (
            <>
                {confirm}{opendetail}{showedit}{confirmapprove}
                <Grid container style={{ marginTop: '70px' }}>
                    <Grid item xs={10}>

                    </Grid>
                    <Grid item xs={2}>
                        <Button
                            variant="contained"
                            color="primary"
                            endIcon={<SendIcon />}
                            style={{ backgroundColor: '#007d00', color: '#bfffbf'}}
                            onClick={this.SendApprove}
                        >
                            Approve
                        </Button>
                    </Grid>
                </Grid>

                <Grid item xs={12} style={{ marginTop: '20px' }}>
                    {loader}
                    {this.state.element}
                </Grid>
            </>
        )
    }
}
export default InvoiceApprove