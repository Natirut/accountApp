import React from 'react';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import FirstStep from './firstStep';
import SecondStep from './secondStep';
// import ThirdStep from './thirdStep';
import ThirdStep from './thirdStep'



class StepperPage extends React.Component {
  constructor() {
    super();

    this.state = {
      steps: ['Get data and input form.', 'Tax invoice amount calculating.', 'Preview create'],
      activeStep: 0,
      dataMaking:null,
      dataInfor:null,
      dataquotation:null,

      //step2 to 
      datainfor2:null,
      vat:null,
      vatof:null

    }

    this.handleNext = this.handleNext.bind(this);
    this.handleReset = this.handleReset.bind(this);
    this.getmakingStep1 = this.getmakingStep1.bind(this);
    this.getInforStep1 = this.getInforStep1.bind(this);
    this.getquotation = this.getquotation.bind(this);

    this.getInforStep2 = this.getInforStep2.bind(this);

    this.getvat = this.getvat.bind(this);
    this.getvatof = this.getvatof.bind(this);
  }

 async handleNext(data) {
    await this.setState({
      activeStep: this.state.activeStep + data,
    })
  }

  async  getmakingStep1(data) {
   await this.setState({
      dataMaking:data
    })
   // console.log("marking",this.state.dataMaking)
  }

  async  getvat(data) {
    await this.setState({
       vat:data
     })

    // console.log("marking",this.state.dataMaking)
   }

   async  getvatof(data) {
    await this.setState({
       vatof:data
     })

     console.log("vatof",this.state.vatof)
   }

  async  getInforStep1(data) {
    await this.setState({
      dataInfor:data
    })
    console.log("infor",this.state.dataInfor)
  }
  
  async  getquotation(data) {
    console.log("courd")
    await this.setState({
      dataquotation:data
    })
  //  console.log("quase",this.state.dataquotation)
  }
  async getInforStep2(data) {
    await this.setState({
      datainfor2:data
    })
  }
 
  getStepContent(stepIndex) {
    switch (stepIndex) {
      case 0:
        return <FirstStep num={this.handleNext} making={this.getmakingStep1} information={this.getInforStep1}   quotation={this.getquotation}  />;
      case 1:
        return <SecondStep vat={this.getvat}  vatof={this.getvatof}  num={this.handleNext} datastep2={this.getInforStep2} backmaking={this.state.dataMaking}   backinformation={this.state.dataInfor} backquotation={this.state.dataquotation} />;
     // break;
      case 2:
          return <ThirdStep backvat={this.state.vat}  backvatof={this.state.vatof}  num={this.handleNext}   backinformation={this.state.dataInfor} numreset={this.handleReset}/>;
      //  break;
      default:
        return 'Unknown stepIndex';
    }
  }
  handleReset(num) {
    this.setState({ activeStep: num})
  }
  render() {
    return (
      <div>
        <Stepper activeStep={this.state.activeStep} alternativeLabel>
          {this.state.steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        <div>
          {this.state.activeStep === this.state.steps.length ? (
            <div>
              <Typography>All steps completed</Typography>

              {/* <Button onClick={this.handleReset}>Reset</Button> */}
            </div>
          ) : (
              <div>
                <Typography>{this.getStepContent(this.state.activeStep)}</Typography>
                <div>
                  {/* <Button
                  disabled={activeStep === 3}
                  onClick={handleBack}
                  className={classes.backButton}
                >
                  Back
              </Button> */}
                  {/* <Button variant="contained" color="primary" onClick={this.handleNext}>
                    {this.state.activeStep === this.state.steps.length - 1 ? 'Finish' : 'Next'}
                  </Button> */}
                </div>
              </div>
            )}
        </div>
      </div>
    )
  }
}

export default StepperPage;