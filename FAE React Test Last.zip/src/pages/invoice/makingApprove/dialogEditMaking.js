import React from 'react'
import Axios from 'axios';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import {Select, MenuItem, InputLabel} from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import DatePicker from '../../components/datepicker/index.component'
class DialogEditMaking extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            pickerDateStart:false,
            pickerDateEnd:false,
            pickerDateInvoice:false,
            pickerDateMove:false,

            //update
            id_update:"",
            contractno_update:"",
            contractstartdate_update:"",
            contractenddate_update:"",
            counterpartyname_update:"",
            phoneno_update:"",
            fax_update:"",
            counterpartyaddress_update:"",
            counterpartychange_update:"",
            counterPartychangePosition_update:"",
            invoicedate_update:"",
            subtotal_update:"",
            grandtotal_update:"",
            typeboi_update:"",
            lotno_update:"",
            moveoutdate_update:"",
            wastename_update:"",

        }
        console.log("props",this.props)
        this.handleClose = this.handleClose.bind(this);
        this.SetConNo = this.SetConNo.bind(this);
        this.SetConName = this.SetConName.bind(this);
        this.SetPhone = this.SetPhone.bind(this);
        this.SetFax = this.SetFax.bind(this);
        this.SetAddress = this.SetAddress.bind(this);
        this.SetChange = this.SetChange.bind(this);
        this.SetPosi = this.SetPosi.bind(this);
        this.Setlotno = this.Setlotno.bind(this);
        this.Setwastename = this.Setwastename.bind(this);
        this.SetBoi = this.SetBoi.bind(this);

        this.openDatePickerStart = this.openDatePickerStart.bind(this);
        this.onSelectedDateStart = this.onSelectedDateStart.bind(this);

        this.openDatePickerEnd = this.openDatePickerEnd.bind(this);
        this.onSelectedDateEnd = this.onSelectedDateEnd.bind(this);

        this.openDatePickerInvoice = this.openDatePickerInvoice.bind(this);
        this.onSelectedDateInvoice = this.onSelectedDateInvoice.bind(this);

        this.openDatePickerMove = this.openDatePickerMove.bind(this);
        this.onSelectedDateMove = this.onSelectedDateMove.bind(this);
        this.UpdatePrepared = this.UpdatePrepared.bind(this);
   
    }
   async UpdatePrepared(){
        try {
            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json',
                }
            })
        let body = []
        body = {
            contractNo: this.state.contractno_update,
            contractStartDate: this.state.contractstartdate_update,
            contractEndDate: this.state.contractenddate_update,
            counterpartyName: this.state.counterpartyname_update,
            phoneNo:this.state.phoneno_update,
            fax: this.state.fax_update,
            counterpartyAddress: this.state.counterpartyaddress_update,
            counterpartyChange: this.state.counterpartychange_update,
            counterPartyChangePosition: this.state.counterPartychangePosition_update,
            invoiceDate: this.state.invoicedate_update,
            subTotal: this.state.subtotal_update,
            grandTotal: this.state.grandtotal_update,
            typeBoi: this.state.typeboi_update,
            lotNo: this.state.lotno_update,
            moveOutDate: this.state.moveoutdate_update,
            wasteName:this.state.wastename_update,
            status: this.props.data.status,
            createBy: this.props.data.createBy,
            createDate: this.props.data.createDate,
            year: this.props.data.year,
            month: this.props.data.month,
            wasteItem:this.props.data.wasteItem
        }
        console.log("body",body)
            const response = await instance.put(`/fae-part/invoice/${this.state.id_update}`, body);

            console.log('data', response.data)
            this.props.reload()
        } catch (err) {
            console.log(err.response.data)
        }
    }
    openDatePickerStart() {
        this.setState({ pickerDateStart: true })
    }
    async onSelectedDateStart(date) {
        if (date !== false) {
            await this.setState({ contractstartdate_update: date.selectedDate })
        }
        this.setState({ pickerDateStart: false, })
    }

    openDatePickerEnd() {
        this.setState({ pickerDateEnd: true })
    }
    async onSelectedDateEnd(date) {
        if (date !== false) {
            await this.setState({ contractenddate_update: date.selectedDate })
        }
        this.setState({ pickerDateEnd: false, })
    }

    openDatePickerInvoice() {
        this.setState({ pickerDateInvoice: true })
    }
    async onSelectedDateInvoice(date) {
        if (date !== false) {
            await this.setState({ invoicedate_update: date.selectedDate })
        }
        this.setState({ pickerDateInvoice: false, })
    }

    openDatePickerMove() {
        this.setState({ pickerDateMove: true })
    }
    async onSelectedDateMove(date) {
        if (date !== false) {
            await this.setState({ moveoutdate_update: date.selectedDate })
        }
        this.setState({ pickerDateMove: false, })
    }

    async SetConNo(e) {
        await  this.setState({ contractno_update: e.target.value })
          console.log(this.state.contractno_update)
      }
      async SetConName(e) {
        await  this.setState({ counterpartyname_update: e.target.value })
          console.log(this.state.counterpartyname_update)
      }
      async SetPhone(e) {
        await  this.setState({ phoneno_update: e.target.value })
          console.log(this.state.phoneno_update)
      }
      async SetFax(e) {
        await  this.setState({ fax_update: e.target.value })
          console.log(this.state.fax_update)
      }
      async SetAddress(e) {
        await  this.setState({ counterpartyaddress_update: e.target.value })
          console.log(this.state.counterpartyaddress_update)
      }
      async SetChange(e) {
        await  this.setState({ counterpartychange_update: e.target.value })
          console.log(this.state.counterpartychange_update)
      }
      async SetPosi(e) {
        await  this.setState({ counterPartychangePosition_update: e.target.value })
          console.log(this.state.counterPartychangePosition_update)
      }
      async Setlotno(e) {
        await  this.setState({ lotno_update: e.target.value })
          console.log(this.state.lotno_update)
      }
      async Setwastename(e) {
        await  this.setState({ wastename_update: e.target.value })
          console.log(this.state.wastename_update)
      }
      async SetBoi(e) {
        await this.setState({ typeboi_update: e.target.value })
        console.log(this.state.typeboi_update)
    }
   
    async componentDidMount() {
        console.log(this.props)
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })

        await this.setState({
            id_update:this.props.data._id,
            contractno_update:this.props.data.contractNo,
            contractstartdate_update:this.props.data.contractStartDate,
            contractenddate_update:this.props.data.contractEndDate,
            counterpartyname_update:this.props.data.counterpartyName,
            phoneno_update:this.props.data.phoneNo,
            fax_update:this.props.data.fax,
            counterpartyaddress_update:this.props.data.counterpartyAddress,
            counterpartychange_update:this.props.data.counterpartyChange,
            counterPartychangePosition_update:this.props.data.counterPartyChangePosition,
            invoicedate_update:this.props.data.invoiceDate,
            subtotal_update:this.props.data.subTotal,
            grandtotal_update:this.props.data.grandTotal,
            typeboi_update:this.props.data.typeBoi,
            lotno_update:this.props.data.lotNo,
            moveoutdate_update:this.props.data.moveOutDate,
            wastename_update:this.props.data.wasteName,
        })
    }
    handleClose() {
        this.props.cancle()
    }
    render() {
        let datepickerstart;
        if (this.state.pickerDateStart === true) {
            datepickerstart = <DatePicker callBackClose={this.onSelectedDateStart} />
        }

        let datepickerend;
        if (this.state.pickerDateEnd === true) {
            datepickerend = <DatePicker callBackClose={this.onSelectedDateEnd} />
        }

        let datepickerinvoice;
        if (this.state.pickerDateInvoice === true) {
            datepickerinvoice = <DatePicker callBackClose={this.onSelectedDateInvoice} />
        }

        let datepickermove;
        if (this.state.pickerDateMove === true) {
            datepickermove = <DatePicker callBackClose={this.onSelectedDateMove} />
        }
        return (
            <>{datepickerstart}{datepickerend}{datepickerinvoice}{datepickermove}
                <Dialog
                    fullWidth="true"
                    maxWidth="md"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}
                >
                    <DialogTitle >Edit Prepared</DialogTitle>
                    <DialogContent  >
                        <Grid container>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Contract No"
                                    value={this.state.contractno_update}
                                    variant="outlined"
                                    onChange={this.SetConNo}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Contract Start Date"
                                    value={this.state.contractstartdate_update}
                                    variant="outlined"
                                   // onChange={this.SetConName}
                                   onClick={this.openDatePickerStart} 
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Contract End Date"
                                    value={this.state.contractenddate_update}
                                    variant="outlined"
                                  //  onChange={this.SetPhone}
                                  onClick={this.openDatePickerEnd} 
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Counterparty Name"
                                    value={this.state.counterpartyname_update}
                                    variant="outlined"
                                    onChange={this.SetConName}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                        </Grid>



                        {/* //2 */}
                        <Grid container>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Phone No"
                                    value={this.state.phoneno_update}
                                    variant="outlined"
                                    onChange={this.SetPhone}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Fax"
                                    value={this.state.fax_update}
                                    variant="outlined"
                                    onChange={this.SetFax}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Counterparty Address"
                                    value={this.state.counterpartyaddress_update}
                                    variant="outlined"
                                    onChange={this.SetAddress}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Counterparty Change"
                                    value={this.state.counterpartychange_update}
                                    variant="outlined"
                                    onChange={this.SetChange}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                        </Grid>




                        {/* //3 */}
                        <Grid container>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="CounterParty ChangePosition"
                                    value={this.state.counterPartychangePosition_update}
                                    variant="outlined"
                                    onChange={this.SetPosi}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Invoice Date"
                                    value={this.state.invoicedate_update}
                                    variant="outlined"
                                    onClick={this.openDatePickerInvoice} 
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                {/* <TextField
                                    id="outlined-required"
                                    label="Type of Boi"
                                    value={this.state.typeboi_update}
                                    variant="outlined"
                                    style={{margin:'7px'}}
                                /> */}
                                 <FormControl variant="outlined"  >
                                          <InputLabel id="demo-simple-select-helper-label" style={{ marginLeft: '10px',marginTop: '7px' }}>Type of BOI/Non-BOI</InputLabel>
                                        <Select
                                            label="Type of BOI/Non-BOII"   
                                            labelId="demo-simple-select-helper-label"
                                            id="typeBoi"
                                            //style={{ width: '150px', marginLeft: '30px' }}
                                            style={{margin:'7px', width:'212px',}}
                                            onChange={this.SetBoi}
                                            value={this.state.typeboi_update}
                                          
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value={true}>BOI</MenuItem>
                                            <MenuItem value={false}>NON-BOI</MenuItem>
                                        </Select>
                                 </FormControl>
                              
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="lot No"
                                    value={this.state.lotno_update}
                                    variant="outlined"
                                    onChange={this.Setlotno}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                      
                        </Grid>



                        {/* //4 */}
                        <Grid container>
                            
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Move Out Date"
                                    value={this.state.moveoutdate_update}
                                    variant="outlined"
                                    onClick={this.openDatePickerMove} 
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                            <Grid item xs={3}>
                                <TextField
                                    id="outlined-required"
                                    label="Waste Name"
                                    value={this.state.wastename_update}
                                    variant="outlined"
                                    onChange={this.Setwastename}
                                    style={{margin:'7px'}}
                                />
                            </Grid>
                  
                        </Grid>
                    </DialogContent>
                    <DialogActions>
                            <Button onClick={this.UpdatePrepared} color="primary">UPDATE</Button>
                        </DialogActions>
                </Dialog>
            </>
        )
    }
}
export default DialogEditMaking

