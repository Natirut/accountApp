
import React from 'react';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import Paper from '@material-ui/core/Paper';

import Grid from '@material-ui/core/Grid';

import Datatable from '../../components/datatable/index.component';


class ViewInvoice extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            open: false,
            Transition: null,
            columns: [],
            data: props.item,
        }
        // console.log(props)
        this.handleClose = this.handleClose.bind(this)
    }
    componentDidMount() {
        this.setState({
            columns: [
                { title: 'Quotation No.', field: 'quotationNo', align: 'center' },
                { title: 'Waste name', field: 'wasteName', align: 'center' },
                { title: 'Quantity', field: 'quantity', align: 'center' },
                { title: 'Unit price', field: 'unitPrice', align: 'center' },
                { title: 'Amount', field: 'amount', align: 'center' },
            ]
        })
        this.setState({
            Transition: React.forwardRef(function Transition(props, ref) {
                return <Slide direction="up" ref={ref} {...props} />
            }),
            open: true,
        })
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.close();
    }
    render() {
        return (
            <Dialog
                open={this.state.open}
                TransitionComponent={this.state.Transition}
                fullScreen={true}
                keepMounted
                onClose={this.handleClose}
                aria-labelledby="alert-dialog-slide-title"
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle>
                    <Grid container spacing={0}>
                        <Grid item xs={1}>

                        </Grid>
                        <Grid item xs={10} style={{
                            boxShadow: '1px 1px 0px 2px #8675a9',
                            borderRadius: '5px',
                            padding: '10px',
                            backgroundColor: '#faf0ff',
                            textAlign: 'center',
                            marginTop: 'calc(2%)'
                        }}>
                            Automatics invoice data.
                        </Grid>
                        <Grid item xs={1}>

                        </Grid>
                    </Grid>
                </DialogTitle>
                <DialogContent>
                    <DialogContentText >
                        <Grid container spacing={0} style={{
                            boxShadow: '#d45d79 0px 0px 4px 1px',
                            padding: '20px',
                            borderRadius: '5px',
                            backgroundColor: 'aliceblue'
                        }}>

                            {/* ROW 1 */}
                            <Grid container spacing={0}>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Contract No: {this.state.data.contractNo}
                                    </Paper>
                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Contract start date: {this.state.data.contractStartDate}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Contract end date: {this.state.data.contractEndDate}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px'
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Counter party name: {this.state.data.counterpartyName}
                                    </Paper>

                                </Grid>
                            </Grid>
                            {/* ROW 1 */}

                            {/* ROW 2 */}
                            <Grid container spacing={0} style={{ marginTop: '20px' }}>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Phone: {this.state.data.phoneNo}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        FAX: {this.state.data.fax}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Counter party change: {this.state.data.counterpartyChange}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Counter party position: {this.state.data.counterPartyChangePosition}
                                    </Paper>

                                </Grid>
                            </Grid>
                            {/* ROW 2 */}

                            {/* ROW 3 */}
                            <Grid container spacing={0} style={{ marginTop: '20px' }}>
                                <Grid item xs={12} style={{
                                    textAlign: 'left',
                                    borderRadius: '5px',
                                    padding: '5px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Address: {this.state.data.counterpartyAddress}
                                    </Paper>

                                </Grid>
                            </Grid>
                            {/* ROW 3 */}

                            {/* ROW 4 */}
                            <Grid container spacing={0} style={{ marginTop: '20px' }}>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Invoice date: {this.state.data.invoiceDate}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Waste name: {this.state.data.wasteName}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Move out date: {this.state.data.moveOutDate}
                                    </Paper>

                                </Grid>
                                <Grid item xs={3} style={{
                                    textAlign: 'center',
                                    borderRadius: '5px',
                                    padding: '2px',
                                }}>
                                    <Paper style={{ padding: '5px' }}>
                                        Lot no: {this.state.data.lotNo}
                                    </Paper>

                                </Grid>
                            </Grid>
                            {/* ROW 4 */}

                            {/* DATA TABLE */}
                            <Grid container spacing={0} style={{ marginTop: '20px' }}>
                                <Grid item xs={12}>
                                    <Datatable title="Invoice items." headers={this.state.columns} data={this.state.data.wasteItem} />
                                </Grid>
                            </Grid>
                            {/* DATA TABLE */}

                            <Grid container spacing={0} style={{ marginTop: '10px' }}>
                                <Grid item xs={8}>

                                </Grid>

                                <Grid item xs={4}>
                                    <Paper elevation={3} style={{ padding: '10px' }}>
                                        <p>Sub Total: {this.state.data.subTotal}</p>
                                        <p>Grand Total: {this.state.data.grandTotal}</p>
                                    </Paper>
                                </Grid>
                            </Grid>
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} color="primary" style={{
                        backgroundColor: '#ffb3bf', color: '#001247'
                    }}>
                        Close
          </Button>
                </DialogActions>
            </Dialog>
        )
    }
}

export default ViewInvoice;
