
import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
// import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import _ from 'lodash';
// PRPOS CONTEXT

// data=['base64str', '']
// close=function
//PROPS CONTEXT
class TakedImages extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            data: props.data,
            open: false,
            element: null,
        }
        this.handleClose = this.handleClose.bind(this);
        this.removeImage = this.removeImage.bind(this);
    }
    async removeImage(index) {
        await _.pullAt(this.state.data, [index])

        this.setState({
            data: this.state.data
        })
        this.componentWillMount();
    }
    componentWillMount() {
        console.log('RECIVED PROPS', this.props)
        this.setState({ open: true });

        this.setState({
            element: this.state.data.map((item, index) => (
                <>
                    <Grid item xs={4}>
                        <Card>
                            <CardActionArea>
                                <CardMedia
                                    component="img"
                                    alt="Contemplative Reptile"
                                    height="200"
                                    image={item}
                                    title="Contemplative Reptile"
                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        Image {index + 1}
                                    </Typography>
                                    <Typography variant="body2" color="textSecondary" component="p">
                                        Press <b>DELETE</b> button to Delete this images.
          </Typography>
                                </CardContent>
                            </CardActionArea>
                            <CardActions>
                                <Button size="small" color="primary"
                                    style={{ backgroundColor: '#c51162', color: 'aliceblue' }}
                                    onClick={() => this.removeImage(index)}

                                >Delete</Button>
                            </CardActions>
                        </Card>
                        {/* <img src={item} alt="" width="100%" height="100%" /> */}
                    </Grid>
                </>
            ))
        })
    }
    handleClose() {
        this.props.close(this.state.data);
    }
    render() {
        return (
            <Dialog
                open={this.state.open}
                onClose={this.handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                fullScreen
            >
                <DialogTitle id="alert-dialog-title"
                    style={{ backgroundColor: '#01579b', color: 'aliceblue' }}
                >{"All images on capture."}</DialogTitle>
                <DialogContent style={{ backgroundColor: '#e0f7fa' }}>
                    <DialogContentText id="alert-dialog-description">
                        <Grid container spacing={1}>
                            {this.state.element}
                        </Grid>
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} color="primary" autoFocus
                        style={{ width: '100%', backgroundColor: 'rgba(0, 188, 212, 0.7)', color: '#d50000' }}
                    >Confirm Images</Button>
                </DialogActions>
            </Dialog>
        )
    }
}

export default TakedImages;
