import React, { Component } from 'react';
// import ReactDOM from 'react-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';

// PROPS CONTEXT
// images=['imagename1', 'imagename1']
// close=Function

// PROPS CONTEXT
class DemoCarousel extends Component {

    constructor(props) {
        super(props);

        this.state = {
            open: false,
            element: null,
        }
        this.handleClose = this.handleClose.bind(this);
        this.createElementImage = this.createElementImage.bind(this);
    }
    componentDidMount() {
        this.setState({ open: true })
        this.createElementImage();
    }
    createElementImage() {
        this.setState({ element: this.props.images.map((item) => (
            <>
                {/* {`${process.env.REACT_APP_FILES_PATH}/files/${item}`} */}
                <img src={`${process.env.REACT_APP_FILES_PATH}/files/${item}`} alt="" />
                {/* {item.substring(item.length - 3 , item.length)} */}
            </>
        ))})
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.cancle();
    }
    render() {
        return (
            <Dialog
                open={this.state.open}
                onClose={this.state.handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>
                    <Carousel infiniteLoop emulateTouch>
                        {this.state.element}
                    </Carousel>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.handleClose} style={{ backgroundColor: '#1a1b4b', color: 'aliceblue'}}>Close</Button>
                </DialogActions>
            </Dialog>

        );
    }
}

export default DemoCarousel;