
import React from 'react';

import Skeleton from '@material-ui/lab/Skeleton';

class SkeletonLoader extends React.Component {

    render() {
        return (
            <React.Fragment>
                <Skeleton />
                <Skeleton animation="wave" style={{ height: '80px' }} />
                <Skeleton animation="wave" />
            </React.Fragment>

        )
    }
}

export default SkeletonLoader;
