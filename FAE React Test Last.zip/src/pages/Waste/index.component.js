import React from 'react';
import Grid from '@material-ui/core/Grid';
// import _ from 'lodash';
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';
import Fab from '@material-ui/core/Fab';
import './style.css';
import Atp from '../../App'
import Success from '../components/successBar/index.component';
import ReactDOM from 'react-dom';
import Create from './createForm.component';
import { PostAdd, Edit, Delete, AspectRatio } from '@material-ui/icons';
import DataTable from '../components/datatable/index.component';
import Caronsol from '../components/imageCategory/index.component';
import SkeletonLoader from '../components/skeleton/index.component';
import EditDialog from './dialog_EditWaste'
import axios from 'axios';

import Confirm from '../components/confirm/index.component';


class RecordData extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            openForm: false,
            columns: [],
            data: [],
            element: null,
            loader: true,
            confirm: false,
            deleteId: '',
            message: '',
            expand: false,
            dialog_Carlonso: false,
            filesItem: [],
            dialog_Edit:false,
            dataUpdate:[]
        }
        this.openCreateForm = this.openCreateForm.bind(this);
        this.openEditForm = this.openEditForm.bind(this);
        this.close = this.close.bind(this);
        this.cancle = this.cancle.bind(this);
        this.confirmDelete = this.confirmDelete.bind(this);
        this.onRecordDelete = this.onRecordDelete.bind(this);
        this.showExpand = this.showExpand.bind(this);

        this.rowData = this.rowData.bind(this);
    }
    async openEditForm(item) {
        console.log(item)
        await this.setState({ dataUpdate: item, })
        await this.setState({ dialog_Edit: true, })
    }
    componentDidMount() {
        this.rowData();
    }
    onRecordUpdate(item) {
        console.log(item);
    }
    onRecordDelete(id) {
        console.log(id)
        this.setState({
            deleteId: id,
            confirm: true,
        })
    }
    onRecordDetail(item) {
        console.log(item);
    }
    showExpand(files) {
        console.log(files)
        this.setState({ expand: true, filesItem: files })
    }
    async confirmDelete(x) {
        try {
            if (x === true) {
                const instance = axios.create({
                    baseURL: process.env.REACT_APP_ENDPOINT,
                    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
                });

                const response = await instance.delete(`/fae-part/waste/${this.state.deleteId}`);

                // _.remove(this.state.data, { idMapping: this.state.deleteId });
                // this.setState({
                //     message: response.data.message,
                //     data: this.state.data,
                //     element: null,
                // })
              console.log(response)
               //  this.setState({ element: <DataTable headers={this.state.columns} data={this.state.data} /> })
                
              await  this.setState({ confirm: false, })
              await    setTimeout(async () => {
                this.setState({element: null})
                this.setState({element: <SkeletonLoader />,})
                await this.rowData();
            }, 500);
           

            }else{
                this.setState({ confirm: false, })
            }
        } catch (err) {
            this.setState({ confirm: false, })
        }
    }

    async rowData() {
        try {
            // console.log('ROWDATA')
            //  setTimeout(async () => {
            //      this.setState({element: <SkeletonLoader />,})
            //  }, 500);

            //this.setState({element: null,})
            const column = [
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'more', title:<b>Action</b> , align: 'center', },
                // headerStyle: { backgroundColor: '#ffccbc' }
                { field: 'typeBoi', title:<b>TypeBoi</b> , align: 'center', },
                { field: 'date', title: <b>Date</b>, align: 'center', },
                { field: 'time', title:<b>Time</b>, align: 'center', },
                { field: 'cptType', title:<b>CptType</b> , align: 'center', },
                { field: 'lotNo', title:<b>LotNo.</b> , align: 'center', },
                { field: 'companyApprove', title:<b>CompanyApprove.</b> , align: 'center', },
                { field: 'gennerateGroup', title:<b>GennerateGroup.</b> , align: 'center', },
                { field: 'wasteGroup', title:<b>WasteGroup.</b> , align: 'center', },
                { field: 'wasteName', title:<b>WasteName.</b> , align: 'center', },
                { field: 'totalWeight', title:<b>TotalWeight.</b> , align: 'center', },
                { field: 'containerWeight', title:<b>ContainerWeight.</b>, align: 'center', },
                { field: 'netWasteWeight', title:<b>NetWasteWeight.</b>, align: 'center', },
                { field: 'wasteContractor', title:<b>ContractortCompany.</b>, align: 'center', },
                { field: 'containerType', title:<b>containerType.</b>, align: 'center', },
                { field: 'phase', title:<b>Phase.</b>, align: 'center', },
               
            ];
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
            });

            const response = await instance.get(`/fae-part/waste/open`);

            this.setState({
                Alldata: response.data.data
            })



            const row = [];

            // const record = new Promise((resolve) => {
            for (const item of response.data.data) {
                row.push(
                    {
                        more:
                        <>
                            <Grid container spacing={2}>
                                <Grid item xs={12}>
                                    <Tooltip title="Expand" style={{ cursor: 'pointer', color: '#745c97' }}>
                                        <AspectRatio onClick={() => this.showExpand(item.files)} />
                                    </Tooltip>
                                </Grid>
                                <Grid item xs={6}>
                                    <Tooltip title="Edit" style={{ cursor: 'pointer', color: '#32afa9' }}>
                                        {/* <Edit onClick={() => this.onRecordUpdate(item)} /> */}
                                        <Edit onClick={() => this.openEditForm(item)} />
                                    </Tooltip>
                                </Grid>
                                <Grid item xs={6}>
                                    <Tooltip title="Delete" style={{ cursor: 'pointer', color: '#f67280' }}>
                                        <Delete onClick={() => this.onRecordDelete(item._id)} />
                                    </Tooltip>
                                </Grid>
                            </Grid>
                        </>,
                        typeBoi: item.typeBoi,
                        date: item.date,
                        time: item.time,
                        cptType: item.cptType,
                        lotNo: item.lotNo,
                        companyApprove: item.companyApprove,
                        gennerateGroup: item.gennerateGroup,
                        wasteGroup: item.wasteGroup,
                        wasteName: item.wasteName,
                        totalWeight: item.totalWeight,
                        containerWeight: item.containerWeight,
                        netWasteWeight: item.netWasteWeight,
                        wasteContractor: item.wasteContractor,
                        containerType: item.containerType,
                        phase: item.phase, 
                    }
                )
            }
            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, loader: false, })
                this.setState({ element: <DataTable title="Waste on created." headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            console.log(err.response.status)
            if (err.response.status === 401) {
                localStorage.clear();
                ReactDOM.unmountComponentAtNode(document.getElementById('root'))
                ReactDOM.render(<Atp />, document.getElementById('root'));
            }
            this.setState({ element: <DataTable title="Waste on created." headers={this.state.columns} data={[]} />, loader: false, })
        }
    }
    async close() {
        console.log("tt") 
            setTimeout(async () => {
                await  this.setState({element: null})
                await this.setState({element: <SkeletonLoader />,})
                await this.rowData();
             }, 500);
            
               this.setState({ openForm: false, expand: false,dialog_Edit:false });

    }
   async cancle(){
        await  this.setState({ openForm: false, expand: false,dialog_Edit:false });
    }
    async openCreateForm() {
        await this.setState({ openForm: true, })
    }
    render() {
        let create; let loader; let confirm; let success; let showexpand; let showedit;
        if (this.state.openForm === true) {
            create = <Create close={this.close} />
        }
        if (this.state.loader === true) {
            loader = <SkeletonLoader />
        }
        if (this.state.confirm === true) {
            confirm = <Confirm content={{ header: "Do you want to delete this row ?", description: "This record will remove from this table please confirm.", }} confirmed={this.confirmDelete} />
        }
        if (this.state.message !== '') {
            success = <Success message={this.state.message} />
        }
        if (this.state.expand === true) {
            showexpand = <Caronsol images={this.state.filesItem} close={this.close} cancle={this.cancle} />
        }
        if (this.state.dialog_Edit === true) {
            showedit = <EditDialog  close={this.close} data={this.state.dataUpdate} cancle={this.cancle}/>
        }
        return (
            <>
                {create}{confirm}{success}{showexpand}{showedit}
                <Grid container spacing={0} style={{ marginTop: 'calc(4%)' }}>
                    <Grid item xs={10}>
                    </Grid>
                    <Grid item xs={2} className="record-action">
                        <center>
                            <Tooltip title="Add item" aria-label="add">
                                <Fab color="secondary" style={{ backgroundColor: '#81f5ff' }} onClick={this.openCreateForm}>
                                    <AddIcon />
                                </Fab>
                            </Tooltip>
                            {/* <Tooltip title="Create Invoice">
                                <Fab color="secondary" style={{ backgroundColor: '#f19292', marginLeft: '5px' }}>
                                    <PostAdd />
                                </Fab>
                            </Tooltip> */}
                        </center>
                    </Grid>

                    {/* SET ROUTE BUTTON */}
                    {/* <Grid container spacing={0} style={{ marginTop: 'calc(2%)' }}>
                        <Grid item xs={10}>

                        </Grid>
                        <Grid item xs={2}>
                            <center>
                                <Button variant="outlined" color="primary">Approve</Button>
                            </center>

                        </Grid>
                    </Grid> */}

                    {/* SET ROUTE BUTTON */}

                    <Grid item xs={12} style={{ marginTop: '20px' }}>
                        {loader}
                        {this.state.element}
                        {/* <DataTable columns={this.state.column} data={this.state.row} /> */}
                    </Grid>
                </Grid>

            </>
        )
    }
}

export default RecordData;