import React from 'react';
import moment from 'moment';
import Axios from 'axios';
import { CameraAlt, CloudUpload, Today } from '@material-ui/icons';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import TextField from '@material-ui/core/TextField';
import { Grid, Select, MenuItem, InputLabel, ButtonGroup, IconButton } from '@material-ui/core';
import DatePicker from '../components/datepicker/index.component'
import Camera from '../components/captureImages/captureImages.component'
class EditWaste extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            //dataWaste:[],
            captureImage:false,
            data_com:null,
            pickerDate: false,
            filesSelected:null,
            imagedata:"",


            status_file:false,
            id_update:"",
            boi_update:"",
            date_update:"",
            time_update:"",
            type_update:"",
            lotno_update:"",
            companyno_update:"",
            generate_update:"",
            wastegroup_update:"",
            wastename_update:"",
            totalweight_update:"",
            containerweight_update:"",
            netwaste_update:"",
            contractor_update:"",
            containertype_update:"",
            phase_update:"",
            files_update:"",
            status_update:""

        }
        this.onFileSelect = this.onFileSelect.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.SetBoi = this.SetBoi.bind(this);
        this.GetCompany = this.GetCompany.bind(this);
        this.openDatePicker = this.openDatePicker.bind(this);
        this.onSelectedDate = this.onSelectedDate.bind(this);
        this.SetCptType = this.SetCptType.bind(this);
        this.SetLotno = this.SetLotno.bind(this);
        this.SetComno = this.SetComno.bind(this);
        this.SetGenerate = this.SetGenerate.bind(this);
        this.SetWasteGroup = this.SetWasteGroup.bind(this);
        this.SetWasteName = this.SetWasteName.bind(this);
        this.SetTotalWaight = this.SetTotalWaight.bind(this);
        this.SetConWeight = this.SetConWeight.bind(this);
        this.SetContractor = this.SetContractor.bind(this);
        this.SetContainertype = this.SetContainertype.bind(this);
        this.SetPhase = this.SetPhase.bind(this);
        this.getCurren = this.getCurren.bind(this);
        this.SetTime = this.SetTime.bind(this);
        this.openCamera = this.openCamera.bind(this);
        this.close = this.close.bind(this); 
        this.submit = this.submit.bind(this);  

        console.log('PSROPS EDIT: ', props)
    }

    openCamera() {
        this.setState({ captureImage: true })
    }
   async onFileSelect(e) {
      await  this.setState({ filesSelected: e.target.files })
        console.log(this.state.filesSelected)
    }
    async SetBoi(e) {
        await this.setState({ boi_update: e.target.value })
        console.log(this.state.boi_update)
    }
    async SetCptType(e) {
        await this.setState({ type_update: e.target.value })
    }
    async SetLotno(e) {
        await this.setState({ lotno_update: e.target.value })
        console.log(this.state.lotno_update)
    }
    async SetComno(e) {
        await this.setState({ companyno_update: e.target.value })
    }
    async SetGenerate(e) {
        await this.setState({ generate_update: e.target.value })
    }
    async SetWasteGroup(e) {
        await this.setState({ wastegroup_update: e.target.value })
    }
    async SetWasteName(e) {
        await this.setState({ wastename_update: e.target.value })
    }
    async SetContractor(e) {
        await this.setState({ contractor_update: e.target.value })
    }
    async SetContainertype(e) {
        await this.setState({ containertype_update: e.target.value })
    }
    async SetPhase(e) {
        await this.setState({ phase_update: e.target.value })
    }
    async SetTime(e) {
        console.log(e.target.value)
        this.setState({ time_update: e.target.value })
    }
    SetTotalWaight(event){
        // console.log(e.target.value)
        this.setState({
            totalweight_update:event.target.value,
            netwaste_update: (parseFloat(event.target.value) - parseFloat(this.state.containerweight_update)).toFixed(3).toString(),
         })
       // console.log(this.state.totalWeight)
 
     }
  
     SetConWeight(event) {
         this.setState({
            containerweight_update: event.target.value,
             netwaste_update: (parseFloat(this.state.totalweight_update) - parseFloat(event.target.value)).toFixed(3).toString(),
         });
     }
    handleClose() {
        this.props.cancle();
    }
    async submit() {

        try { 
            let formData = new FormData();

            formData.append('date', document.getElementById('date').value);
            formData.append('time', document.getElementById('time').value);
            formData.append('phase', this.state.phase_update);
            formData.append('typeBoi', this.state.boi_update);
            formData.append('cptType', this.state.type_update);
            formData.append('lotNo', document.getElementById('lotNo').value);
            formData.append('companyApprove', document.getElementById('companyApprove').value);
            formData.append('gennerateGroup', this.state.generate_update);
            formData.append('wasteGroup', this.state.wastegroup_update);
            formData.append('wasteName', document.getElementById('wasteName').value);
            formData.append('totalWeight', this.state.totalweight_update);
            formData.append('containerWeight', this.state.containerweight_update);
            formData.append('containerType', this.state.containertype_update);
            formData.append('netWasteWeight', this.state.netwaste_update);
            formData.append('wasteContractor', this.state.contractor_update);
            formData.append('status', this.state.status_update);
            
            // if(this.state.imagedata!=="" && this.state.filesSelected!==null){
            //     for (const item of this.state.imagedata) {
            //         formData.append('imageCapture', item);
            //    }
            //    for (const item of this.state.filesSelected) {
            //        formData.append('files', item);
            //    }      
            //  }

            if(this.state.imagedata!=="" ){
                for (const item of this.state.imagedata) {
                    formData.append('imageCapture', item);
               }
            }

           else if(this.state.filesSelected!==null ){
                for (const item of this.state.filesSelected) {
                         formData.append('files', item);
                     }  
            }else{
                for (const item of this.state.files_update) {
                    formData.append('imageCapture', item);
                }
                    
            }
                   

            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { 
                    'Content-Type': 'multipart/form-data', accept: 'text/plain', 
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const response = await instance.put(`/fae-part/waste/${this.state.id_update}`, formData);
            
            console.log(response)
            this.props.close()
         
        } catch (err) {
            console.log(err.stack)
        }
    }
   async componentDidMount() {
       await this.GetCompany()
       //await this.setState({dataWaste:this.props.data})
       console.log("test",this.props.data.files)
       await this.setState({
           id_update:this.props.data._id,
           boi_update:this.props.data.typeBoi,
           date_update:this.props.data.date,
           time_update:this.props.data.time,
           type_update:this.props.data.cptType,
           lotno_update:this.props.data.lotNo,
           companyno_update:this.props.data.companyApprove,
           generate_update:this.props.data.gennerateGroup,
           wastegroup_update:this.props.data.wasteGroup,
           wastename_update:this.props.data.wasteName,
           totalweight_update:this.props.data.totalWeight,
           containerweight_update:this.props.data.containerWeight,
           netwaste_update:this.props.data.netWasteWeight,
           contractor_update:this.props.data.wasteContractor,
           containertype_update:this.props.data.containerType,
           phase_update:this.props.data.phase,
           files_update:this.props.data.files,
           status_update:this.props.data.status
        })
        console.log("fileUp",this.state.files_update)
        await  this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await  this.setState({ open: true, })
    }
    openDatePicker() {
        this.setState({ pickerDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ date_update: date.selectedDate })
        }
        this.setState({ pickerDate: false, })
    }
    getCurren() {
        let datee
        let timee
        datee = moment(this.state.currenDate).format('YYYY/MM/DD')
        timee = moment(this.state.currenDate).format('HH:mm')
        this.setState({ date_update: datee })
        this.setState({ time_update: timee })
        console.log(datee)
        console.log(timee)

    }
    uploadFileOnlocal(){
        document.getElementById('file').click();
    }
    GetCompany() {
        //  let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        try {
            Axios.get(url,{ headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } } )
                .then(res => {
                    this.setState({
                        data_com: res.data.data.map((item) => (
                            <MenuItem value={item.companyName}>{item.companyName} </MenuItem>
                        ))
                    });
                     console.log(res.data)

                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    close(image) {
        console.log("dataImage",image)
        if(image) {
            console.log("IMAGE: ", image)
            this.setState({imagedata:image})
            
        }
        this.setState({ captureImage: false, })
    }
    render() {
        let datepicker;
        if (this.state.pickerDate === true) {
            datepicker = <DatePicker callBackClose={this.onSelectedDate} />
        }
        let camera;
        if (this.state.captureImage === true) {
            camera = <Camera close={this.close} />
        }
        return (
            <>
                <div>{datepicker}{camera}
                    <Dialog
                        fullWidth="true"
                        maxWidth="md"
                        open={this.state.open}
                        TransitionComponent={this.state.slide}
                        onClose={this.handleClose}

                    >
                        <DialogTitle >Edit Waste</DialogTitle>
                        <DialogContent  >
                            <Grid item xs={12}   >
                                {/* row1 */}
                                <Grid container spacing={1}>
                                    <Grid item xs={4}>
                                        <InputLabel id="demo-simple-select-helper-label" style={{ marginLeft: '30px' }}>Type of BOI/Non-BOI</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-helper-label"
                                            id="typeBoi"
                                            style={{ width: '150px', marginLeft: '30px' }}
                                            onChange={this.SetBoi}
                                            value={this.state.boi_update}
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value={true}>BOI</MenuItem>
                                            <MenuItem value={false}>NON-BOI</MenuItem>
                                            {/* <MenuItem value={80}><div style={{ marginLeft: '35%' }}><AddCircleIcon fontSize="large" style={{ color: green[500] }} /></div></MenuItem> */}
                                        </Select>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField id="date" label="Move Out Date" variant="outlined"  value={this.state.date_update} onClick={this.openDatePicker}  />
                                    </Grid>

                                    <Grid item xs={4}>
                                        <TextField onChange={this.SetTime} value={this.state.time_update} style={{ width: '180px' }} id="time"  type="time" label="Move Out Time" variant="outlined" />
                                        <Today onClick={this.getCurren} style={{ color: '#00b300', position: 'absolute' }} />
                                    </Grid>
                                </Grid>
                                {/* row2 */}
                                <Grid container style={{ paddingTop: 'calc(3%)' }} >
                                    <Grid item xs={4}>
                                        <InputLabel style={{ marginLeft: '30px' }} id="select-cpt-type">CPT Type</InputLabel>
                                        <Select value={this.state.type_update} style={{ width: '60%', marginLeft: '30px' }} label="CPT Type" color="primary" labelId="select-cpt-type" id="cptType" onChange={this.SetCptType}>
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="Fixed Asset">Fixed Asset</MenuItem>
                                            <MenuItem value="Non Fixed Asset">Non Fixed Asset</MenuItem>
                                            <MenuItem value="Company Approval">Company Approval</MenuItem>
                                            <MenuItem value="Parts">Parts</MenuItem>
                                            <MenuItem value="PMD">PMD</MenuItem>
                                            <MenuItem value="IMO">IMO</MenuItem>
                                            <MenuItem value="MSC">MCS</MenuItem>
                                            <MenuItem value="-">Other (Please Specific)</MenuItem>
                                        </Select>
                                    </Grid>
                                    <Grid item xs={4} >
                                        <TextField  onChange={this.SetLotno}  value={this.state.lotno_update} label="Lot No." variant="outlined" id="lotNo" />
                                    </Grid>
                                    <Grid item xs={4} >
                                        <TextField onChange={this.SetComno} value={this.state.companyno_update} label="Company Approval No." variant="outlined" id="companyApprove" />
                                    </Grid>
                                </Grid>
                                {/* third Row */}
                                <Grid container spacing={0} style={{ paddingTop: 'calc(3%)' }} >
                                    <Grid item xs={4}>
                                        <InputLabel style={{ marginLeft: '30px' }} id="gennerate-group">Generate Group</InputLabel>
                                        <Select onChange={this.SetGenerate} value={this.state.generate_update} style={{ width: '60%', marginLeft: '30px' }} color="primary" labelId="gennerate-group" id="gennerateGroup" >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="Production">Production</MenuItem>
                                            <MenuItem value="Non-Production">Non-Production</MenuItem>
                                            <MenuItem value="-">Other (Please Specific)</MenuItem>
                                        </Select>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <InputLabel id="gennerate-group">Waste Group</InputLabel>
                                        <Select onChange={this.SetWasteGroup} value={this.state.wastegroup_update} style={{ width: '60%' }} color="primary" labelId="gennerate-group" id="wasteGroup" >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="General Waste">General Waste</MenuItem>
                                            <MenuItem value="Recycle Waste">Recycle Waste</MenuItem>
                                            <MenuItem value="Hazardous Waste">Hazardous Waste</MenuItem>
                                            <MenuItem value="Infectious Waste">Infectious Waste</MenuItem>
                                        </Select>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField onChange={this.SetWasteName} value={this.state.wastename_update} label="Waste Name" variant="outlined" id="wasteName" />
                                    </Grid>
                                </Grid>

                                {/* 4th Row */}
                                <Grid container spacing={0} style={{ paddingTop: 'calc(3%)' }}>
                                    <Grid item xs={4}>
                                        <TextField onChange={this.SetTotalWaight}  value={this.state.totalweight_update} style={{ marginLeft: '30px' }} label="Total Weight" id="totalWeight" variant="outlined" />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField  onChange={this.SetConWeight} value={this.state.containerweight_update} label="Container Weight" variant="outlined" id="containerWeight" />
                                    </Grid>
                                    <Grid item xs={4}>
                                        <TextField value={this.state.netwaste_update} disabled="true" label="Net Waste Weight" variant="outlined" id="netWasteWeight" />
                                    </Grid>
                                </Grid>

                                {/* 5th row */}
                                <Grid container spacing={0} style={{ paddingTop: 'calc(3%)' }}>

                                    <Grid item xs={3}>
                                        <InputLabel id="test" style={{ marginLeft: '30px' }} >Contractor Company</InputLabel>
                                        <Select
                                             value={this.state.contractor_update}
                                            labelId="test"
                                            id="test"
                                            onChange={this.SetContractor}
                                            style={{ width: '60%',marginLeft: '30px' }}
                                          
                                        >
                                            <MenuItem value="" >
                                                <em >None</em>
                                            </MenuItem>
                                            {this.state.data_com}
                                        </Select>
                                    </Grid>

                                    <Grid item xs={3}>
                                        <InputLabel id="containerType">Container Type</InputLabel>
                                        <Select  onChange={this.SetContainertype} value={this.state.containertype_update} id="containerType" style={{ width: '60%' }} color="primary" variant="standard" labelId="containerType" >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="ถุง Big Bag">ถุง Big Bag</MenuItem>
                                            <MenuItem value="ถังเหล็ก">ถังเหล็ก</MenuItem>
                                        </Select>
                                    </Grid>

                                    <Grid item xs={3}>
                                        <InputLabel id="demo-simple-select-helper-label">Waste of Phase</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-helper-label"
                                            id="phase"
                                            style={{ width: '150px' }}
                                            value={this.state.phase_update}
                                            onChange={this.SetPhase} 
                                        //onChange={this.SetWastePhase}
                                        >
                                            <MenuItem value=""><em>None</em></MenuItem>
                                            <MenuItem value="Phase 1">Phase 1</MenuItem>
                                            <MenuItem value="Phase 2">Phase 2</MenuItem>
                                            <MenuItem value="Phase 3">Phase 3</MenuItem>
                                            {/* <MenuItem value={90}><div style={{ marginLeft: '35%' }}><AddCircleIcon fontSize="large" style={{ color: green[500] }} /></div></MenuItem> */}
                                        </Select>
                                    </Grid>

                                    <Grid item xs={3}>
                                        <ButtonGroup style={{ padding: '15px' }} size="small" color="primary" aria-label="outlined secondary button group">
                                            <Button onClick={this.openCamera}>
                                                <IconButton color="primary" aria-label="upload picture" component="span" >
                                                    <CameraAlt />
                                                </IconButton>
                                            </Button>
                                            <Button onClick={this.uploadFileOnlocal} >
                                                <input accept=".png,.jpg" id="file" type="file" onChange={this.onFileSelect}   multiple hidden />
                                                <IconButton color="primary" component="span">
                                                    <CloudUpload />
                                                </IconButton>
                                            </Button>
                                        </ButtonGroup>
                                    </Grid>
                                </Grid>

                            </Grid>
                        </DialogContent>
                        <DialogActions>
                            {/* <Button onClick={this.handleClose} color="primary">Disagree</Button> */}
                            <Button onClick={this.submit} color="primary">UPDATE</Button>
                        </DialogActions>
                    </Dialog>
                </div>
            </>
        )
    }
}

export default EditWaste