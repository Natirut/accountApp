import React from 'react';
import DialogContent from '@material-ui/core/DialogContent';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import Button from '@material-ui/core/Button';
import Axios from 'axios'
class Car extends React.Component{
    constructor(props) {
        super(props)
        this.state = {
            Carname: null,
            open: false,
            slide: null,
        }
        this.handleClose = this.handleClose.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.insertCar = this.insertCar.bind(this);
    }
    componentDidMount() {
        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        this.setState({ open: true, })
    }
    handleChange(event) {
        this.setState({
            Carname: event.target.value
        });
    }
    handleClose() {
        this.props.close();
      
    }
    async insertCar(){
        const car = {
            carType: this.state.Carname
        };
        // console.log(company)
       // let url = process.env.REACT_APP_ENDPOINT+"/fae-part/car"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/car`
        // console.log(this.state.name)
        try {
              Axios.post(url,  car )
                .then( async res => {
                    console.log(res.data)
                    await this.handleClose();
                    await this.props.get();
                })
        } catch (err) {
            console.log(err.stack)
        }
    }
    render() {
        return (
            <>
                <Dialog open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#BEEACB', color: '#005F7E' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleClose}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Add Disposal car</Typography>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>
                        <TextField
                            autoFocus
                            margin="dense"
                            id="name"
                            label="Car"
                            type="email"
                            fullWidth
                            value={this.state.Carname}
                            onChange={this.handleChange}
                        />
                        <Button variant="contained" color="secondary" onClick={this.insertCar}>
                            ADD
                    </Button>
                    </DialogContent>
                </Dialog>
            </>
        )
    }
}
export default Car