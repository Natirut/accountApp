import React from 'react';
import { green } from '@material-ui/core/colors';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import CancelIcon from '@material-ui/icons/Cancel';
import AppBar from '@material-ui/core/AppBar';
import Dialog from '@material-ui/core/Dialog';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import moment from 'moment';
import { CameraAlt, CloudUpload, Today } from '@material-ui/icons';
import { Grid, TextField, Select, MenuItem, InputLabel, ButtonGroup, IconButton } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import DatePicker from '../components/datepicker/index.component';
import DialogRe from './dialog_Recycle';
import DialogCar from './dialog_Car';
import DialogType from './dialog_typeWast';
import Axios from 'axios';
import Confirm from '../components/confirm/index.component';
import Camera from '../components/captureImages/captureImages.component';
// import SuccessBar from '../components/successBar/index.component';
import SuccessBar from '../components/progress/index.component';

class Create extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            open: false,
            slide: null,
            pickerDate: false,
            pickedDate: '',
            open_DialogRe: false, //1,
            open_DialogCar: false, //1,
            open_DialogType: false, //1,
            data_com: null,
            data_car: null,
            data_type: null,
            currenDate: new Date(),
            time: "",
            confirm: false,
            successShow:false,
            id_delete: "",
            id_deleteCar: "",
            id_deleteType: "",
            boi: "",
            captureImage: false,
            filesSelected: null,
            cptType:"",
            generate:"",
            wasteGroup:"",
            contractor:"",
            container:"",
            wastephase:"",
            netwasteWeight:"",
            totalWeight:"",
            containerWeight:"",
            imagedata:"",
           
        };
        this.handleClose = this.handleClose.bind(this);
        this.onSelectedDate = this.onSelectedDate.bind(this);
        this.openDatePicker = this.openDatePicker.bind(this);
        this.submit = this.submit.bind(this)
        this.ShowAdd = this.ShowAdd.bind(this);//1
        this.close = this.close.bind(this);
        this.GetCompany = this.GetCompany.bind(this);
        this.GetCar = this.GetCar.bind(this);
        this.GetType = this.GetType.bind(this);

        this.getCurren = this.getCurren.bind(this);
        this.test = this.test.bind(this);
        this.ondelete = this.ondelete.bind(this);
        this.callBlack = this.callBlack.bind(this)
        this.ondelete = this.ondelete.bind(this);
        this.ondeleteCar = this.ondeleteCar.bind(this);
        this.ondeleteType = this.ondeleteType.bind(this);
        this.SetBoi = this.SetBoi.bind(this);
        this.SetCptType = this.SetCptType.bind(this);
        this.SetGenerate = this.SetGenerate.bind(this);
        this.SetWasteGroup = this.SetWasteGroup.bind(this);
        this.SetContainer = this.SetContainer.bind(this);
        this.SetWastePhase = this.SetWastePhase.bind(this);
        this.SetTotalWaight = this.SetTotalWaight.bind(this);
       // this.SetContainerWaight = this.SetContainerWaight.bind(this);
        this.SetNetWeight = this.SetNetWeight.bind(this);
    
        this.openCamera = this.openCamera.bind(this);
        this.onFileSelect = this.onFileSelect.bind(this);
    }
    async SetBoi(e) {
        await this.setState({ boi: e.target.value })
        console.log(this.state.boi)
    }
    async SetCptType(e) {
        await this.setState({ cptType: e.target.value })
        console.log(this.state.cptType)
    }
    async SetGenerate(e) {
        await this.setState({ generate: e.target.value })
        console.log(this.state.generate)
    }
    async SetWasteGroup(e) {
        await this.setState({ wasteGroup: e.target.value })
        console.log(this.state.wasteGroup)
    }
    async SetContainer(e) {
        await this.setState({ container: e.target.value })
        console.log(this.state.container)
    }
    async SetWastePhase(e) {
        await this.setState({ wastephase: e.target.value })
        console.log(this.state.wastephase)
    }
    onFileSelect(e) {
        this.setState({ filesSelected: e.target.files })
    }
    close(image) {
        console.log("close")
        if(image) {
            console.log("IMAGE: ", image)
            this.setState({imagedata:image})
            
        }
        this.setState({ open_DialogRe: false, });
        this.setState({ open_DialogCar: false, });
        this.setState({ open_DialogType: false, });
        this.setState({ captureImage: false, })
    }
    openCamera() {
        this.setState({ captureImage: true })
    }
    handleClose() {
        this.setState({ open: false, })
        this.props.close();
    }
 

    openDatePicker() {
        this.setState({ pickerDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ pickedDate: date.selectedDate })
        }
        this.setState({ pickerDate: false, })
    }
    SetTotalWaight(event){
       // console.log(e.target.value)
       this.setState({
           totalWeight:event.target.value,
           netwasteWeight: (parseFloat(event.target.value) - parseFloat(this.state.containerWeight)).toFixed(3).toString(),
        })
      // console.log(this.state.totalWeight)

    }
 
    SetNetWeight(event) {
        this.setState({
            containerWeight: event.target.value,
            netwasteWeight: (parseFloat(this.state.totalWeight) - parseFloat(event.target.value)).toFixed(3).toString(),
        });
    }
    async submit() {
        try { 
            // console.log(document.getElementById('date').value)
            // console.log(document.getElementById('time').value)
            // console.log(this.state.wastephase)
            // console.log(this.state.boi)
            // console.log(this.state.cptType)
            // console.log(document.getElementById('lotNo').value)
            // console.log(document.getElementById('companyApprove').value)
            // console.log(this.state.generate)
            // console.log(this.state.wasteGroup)
            // console.log(document.getElementById('wasteName').value)
            // console.log(document.getElementById('totalWeight').value)
            // console.log(document.getElementById('containerWeight').value)
            // console.log( this.state.container)
            // console.log(this.state.netwasteWeight)
            // console.log(this.state.contractor)


            let formData = new FormData();

            formData.append('date', document.getElementById('date').value);
            formData.append('time', document.getElementById('time').value);
            formData.append('phase', this.state.wastephase);
            formData.append('typeBoi', this.state.boi);
            formData.append('cptType', this.state.cptType);
            formData.append('lotNo', document.getElementById('lotNo').value);
            formData.append('companyApprove', document.getElementById('companyApprove').value);
            formData.append('gennerateGroup', this.state.generate);
            formData.append('wasteGroup', this.state.wasteGroup);
            formData.append('wasteName', document.getElementById('wasteName').value);
            formData.append('totalWeight', this.state.totalWeight);
            formData.append('containerWeight', this.state.containerWeight);
            formData.append('containerType', this.state.container);
            formData.append('netWasteWeight', this.state.netwasteWeight);
            formData.append('wasteContractor', this.state.contractor);
            
            for (const item of this.state.imagedata) {
                 formData.append('imageCapture', item);
            }
           
            // formData.append('files', '');
            
            for (const item of this.state.filesSelected) {
                formData.append('files', item);
            }
           
           

            const instance = Axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { 
                    'Content-Type': 'multipart/form-data', accept: 'text/plain', 
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            const response = await instance.post(`/fae-part/waste`, formData);

            console.log(response)
            this.setState({ successShow: true, });
            setTimeout(() => {
                 this.handleClose()
           }, 500);
          // await this.handleClose()
        } catch (err) {
            console.log(err.stack)
        }
    }
    async ShowAdd(e) {//1
        console.log(e.target.value);
        await this.setState({ contractor: e.target.value })
        console.log(this.state.contractor)
        if (e.target.value === 70) {
            await this.setState({ open_DialogRe: true })
            console.log("Ready Add")
        }
    }
    componentDidMount() {
        // this.setState({showbutton: <AddCircleIcon fontSize="large" style={{ color: green[500] }} / >})
        this.GetCompany()
        // this.GetCar()
        // this.GetType()

        this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });

        this.setState({ open: true, })

        if (this.props.data) {
            console.log('Data for edit');
        }
    }
    ondelete(id) {
        // alert(id)
        this.setState({ confirm: true, })
        this.setState({ id_delete: id, })
    }
    ondeleteCar(id) {
        this.setState({ confirm: true, })
        this.setState({ id_deleteCar: id, })
    }
    ondeleteType(id) {
        this.setState({ confirm: true, })
        this.setState({ id_deleteType: id, })
    }
    GetCompany() {
        //  let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company`
        try {
            Axios.get(url,{ headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } } )
                .then(res => {
                    this.setState({
                        data_com: res.data.data.map((item) => (
                            <MenuItem value={item.companyName}>{item.companyName} </MenuItem>
                        ))
                    });
                    // console.log(res.data)

                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    GetCar() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/car"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/car`
        try {
            Axios.get(url,{ headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } } )
                .then(res => {
                    this.setState({
                        data_car: res.data.data.map((item) => (
                            <MenuItem value={item.carType}><CancelIcon style={{ paddingRight: '4%' }} color="secondary" onClick={() => this.ondeleteCar(item._id)} />{item.carType}</MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    GetType() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/wasteType"
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteType`
        try {
            Axios.get(url)
                .then(res => {
                    this.setState({
                        data_type: res.data.data.map((item) => (
                            <MenuItem value={item.typeName}><CancelIcon style={{ paddingRight: '4%' }} color="secondary" onClick={() => this.ondeleteType(item._id)} />{item.typeName}</MenuItem>
                        ))
                    });
                })
        } catch (err) {
            console.log(err.response)
        }
        // return this.data_com
    }
    uploadFileOnlocal(){
        document.getElementById('file').click();
    }
    getCurren() {
        let datee
        let timee
        datee = moment(this.state.currenDate).format('YYYY/MM/DD')
        timee = moment(this.state.currenDate).format('HH:mm')
        this.setState({ pickedDate: datee })
        this.setState({ time: timee })
        console.log(datee)
        console.log(timee)

    }
    test(e) {
        console.log(e.target.value)
        this.setState({ time: e.target.value })
    }

    truedelete() {
        // let url = process.env.REACT_APP_ENDPOINT + "/fae-part/company/"+id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/company/${this.state.id_delete}`
        try {
            Axios.delete(url)
                .then(res => {
                    console.log(res.data)
                    this.GetCompany()
                })
        } catch (err) {
            console.log(err.response)
        }
    }
    truedeleteCar() {
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/car/${this.state.id_deleteCar}`
        try {
            Axios.delete(url)
                .then(res => {
                    console.log(res.data)
                    this.GetCar()
                })
        } catch (err) {
            console.log(err.response)
        }
    }
    truedeleteType() {
        //let url = process.env.REACT_APP_ENDPOINT + "/fae-part/wasteType/"+id
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/wasteType/${this.state.id_deleteType}`
        try {
            Axios.delete(url)
                .then(res => {
                    console.log(res.data)
                    this.GetType()
                })
        } catch (err) {
            console.log(err.response)
        }
    }
    callBlack(x) {
        this.setState({ confirm: false, })
        if (x === true) {
            this.truedelete()
            this.truedeleteCar()
            this.truedeleteType()
        }
    }

    render() {
        let datepicker;
        if (this.state.pickerDate === true) {
            datepicker = <DatePicker callBackClose={this.onSelectedDate} />
        }
        let Dialog_re;//1
        if (this.state.open_DialogRe === true) {
            Dialog_re = <DialogRe close={this.close} get={this.GetCompany} />
        }
        let Dialog_car;//1
        if (this.state.open_DialogCar === true) {
            Dialog_car = <DialogCar close={this.close} get={this.GetCar} />
        }
        let Dialog_type;//1
        if (this.state.open_DialogType === true) {
            Dialog_type = <DialogType close={this.close} get={this.GetType} />
        }
        let confirm;

        if (this.state.confirm === true) {
            confirm = <Confirm content={{ header: 'Confirm deleting', description: 'Delete this row from selection form.' }} confirmed={this.callBlack} />
        }

        let camera;
        if (this.state.captureImage === true) {
            camera = <Camera close={this.close} />
        }
        let success;
        if(this.state.successShow === true){
            success = <SuccessBar />
        }
        return (
            <>
           
                {confirm}{camera}{Dialog_re}{Dialog_car}{Dialog_type}{datepicker}
                <Dialog fullScreen open={this.state.open} onClose={this.handleClose} TransitionComponent={this.state.slide}>
                    <AppBar style={{ position: 'relative', backgroundColor: '#f6def6', color: '#424874' }}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" onClick={this.handleClose}>
                                <CloseIcon />
                            </IconButton>
                            <Typography variant="h6">Create Recycle Waste</Typography>
                        </Toolbar>
                    </AppBar>
                    {success}
                    <Grid container style={{ paddingLeft: 'calc(8%)' }}>
                        {/* first row */}
                        <Grid container style={{ paddingTop: 'calc(2%)' }}>
                            <Grid item xs={4}>
                                <InputLabel id="demo-simple-select-helper-label">Type of BOI/Non-BOI</InputLabel>
                                <Select
                                    labelId="demo-simple-select-helper-label"
                                    id="typeBoi"
                                    style={{ width: '150px' }}
                                    onChange={this.SetBoi}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value={true}>BOI</MenuItem>
                                    <MenuItem value={false}>NON-BOI</MenuItem>
                                    {/* <MenuItem value={80}><div style={{ marginLeft: '35%' }}><AddCircleIcon fontSize="large" style={{ color: green[500] }} /></div></MenuItem> */}
                                </Select>
                            </Grid>

                            <Grid item xs={4}>
                                <TextField id="date" label="Move Out Date" variant="outlined" value={this.state.pickedDate} onClick={this.openDatePicker} />
                            </Grid>

                            <Grid item xs={4}>
                                <TextField onChange={this.test} style={{ width: '180px' }} id="time" type="time" label="Move Out Time" variant="outlined" value={this.state.time} />
                                <Today onClick={this.getCurren} style={{ color: '#00b300', position: 'absolute' }} />
                            </Grid>
                        </Grid>


                        {/* second row */}
                        <Grid container style={{ paddingTop: 'calc(2%)' }}>
                            <Grid item xs={4}>
                                <InputLabel id="select-cpt-type">CPT Type</InputLabel>
                                <Select style={{ width: '60%' }} label="CPT Type" color="primary" labelId="select-cpt-type" id="cptType" onChange={this.SetCptType}>
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value="Fixed Asset">Fixed Asset</MenuItem>
                                    <MenuItem value="Non Fixed Asset">Non Fixed Asset</MenuItem>
                                    <MenuItem value="Company Approval">Company Approval</MenuItem>
                                    <MenuItem value="Parts">Parts</MenuItem>
                                    <MenuItem value="PMD">PMD</MenuItem>
                                    <MenuItem value="IMO">IMO</MenuItem>
                                    <MenuItem value="MSC">MCS</MenuItem>
                                    <MenuItem value="-">Other (Please Specific)</MenuItem>
                                </Select>
                            </Grid>
                            <Grid item xs={4} >
                                <TextField label="Lot No." variant="outlined" id="lotNo" />
                            </Grid>
                            <Grid item xs={4} >
                                <TextField label="Company Approval No." variant="outlined" id="companyApprove" />
                            </Grid>
                        </Grid>

                        {/* third Row */}
                        <Grid container spacing={0} style={{ paddingTop: 'calc(2%)' }}>
                            <Grid item xs={4}>
                                <InputLabel id="gennerate-group">Generate Group</InputLabel>
                                <Select style={{ width: '60%' }} color="primary" labelId="gennerate-group" id="gennerateGroup" onChange={this.SetGenerate}>
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value="Production">Production</MenuItem>
                                    <MenuItem value="Non-Production">Non-Production</MenuItem>
                                    <MenuItem value="-">Other (Please Specific)</MenuItem>
                                </Select>
                            </Grid>
                            <Grid item xs={4}>
                                <InputLabel id="gennerate-group">Waste Group</InputLabel>
                                <Select style={{ width: '60%' }} color="primary" labelId="gennerate-group" id="wasteGroup" onChange={this.SetWasteGroup}>
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value="General Waste">General Waste</MenuItem>
                                    <MenuItem value="Recycle Waste">Recycle Waste</MenuItem>
                                    <MenuItem value="Hazardous Waste">Hazardous Waste</MenuItem>
                                    <MenuItem value="Infectious Waste">Infectious Waste</MenuItem>
                                </Select>
                            </Grid>
                            <Grid item xs={4}>
                                <TextField label="Waste Name" variant="outlined" id="wasteName" />
                            </Grid>
                        </Grid>


                        {/* 4th Row */}
                        <Grid container spacing={0} style={{ paddingTop: 'calc(2%)' }}>
                            <Grid item xs={4}>
                                <TextField   onChange={this.SetTotalWaight} label="Total Weight" variant="outlined"/>
                            </Grid>
                            <Grid item xs={4}>
                                <TextField  onChange={this.SetNetWeight} label="Container Weight" variant="outlined" id="containerWeight" />
                            </Grid>
                            <Grid item xs={4}>
                                <TextField value={this.state.netwasteWeight} disabled="true"  label="Net Waste Weight" variant="outlined" id="netWasteWeight" />
                            </Grid>
                        </Grid>

                        {/* 5th row */}
                        <Grid container spacing={0} style={{ paddingTop: 'calc(2%)' }}>

                            <Grid item xs={3}>
                                <InputLabel id="disposalCompany">Contractor Company</InputLabel>
                                <Select
                                    labelId="disposalCompany"
                                    id="wasteContractor"
                                    onChange={this.ShowAdd}
                                    style={{ width: '60%' }}
                                >
                                    <MenuItem value="" >
                                        <em >None</em>
                                    </MenuItem>
                                    {this.state.data_com}
                                    <MenuItem value={70}><div style={{ marginLeft: '45%' }}>
                                        <AddCircleIcon fontSize="large" style={{ color: green[500] }} />
                                    </div></MenuItem>
                                </Select>
                            </Grid>

                            <Grid item xs={3}>
                                <InputLabel id="containerType">Container Type</InputLabel>
                                <Select id="containerType" style={{ width: '60%' }} color="primary" variant="standard" labelId="containerType" onChange={this.SetContainer}>
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value="ถุง Big Bag">ถุง Big Bag</MenuItem>
                                    <MenuItem value="ถังเหล็ก">ถังเหล็ก</MenuItem>
                                </Select>
                            </Grid>

                            <Grid item xs={3}>
                                <InputLabel id="demo-simple-select-helper-label">Waste of Phase</InputLabel>
                                <Select
                                    labelId="demo-simple-select-helper-label"
                                    id="phase"
                                    style={{ width: '150px' }}
                                  onChange={this.SetWastePhase}
                                >
                                    <MenuItem value=""><em>None</em></MenuItem>
                                    <MenuItem value="Phase 1">Phase 1</MenuItem>
                                    <MenuItem value="Phase 2">Phase 2</MenuItem>
                                    <MenuItem value="Phase 3">Phase 3</MenuItem>
                                    {/* <MenuItem value={90}><div style={{ marginLeft: '35%' }}><AddCircleIcon fontSize="large" style={{ color: green[500] }} /></div></MenuItem> */}
                                </Select>
                            </Grid>

                            <Grid item xs={3}>
                                <ButtonGroup style={{ padding: '15px' }} size="small" color="primary" aria-label="outlined secondary button group">
                                    <Button >
                                        <IconButton color="primary" aria-label="upload picture" component="span" onClick={this.openCamera}>
                                            <CameraAlt />
                                        </IconButton>
                                    </Button>
                                    <Button onClick={this.uploadFileOnlocal}>
                                        <input accept=".png,.jpg" id="file" type="file" onChange={this.onFileSelect} multiple hidden />
                                        <IconButton color="primary" component="span">
                                            <CloudUpload />
                                        </IconButton>
                                    </Button>
                                </ButtonGroup>
                            </Grid>
                        </Grid>

                        <Grid container spacing={0}>
                            <Grid item xs={12} style={{ marginTop: '20px', }}>
                                {/* <center> */}
                                <Button variant="contained" color="primary" onClick={this.submit}>Confirm</Button>
                                <Button variant="contained" color="secondary" onClick={this.handleClose} style={{ marginLeft: '10px' }}>cancle</Button>
                                {/* </center> */}
                            </Grid>
                        </Grid>
                    </Grid>  
                </Dialog>
            </>
        );
    }
}

export default Create;