import React from 'react';
import { Pie } from 'react-chartjs-2';

export default class pieChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: null,
      text: props.data.text,
    }
  }
  componentDidMount() {

    const obj = {};

    const labels = []; const data = []; const backgroundColor = [];
    for (const item of this.props.data.labels) {
      labels.push(item)
    }

    for (let i = 0; i < this.props.data.datasets[0].data.length; i += 1) {
      data.push(parseFloat(this.props.data.datasets[0].data[i]));
      backgroundColor.push(this.props.data.datasets[0].backgroundColor[i])
    }
    obj.labels = labels;
    obj.datasets = [
      { backgroundColor, data, }
    ]
    this.setState({ data: obj })
  }
  render() {
    return (
      <Pie
        data={this.state.data}
        options={{
          title: {
            display: true,
            text: this.state.text,
            fontSize: 20
          },
          legend: {
            display: true,
            position: 'right'
          }
        }}
      />
    );
  }
}