

import React from 'react';

import './style.css'

import Grid from '@material-ui/core/Grid';

class Footer extends React.Component {

    render() {
        return (
            <>
                <footer className="footer">
                    <Grid container spacing={0}>
                        <Grid item xs={4}>
                            <center>
                                @Power by ReactJS
                        </center>
                        </Grid>
                        <Grid item xs={4}>
                            <center>
                                Create By @ICD
                        </center>
                        </Grid>
                        <Grid item xs={4}>
                            <center>
                                Contact 5211 (Au)
                        </center>
                        </Grid>
                    </Grid>
                </footer>
            </>
        )
    }
}


export default Footer;