const mongoose = require('mongoose');



const userProduct = new mongoose.Schema({
    product_name:String,
    product_price:String 
});

// const userProduct = new mongoose.Schema({
//     product_name: {
//         type: String,
//         required: true,
//     },
//     product_type: {
//         type: String,
//         required: true,
//     },
// });

module.exports = mongoose.model('products', userProduct);
