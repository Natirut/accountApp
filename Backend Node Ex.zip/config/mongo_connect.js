const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.mongoconnect,
    { useNewUrlParser: true, useUnifiedTopology: true }, (err) => {
        if (err) {
            console.log('ERROR: ', err)
        } else {
            console.log('Connect to mongoDB success')
        }
    });