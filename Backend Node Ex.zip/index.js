const express = require('express')
require('./config/mongo_connect')
const app = express()
const cors = require('cors')
app.use(cors())
const router = require('./routes/index.route')
app.use(express.json())
app.use('/', router);

module.exports = app;
app.listen(3000)
