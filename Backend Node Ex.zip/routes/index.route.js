const express = require('express');
const app = express();
const product = require('./product.route')

app.use('/product',product)

module.exports = app;