const express = require('express')
const router = express.Router();
const productController = require('../controllers/product.controller')

  router.route('/product')
  .get(productController.getproduct);


  router.route('/product/:id')
  .get(productController.getproductby_id);

  router.route('/product')
  .post(productController.insertproduct)

  router.route('/product/:id')
  .delete(productController.delete)

  router.route('/product/:id')
  .put(productController.updateproduct);

  // router.route('/')
  // .get(productController.getproduct);

  module.exports = router;

