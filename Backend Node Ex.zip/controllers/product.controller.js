require('dotenv').config()
const { isValidObjectId } = require('mongoose')
const product_model = require('../models/product.model')

const products = [
  {
    id: '1001',
    name: 'Node.js for Beginners',
    category: 'Node',
    price: 990
  },
  {
    id: '1002',
    name: 'React 101',
    category: 'React',
    price: 3990
  },
  {
    id: '1003',
    name: 'Getting started with MongoDB',
    category: 'MongoDB',
    price: 1990
  }
]

exports.getproduct =  async (req, res) => {
  // console.log(process.env.mongoconnect) // log ข้อมูล env 
  try{
     const data = await product_model.find({})
       res.json(data)  
  }catch(err){
    console.log(err)
  }
}// get

exports.getproductby_id = async (req,res) =>{
  const {id} = req.params
  try{
    const data = await product_model.find({product_price:id})
     res.json(data)
  }catch(err){
    console.log(err)
  }
}//get by id

exports.insertproduct = async (req,res) => {
  const body = req.body
  try{
    // const data =  await product_model.create(body)
    const data =  await product_model.insertMany([body])
     res.json(data)
  }catch(err){
      console.log(err)
  }
}// insert

exports.updateproduct = async (req,res) => {
  const {id} = req.params
  const body = req.body
  try{
    const data = await product_model.updateOne(
      {_id:id},
      {$set:body}
    )
    res.json(data)
  }catch(err){
    console.log(err)
  }
 console.log("update")
}// update

 exports.delete = async (req,res) => {
    const {id} = req.params
    try{
      const data = await product_model.deleteOne({"_id":id})
      res.json(data)
    }catch(err){
      console.log(err)
    }
   
 } //delete

// exports.getproductby_id = (req, res, next) => {
//   console.log("getproductby_id");
//   const { id } = req.params
//   console.log("ID: ", id);
//   const result = products.find(x => x.id === id)
//   console.log(result)
//   res.json(result)
// }

// exports.insertproduct = (req, res) => {
//   const payload = req.body
//   res.json(payload)
// }

// exports.delete = (req, res) =>{
//   const {id} = req.params
//   res.json({id})
// }





