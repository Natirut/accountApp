
import { combineReducers } from 'redux';

import counters from './counter';

export default combineReducers({
    counters
})
