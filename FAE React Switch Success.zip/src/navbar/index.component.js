/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import './style.css';
import FormControl from '@material-ui/core/FormControl';
import { InputLabel } from '@material-ui/core';
import Select from '@material-ui/core/Select';
import ReactDom from 'react-dom';
import QRScanner from '../pages/components/qrcodeReader/index.component';
import Atp from '../App'
import PageSelecter from '../pages/index.component';
import MenuItem from '@material-ui/core/MenuItem';

import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import LinearScaleIcon from '@material-ui/icons/LinearScale';

import Register from '../pages/Register/index.component';

import { Provider } from 'react-redux';
import store from '../redux/store';

class NavBar extends React.Component {
  constructor() {
    super();

    this.state = {
      openScanner: false,
      cssTab3: {},
      show: false,
      tax_invoice: null,
      fae_menu: null,
      sub_menu: null,
      sub_menuRequester: null,
      anchorEl: null,
      openRegister: false,
    }
    this.close = this.close.bind(this);
    this.openScanner = this.openScanner.bind(this);
    this.summary = this.summary.bind(this);
    this.recyclegarbage = this.recyclegarbage.bind(this);
    // this.disposalWaste = this.disposalWaste.bind(this);
    this.home = this.home.bind(this);
    this.manage = this.manage.bind(this);
    this.login = this.login.bind(this);
    this.register = this.register.bind(this);
    this.logout = this.logout.bind(this);
    // this.Routefae = this.Routefae.bind(this);
    this.history = this.history.bind(this);
    this.showmenu = this.showmenu.bind(this);
    this.prepared = this.prepared.bind(this);
    this.optionClicked = this.optionClicked.bind(this);
    this.register = this.register.bind(this);
    this.requester = this.requester.bind(this);
  }
  login() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='login' />, document.getElementById('space'));
  }
  openScanner() {
    this.setState({ openScanner: true, anchorEl: null, })
  }
  faeCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='faeCheck' />, document.getElementById('space'));
  }
  faeApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='faeApprove' />, document.getElementById('space'));
  }

  register() {
    this.setState({ openRegister: true, anchorEl: null, })
  }

  async componentDidMount() {

    if (localStorage.getItem('dept') === 'FAE') {
      this.setState({
        tax_invoice:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }}>Invoice menu</InputLabel>
            <Select disableUnderline color="primary" >
              <MenuItem onClick={this.prepared} value="Requester Prepared">Prepare</MenuItem>
              <MenuItem onClick={this.requesterCheck} value="Requester Checked">Check</MenuItem>
              <MenuItem onClick={this.requesterApprove} value="Requester Approve">Approve</MenuItem>
              <MenuItem value="Tax Invoice Making Approve" onClick={this.makingApproveInvoice} >Making Approve</MenuItem>
            </Select>
          </FormControl>
      })
      this.setState({
        fae_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >Waste menu</InputLabel>
            <Select disableUnderline color="primary" >
              <MenuItem onClick={this.recyclegarbage} value="Fae Prepared">Prepare</MenuItem>
              <MenuItem onClick={this.faeCheck} value="Fae Checked">Check</MenuItem>
              <MenuItem onClick={this.faeApprove} value="Fae Approve">Approve</MenuItem>
              <MenuItem onClick={this.history} value="History">History</MenuItem>
            </Select>
          </FormControl>
      })
    } else if (localStorage.getItem('dept') === 'requester') {
      this.setState({
        fae_menu:
          <FormControl style={{ minWidth: 120, marginTop: '-0.6%', marginLeft: '0.7%', }}>
            <InputLabel style={{ fontSize: '17px', color: '#39375b' }} >Menu</InputLabel>
            <Select disableUnderline color="primary" >
              <MenuItem>Prepare</MenuItem>
              <MenuItem>Check</MenuItem>
              <MenuItem>Approve</MenuItem>
            </Select>
          </FormControl>
      })
    }
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='home' />, document.getElementById('space'));
  }
  home() {
    this.setState({
      cssTab3: {},
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='home' />, document.getElementById('space'));
  }
  summary() {
    this.setState({
      cssTab3: { backgroundColor: '#dedef0', borderRadius: '10px' },
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='summary' />, document.getElementById('space'));
  }
  requester() {
    this.setState({
      cssTab3: {},
    })
    this.setState({
      cssTab4: { backgroundColor: '#dedef0', borderRadius: '10px' },
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requester' />, document.getElementById('space'));
  }
  
  recyclegarbage() {
    this.setState({
      cssTab3: {},
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='recycle' />, document.getElementById('space'));
  }
  manage() {
    this.setState({
      cssTab3: {},
      anchorEl: null,
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='manage' />, document.getElementById('space'));
  }
  history() {
    this.setState({
      cssTab3: {},
    })
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='history' />, document.getElementById('space'));
  }
  // Routefae() {
  //   this.setState({
  //     cssTab3: {},
  //   })
  //   ReactDom.unmountComponentAtNode(document.getElementById('space'))
  //   ReactDom.render(<PageSelecter page='routefae' />, document.getElementById('space'));
  // }
  prepared() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='prepared' />, document.getElementById('space'));
  }
  requesterApprove() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requesterapprove' />, document.getElementById('space'));
  }
  requesterCheck() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='requestercheck' />, document.getElementById('space'));
  }
  makingApproveInvoice() {
    ReactDom.unmountComponentAtNode(document.getElementById('space'))
    ReactDom.render(<PageSelecter page='makingApprove' />, document.getElementById('space'));
  }

  close() {
    this.setState({ openScanner: false, openRegister: false, })
    this.setState({ anchorEl: null, })
  }
  showmenu() {
    this.setState({ show: true })
  }

  logout() {
    localStorage.clear();
    ReactDom.unmountComponentAtNode(document.getElementById('root'))
    ReactDom.render(<Atp />, document.getElementById('root'));
  }

  optionClicked(event) {
    this.setState({ anchorEl: event.currentTarget })
  }


  render() {
    let qrScanner;
    if (this.state.openScanner === true) {
      qrScanner = <QRScanner callBackClose={this.close} />
    }
    let register;
    if (this.state.openRegister === true) {
      register = <Register close={this.close} />
    }

    return (
      <>
        {register}
        <div className="nav">
          <input type="checkbox" id="nav-check" />
          <div className="nav-header">
            <div className="nav-title" onClick={this.home} style={this.state.cssHome}>
              <img src={`${process.env.REACT_APP_FILES_PATH}/icons/logo.png`} alt="logo"
                style={{ width: '47px', height: '44px', position: 'absolute', top: 'calc(20%)' }}
              />
            </div>
          </div>
          <div className="nav-btn">
            <label htmlFor="nav-check">
              <span></span>
              <span></span>
              <span></span>
            </label>
          </div>

          <div className="nav-links">
            {this.state.fae_menu}
            {/* DONT DELETE */}
            <a onClick={this.summary} style={this.state.cssTab3}>Summary Data</a>
            <a onClick={this.requester} style={this.state.cssTab3}>Requester</a>
            {/* DONT DELETE */}

            {(localStorage.getItem('dept') === 'FAE') ? this.state.tax_invoice : ''}


            {(localStorage.getItem('dept') === 'FAE') ? <>
              <Button onClick={this.optionClicked} style={{ position: 'absolute', right: 'calc(4%)', backgroundColor: '#006600', color: 'aliceblue' }}> Options </Button>
              <Menu
                id="simple-menu"
                anchorEl={this.state.anchorEl}
                keepMounted
                open={Boolean(this.state.anchorEl)}
                onClose={this.close}
              >
                <MenuItem onClick={this.manage}>Manage data</MenuItem>
                <MenuItem onClick={this.register}>Create user</MenuItem>
                <MenuItem onClick={this.openScanner}>Scaner QR</MenuItem>
                <MenuItem >
                  <LinearScaleIcon /><LinearScaleIcon /><LinearScaleIcon /><LinearScaleIcon />
                </MenuItem>
                <MenuItem onClick={this.logout} style={{ backgroundColor: '#660000', color: '#ffb3bf' }}>Logout</MenuItem>
              </Menu></>
              : 
              <><Button onClick={this.optionClicked} style={{ position: 'absolute', right: 'calc(4%)', backgroundColor: '#006600', color: 'aliceblue' }}> Options </Button>
              <Menu
                id="simple-menu"
                anchorEl={this.state.anchorEl}
                keepMounted
                open={Boolean(this.state.anchorEl)}
                onClose={this.close}
              >
                <MenuItem onClick={this.logout} style={{ backgroundColor: '#660000', color: '#ffb3bf' }}>Logout</MenuItem>
              </Menu></>}

          </div>
        </div>
        <React.StrictMode>
          <Provider store={store}>
            {qrScanner}
            <div id="space"></div>
          </Provider>
        </React.StrictMode>
      </>
    )
  }
}

export default NavBar;
