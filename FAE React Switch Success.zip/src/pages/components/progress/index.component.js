import React from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import LinearProgress from '@material-ui/core/LinearProgress';

const data = [
  {
    id: 283,
    completed: "100",
  },

];

class Progress extends React.Component {
  state = {
    playersData: [],
  };

  constructor(props) {
    super(props);
    this.state = {
      playersData: data.map(item => ({ ...item, completed: 0}))
    };
  };

  componentDidMount() {
    this.timer = setTimeout(() => this.progress(1), 100);
  }

  componentWillUnmount() {
    clearTimeout(this.timer);
  }

  progress(completion) {
    let done = 0;
    this.setState({
      playersData: data.map((item, i) => {
        const { completed: current } = this.state.playersData[i];
        const { completed: max } = item;
        if (current + completion >= max) {
          done += 1;
        }
        return {
          ...item,
          completed: Math.min(current + completion, max),
        };
      }),
    });
    if (done < data.length) {
      this.timer = setTimeout(() => this.progress(1), 100);
    }
  }

  render() {
    const { playersData } = this.state;
    return (
      <div>
        <Table>
          <TableBody>
            {playersData.map(({ id, completed }) =>
              <TableRow key={id}>
                <TableCell>
                  <LinearProgress mode="determinate" value={completed} />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    );
  }
}
export default Progress