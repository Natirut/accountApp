

import React, { forwardRef } from 'react';

import MaterialTable from 'material-table';

import { Clear, Check, FirstPage, LastPage, DeleteForever, Edit, Add } from '@material-ui/icons'
import SearchIcon from '@material-ui/icons/Search';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import SortOutlinedIcon from '@material-ui/icons/SortOutlined';
// import { Button } from '@material-ui/core';
// import Checkbox from '@material-ui/core/Checkbox';

// PROPS CONTEXT

// headers=[ {title: '', field: '' } ]
// data = [ { field: '', field: ''} ]
// title="string"
// onUpdate=FUNCTION
// onDelete=FUNCTION
// onInsert=FUNCTION
// onDetail=FUNCTION
// editable=false,

// PROPS CONTEXT


class DataTable extends React.Component {

  constructor(props) {
    super(props);
    this._isMounted = false;
    this.state = {
      headers: props.headers,
      title: props.title,
      data: props.data,
      editable: false,
    }

    this.update = this.update.bind(this);
    this.delete = this.delete.bind(this);
    this.insert = this.insert.bind(this);
  }

  componentDidMount() {
    if (!this.props.editable) {

    } else {
      this.setState({
        editable: {
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve) => {
              setTimeout(() => {
                this.update(newData);
                resolve();
              }, 600);
            }),
          onRowDelete: (newData, oldData) =>
            new Promise((resolve) => {
              setTimeout(() => {
                this.delete(newData);
                resolve();
              }, 600);
            }),
          onRowAdd: (newData, oldData) =>
            new Promise((resolve) => {
              setTimeout(() => {
                this.insert(newData);
                resolve();
              }, 600);
            }),
        }
      })
    }
  }
  update(newData) {
    console.log(newData);
    this.props.onUpdate(newData);
  }
  delete(newData) {
    this.props.onDelete(newData);
  }
  insert(newData) {
    this.props.onInsert(newData)
  }
  componentWillUnmount() {
    this._isMounted = true;
  }

  render() {
    return (
      <MaterialTable
        columns={this.state.headers}
        icons={{
          Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
          Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
          Search: forwardRef((props, ref) => <SearchIcon {...props} ref={ref} />),
          FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
          LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
          NextPage: forwardRef((props, ref) => <NavigateNextIcon {...props} ref={ref} />),
          PreviousPage: forwardRef((props, ref) => <ArrowBackIosIcon {...props} ref={ref} />),
          ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
          SortArrow: forwardRef((props, ref) => <SortOutlinedIcon {...props} ref={ref} />),
          Delete: forwardRef((props, ref) => <DeleteForever {...props} ref={ref} />),
          Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
          Add: forwardRef((props, ref) => <Add {...props} ref={ref} />),
        }}
        data={this.state.data}
        title={this.state.title}
        editable={this.state.editable}
        options={{
          rowStyle: { backgroundColor: 'rgb(158 158 158 / 15%)'},
      }}
      />
    )
  }
}

export default DataTable;
