
import React from 'react';

import Grid from '@material-ui/core/Grid';
import BarChart from '../../charts/barChart/index.component';
import PieChart from '../../charts/pieChart/index.component';

class SummaryDisposal extends React.Component {

    constructor() {
        super();

        this.state = {
            recycleUseprocess: null,
            garbage: null,
            danger: null,
        }
        this.genPieChartFormat = this.genPieChartFormat.bind(this);
    }
    componentDidMount() {
        this.genPieChartFormat(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#f6d186', '#a8d3da', '#424874'],
                    data: [15, 60, 95,]
                },
                text: 'Recycle from process',
            }, 'recycleUseprocess');

        this.genPieChartFormat(
            {
                labels: ['All'],
                datasets: {
                    backgroundColor: ['#424874'],
                    data: [250]
                },
                text: 'Garbage',
            }, 'garbage');
        this.genPieChartFormat(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#f6d186', '#a8d3da', '#424874'],
                    data: [85, 50, 15,]
                },
                text: 'Garbage',
            }, 'danger');
    }
    genPieChartFormat(value, state) {
        const data = {
            labels: value.labels,
            datasets: [
                {
                    backgroundColor: value.datasets.backgroundColor,
                    data: value.datasets.data,
                }
            ],
            text: value.text
        }
        const stateSet = {}
        stateSet[state] = data
        this.setState(stateSet)
    }
    render() {
        let recycleUseprocess; let garbage; let danger;

        if (this.state.recycleUseprocess !== null) {
            recycleUseprocess = <PieChart data={this.state.recycleUseprocess} />
        }
        if (this.state.garbage !== null) {
            garbage = <PieChart data={this.state.garbage} />
        }
        if (this.state.danger !== null) {
            danger = <PieChart data={this.state.danger} />
        }
        return (
            <>
                <Grid container spacing={1}>

                    <Grid item xs={6}>
                        <center>
                            <BarChart />
                        </center>
                    </Grid>

                    <Grid item xs={6}>
                        <center>
                            <BarChart />
                        </center>
                    </Grid>

                    <Grid item xs={4}>
                        {recycleUseprocess}
                    </Grid>
                    <Grid item xs={4}>
                        {garbage}
                    </Grid>
                    <Grid item xs={4}>
                        {danger}
                        <button style={
                            {
                                position: 'absolute', right: 'calc(3%)',
                                borderBottomColor: 'brown',
                                padding: '5px',
                                backgroundColor: 'darkgray'
                            }}>More detail</button>
                    </Grid>
                </Grid>
            </>
        )
    }
}

export default SummaryDisposal;