
import React from 'react';
import Grid from '@material-ui/core/Grid';
// import DataTable from '../components/datatable/index.component';
import PieChart from '../../charts/pieChart/index.component';
import Barchart from '../../charts/barChart/index.component';

// import Loading from '../../loading/index.component';
import './style.css';
import MoreDetail from './moreDetail.component';

class Summary extends React.Component {

    constructor() {
        super();

        this.state = {
            recycleUseprocess: null,
            recycleUnuseprocess: null,
            boi: null,
            noneBoi: null,
            showMore: false,
        }
        this.genrecycleUseprocess = this.genrecycleUseprocess.bind(this);
        this.close = this.close.bind(this);
        this.openMoreDetail = this.openMoreDetail.bind(this);
    }

    componentDidMount() {
        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                    backgroundColor: ['#c2ffc2', '#88b388', '#e7ffc2'],
                    data: [65, 59, 80,]
                },
                text: 'Recycle from process',
            }, 'recycleUseprocess');

        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                     backgroundColor: ['#ff99ff', '#9b6bb3', '#bb99ff'],
                    data: [20, 60, 70,]
                },
                text: 'Recycle unuse process',
            }, 'recycleUnuseprocess');

        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                     backgroundColor: ['#9999ff', '#6b7db3', '#99ffff'],
                    data: [40, 30, 30,]
                },
                text: 'BOI',
            }, 'boi');

        this.genrecycleUseprocess(
            {
                labels: ['PH-1', 'PH-2', 'Ph-3'],
                datasets: {
                     backgroundColor: ['#f3c6a5', '#aa8e74', '#f3b4a5'],
                    data: [25, 30, 80,]
                },
                text: 'NON-BOI',
            }, 'noneBoi');
    }
    openMoreDetail() {
        this.setState({ showMore: true, })
    }
    close() {
        this.setState({ showMore: false, })
    }
    genrecycleUseprocess(value, state) {
        const data = {
            labels: value.labels,
            datasets: [
                {
                    backgroundColor: value.datasets.backgroundColor,
                    data: value.datasets.data,
                }
            ],
            text: value.text
        }
        const stateSet = {}
        stateSet[state] = data
        this.setState(stateSet)
    }
    render() {
        let recycleUseprocess;

        if (this.state.recycleUseprocess !== null) {
            recycleUseprocess = <PieChart data={this.state.recycleUseprocess} />
        }
        let recycleUnuseprocess;

        if (this.state.recycleUnuseprocess !== null) {
            recycleUnuseprocess = <PieChart data={this.state.recycleUnuseprocess} />
        }
        let boi;

        if (this.state.boi !== null) {
            boi = <PieChart data={this.state.boi} />
        }
        let noneBoi;

        if (this.state.noneBoi !== null) {
            noneBoi = <PieChart data={this.state.noneBoi} />
        }
        let showMore;

        if (this.state.showMore === true) {
            showMore = <MoreDetail close={this.close} />
        }
        return (
            <>

                <Grid container spacing={0}>
                    <Grid item xs={6}>
                        <center>
                            <Barchart />
                        </center>
                    </Grid>
                    <Grid item xs={6}>
                        <Barchart />
                    </Grid>
                </Grid>

                <Grid container spacing={0} style={{ marginTop: '40px'}}>
                    <Grid item xs={3}>
                        {recycleUseprocess}
                    </Grid>
                    <Grid item xs={3}>
                        {recycleUnuseprocess}
                    </Grid>
                    <Grid item xs={3}>
                        {boi}
                    </Grid>
                    <Grid item xs={3}>
                        {noneBoi}
                        <button onClick={this.openMoreDetail} style={
                            {
                                position: 'absolute', right: 'calc(3%)',
                                borderBottomColor: 'brown',
                                padding: '5px',
                                backgroundColor: 'darkgray'
                            }}>More detail</button>
                    </Grid>
                </Grid>
                {showMore}

            </>
        )
    }
}

export default Summary;