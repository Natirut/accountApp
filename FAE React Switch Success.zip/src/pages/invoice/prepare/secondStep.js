

import React from 'react';
import InputAdornment from '@material-ui/core/InputAdornment';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
// import Button from '@material-ui/core/Button';
// import Dialog from '@material-ui/core/Dialog';
// import DialogActions from '@material-ui/core/DialogActions';
// import DialogContent from '@material-ui/core/DialogContent';
// import DialogContentText from '@material-ui/core/DialogContentText';
// import AppBar from '@material-ui/core/AppBar';
// import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import DataTable from '../../components/datatable/index.component'
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';

class SecondStep extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            columns: null,
            element: null,
            data: [],
            datamarkingOne: null,
            datainforOne: null,
            dataquotation: null,
            datafilterWasteName: [],
            subtotal: "",
            vat: 7,
            vatof: "",
            grandtotal: ""
        }
        this.rowData = this.rowData.bind(this);
        this.MapData = this.MapData.bind(this);
        this.Setvat = this.Setvat.bind(this);
        this.checknext = this.checknext.bind(this);
    }

    async checknext() {
        await  this.readytotal()
        await this.props.num(1)
        await   this.props.datastep2(this.state.datainforOne)
        await   this.props.vat(this.state.vat)
        await   this.props.vatof(this.state.vatof)
    }
      readytotal(){
        this.state.datainforOne.subTotal=this.state.subtotal.toString();
        this.state.datainforOne.grandTotal=this.state.grandtotal.toString();
        
      }
   async Setvat(e){
     await this.setState({vat:e.target.value})
     await this.setState({ vatof: this.state.vat * this.state.subtotal / 100 })
     await this.setState({ grandtotal: this.state.vatof + this.state.subtotal })
    }
    // async Insertinvoice() {
    //     this.state.datainforOne.subTotal=this.state.subtotal.toString();
    //     this.state.datainforOne.grandTotal=this.state.grandtotal.toString();
    //    // console.log("ffffff",this.state.datainforOne)
    //     try {
    //         const instance = Axios.create({
    //             baseURL: process.env.REACT_APP_ENDPOINT,
    //             headers: {
    //                 Authorization: `Bearer ${localStorage.getItem('token')}`,
    //                 'Content-Type': 'application/json',
    //             }
    //         })

    //         const response = await instance.post(`/fae-part/invoice/prepared`, this.state.datainforOne);

    //      //   console.log('data', response.data)
    //     } catch (err) {
    //         console.log(err.response.data)
    //     }
    // }
    async componentDidMount() {
         console.log("props1",this.props)
        // console.log("2 ma",this.props.backmaking)
        // console.log("2 info",this.props.backinformation)
        await this.setState({
            datamarkingOne: this.props.backmaking
        })
        await this.setState({
            datainforOne: this.props.backinformation
        })
        await this.setState({
            dataquotation: this.props.backquotation
        })
        await this.MapData()
        await this.rowData()
        await this.setState({ vatof: this.state.vat * this.state.subtotal / 100 })
        await this.setState({ grandtotal: this.state.vatof + this.state.subtotal })

        console.log("dataMarking", this.state.datamarkingOne)
        console.log("dataInfo", this.state.datainforOne)
        console.log("dataQu", this.state.dataquotation)
    }
    async MapData() {
        let tmp = []
        // var _ = require('lodash');
        // let data = _.filter(this.state.datamarkingOne,o=>o.containerWeight==="1");
        for (let i = 0; i < this.state.datamarkingOne.length; i++) {
            for (let j = 0; j < this.state.dataquotation.length; j++) {
                if (this.state.datamarkingOne[i].wasteName === this.state.dataquotation[j].wasteName) {
                    tmp.push({
                        wasteId: this.state.datamarkingOne[i]._id,
                        quotationNo: this.state.dataquotation[j].quotationNo,
                        wasteName: this.state.dataquotation[j].wasteName,
                        quantity: parseFloat(this.state.datamarkingOne[i].netWasteWeight),
                        amount: this.state.datamarkingOne[i].netWasteWeight * this.state.dataquotation[j].unitPrice,
                        unitPrice: this.state.dataquotation[j].unitPrice,
                    })
                }
            }
        }
        // this.setState({ datafilterWasteName: tmp })
        // console.log("tmp", this.state.datafilterWasteName)
        this.state.datainforOne.wasteItem = tmp

        // let found = this.state.datamarkingOne.find(element => element.wasteName === this.state.dataquotation.wasteName);
        // console.log("found",found)
       // console.log("alllllllllll", this.state.datainforOne)

    }
    // handleClose() {
    //     this.setState({ open: false, })
    // }
    rowData() {
        try {
            console.log("dataInfo", this.state.datainforOne)
            const column = [
                { field: 'quotationNo', title: 'NO', align: 'center' },
                { field: 'wasteName', title: 'Waste Name', align: 'center' },
                { field: 'quantity', title: 'Quanttty', align: 'center' },
                { field: 'unitPrice', title: 'Unit Price', align: 'center' },
                { field: 'amount', title: 'Amount', align: 'center' }
            ]
            const row = [];


            //  console.log(item)

            for (let i = 0; i < this.state.datainforOne.wasteItem.length; i++) {
                row.push(
                    {
                        quotationNo: this.state.datainforOne.wasteItem[i].quotationNo,
                        wasteName: this.state.datainforOne.wasteItem[i].wasteName,
                        quantity: this.state.datainforOne.wasteItem[i].quantity,
                        unitPrice: this.state.datainforOne.wasteItem[i].unitPrice,
                        amount: this.state.datainforOne.wasteItem[i].amount,
                    })
            }


            const sum = this.state.datainforOne.wasteItem.reduce((a, { amount }) => a + amount, 0);

            this.setState({ subtotal: sum })


            setTimeout(async () => {
                // console.log('getdata')
                await this.setState({ columns: column, data: row, })
                this.setState({ element: <DataTable title="Request Contents" headers={this.state.columns} data={this.state.data} /> })
            }, 500);
        } catch (err) {
            this.setState({ element: <DataTable title="Request Contents" headers={this.state.columns} data={[]} /> })
        }
    }

    render() {
        return (
            <>
            <Grid container>
                {/* Discription */}
                <Grid container>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={10}>
                        <Card variant="outlined">
                            <CardContent >
                                <Typography color="textSecondary" gutterBottom style={{ fontSize: '16px', fontWeight: 'bold' }}>
                                    Tax Invoice Making Request
                                </Typography>
                                <TextField
                                    id="discription"
                                    label="Discription."
                                    fullWidth='true'
                                    placeholder="Discription"
                                    multiline
                                    variant="filled"
                                    style={{ margin: '5px' }}
                                />
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>

                {/* Table */}
                <Grid container style={{ marginTop: "10px" }}>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={10}>
                        {this.state.element}
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>


                {/* FooterTable1 */}
                <Grid container style={{ marginTop: "10px" }}>

                    <Grid item xs={9}>

                    </Grid>
                    <Grid item xs={2}>
                        <Card variant="outlined">
                            <CardContent >
                                Sub Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  {this.state.subtotal}
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>


                {/* FooterTable2 */}
                <Grid container style={{ marginTop: "10px" }}>
                    <Grid item xs={9}>

                    </Grid>
                    <Grid item xs={2}>
                        <Card variant="outlined">
                            <CardContent >
                                VAT
                                <TextField
                                    value={this.state.vat}
                                    onChange={this.Setvat}
                                    InputProps={{
                                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                    }}
                                    variant="filled"
                                />
                                 &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {this.state.vatof}
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>



                {/* FooterTable3 */}
                <Grid container style={{ marginTop: "10px" }}>
                    <Grid item xs={9}>

                    </Grid>
                    <Grid item xs={2}>
                        <Card variant="outlined">
                            <CardContent >
                                Grand Total Amount   {this.state.grandtotal}
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid item xs={1}>
                        {/* <button onClick={this.Insertinvoice}>
                            Sentt
                        </button>
                        <button onclick={this.tt}>tt</button> */}
                    </Grid>
                </Grid>
                <Grid item xs={1}>
                        
                        </Grid>
                </Grid>

                <Grid container style={{margin:"7px"}} >
                   
                   <Grid item xs={2}>
                       <Button endIcon={<ArrowForwardIosIcon/>} variant="contained" color="primary" onClick={this.checknext}> Next</Button>
                   </Grid>
                   <Grid item xs={10}>

                   </Grid>

               </Grid>
            </>
        )
    }
}

export default SecondStep;
