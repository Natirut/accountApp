import React from 'react'
import GroupWorkIcon from '@material-ui/icons/GroupWork';
import LoupeIcon from '@material-ui/icons/Loupe';
import AvTimerIcon from '@material-ui/icons/AvTimer';
import Grid from '@material-ui/core/Grid';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import CardContent from '@material-ui/core/CardContent';
import DataTable from '../../components/datatable/index.component'
import SuccessBar from '../../components/successBar/index.component'
import Axios from 'axios';
class ThirdStep extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      datastep2: null,
      element: null,
      columns: null,
      data: [],
      boi: "",
      datamarkingOne: null,
      datainforOne: null,
      dataquotation: null,
      successShow:false
    }

    this.rowData = this.rowData.bind(this);
    this.MapData = this.MapData.bind(this);
    this.Insertinvoice = this.Insertinvoice.bind(this);
  }
  async Insertinvoice() {
   
    // console.log("ffffff",this.state.datainforOne)
    try {
      const instance = Axios.create({
        baseURL: process.env.REACT_APP_ENDPOINT,
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
        }
      })

      const response = await instance.post(`/fae-part/invoice/prepared`, this.state.datainforOne);

      console.log('data', response.data)
     
        
      this.setState({successShow:true})
        setTimeout(() => {
          this.setState({successShow:false})
        }, 1000);
        setTimeout(() => {
          this.props.numreset(0)
        }, 1150);
       //this.props.numreset(0)
     
     console.log("pass")

    } catch (err) {
      console.log("Nopass")
      this.props.numreset(0)
      console.log(err.response.data)
    }
  }
  async MapData() {
    let tmp = []
    // var _ = require('lodash');
    // let data = _.filter(this.state.datamarkingOne,o=>o.containerWeight==="1");
    for (let i = 0; i < this.state.datamarkingOne.length; i++) {
      for (let j = 0; j < this.state.dataquotation.length; j++) {
        if (this.state.datamarkingOne[i].wasteName === this.state.dataquotation[j].wasteName) {
          tmp.push({
            wasteId: this.state.datamarkingOne[i]._id,
            quotationNo: this.state.dataquotation[j].quotationNo,
            wasteName: this.state.dataquotation[j].wasteName,
            quantity: parseFloat(this.state.datamarkingOne[i].netWasteWeight),
            amount: this.state.datamarkingOne[i].netWasteWeight * this.state.dataquotation[j].unitPrice,
            unitPrice: this.state.dataquotation[j].unitPrice,
          })
        }
      }
    }
    // this.setState({ datafilterWasteName: tmp })
    // console.log("tmp", this.state.datafilterWasteName)
    this.state.datainforOne.wasteItem = tmp

    // let found = this.state.datamarkingOne.find(element => element.wasteName === this.state.dataquotation.wasteName);
    // console.log("found",found)
    console.log("alllllllllll", this.state.datainforOne)

  }
  rowData() {
    try {
      console.log("dataInfo", this.state.datainforOne)
      const column = [
        { field: 'quotationNo', title: 'NO', align: 'center' },
        { field: 'wasteName', title: 'Waste Name', align: 'center' },
        { field: 'quantity', title: 'Quanttty', align: 'center' },
        { field: 'unitPrice', title: 'Unit Price', align: 'center' },
        { field: 'amount', title: 'Amount', align: 'center' }
      ]
      const row = [];


      //  console.log(item)

      for (let i = 0; i < this.state.datainforOne.wasteItem.length; i++) {
        row.push(
          {
            quotationNo: this.state.datainforOne.wasteItem[i].quotationNo,
            wasteName: this.state.datainforOne.wasteItem[i].wasteName,
            quantity: this.state.datainforOne.wasteItem[i].quantity,
            unitPrice: this.state.datainforOne.wasteItem[i].unitPrice,
            amount: this.state.datainforOne.wasteItem[i].amount,
          })
      }

      setTimeout(async () => {
        // console.log('getdata')
        await this.setState({ columns: column, data: row, })
        this.setState({ element: <DataTable title="Request Contents" headers={this.state.columns} data={this.state.data} /> })
      }, 500);
    } catch (err) {
      this.setState({ element: <DataTable title="Request Contents" headers={this.state.columns} data={[]} /> })
    }
  }
  async componentDidMount() {
    //await  this.setState({datamarkingOne:this.props.backmaking});
    await this.setState({ datainforOne: this.props.backinformation });
    //await  this.setState({dataquotation:this.props.backquotation});
    //console.log("props3", this.props.backinformation)
    // console.log("dataMarking3", this.state.datamarkingOne)
    //     console.log("dataInfo3", this.state.datainforOne)
    //     console.log("dataQu3", this.state.dataquotation)

    // console.log("tt",this.state.datainforOne.contractEndDate)
    // await this.MapData()
    // console.log("composd",this.props.backdatastep2)
    // await this.setState({datastep2:this.props.backdatastep2})
    //  await this.MapData()
    await this.rowData()
    console.log("ready3", this.state.datainforOne)
  }
  render() {
    let subtotal = this.props.backinformation.subTotal
    let grandtotal = this.props.backinformation.grandTotal

    let success;
    if (this.state.successShow === true) {
        success = <SuccessBar />
    }
    return (
      <>{success}
        <Grid container style={{ textAlign: "center" }} >

          <Grid item xs={2}>

          </Grid>
          <Grid item xs={10}>
            <Grid container style={{ textAlign: "center" }}>
              <Grid item xs={3} style={{ margin: '7px' }}>
                <Card variant="outlined"  style={{boxShadow:'0 3px 3px 0 #04B431'}}>
                  <CardContent >
                    <Grid container>
                      <Grid item xs={3}>
                        <GroupWorkIcon  style={{ fill: "#04B431", fontSize: '50px',marginTop:'10px'  }} />
                      </Grid>
                      <Grid item xs={9}>
                        <div style={{ fontWeight: 'bold', }}>Sub Total</div> {subtotal}
                      </Grid>
                    </Grid>


                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={3} style={{ margin: '7px' }} >
                <Card variant="outlined"  style={{boxShadow:'0 3px 3px 0 #FE2EF7'}}>

                  <CardContent >
                  <Grid container>
                      <Grid item xs={3}>
                        <AvTimerIcon style={{ fill: "#FE2EF7", fontSize: '50px',marginTop:'10px'  }} />
                      </Grid>
                      <Grid item xs={9}>
                      <div style={{ fontWeight: 'bold' }}> Vat</div>  {this.props.backvat}% = {this.props.backvatof}
                      </Grid>
                    </Grid>
                   
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={3} style={{ margin: '7px' }}>
                <Card variant="outlined" style={{boxShadow:'0 3px 3px 0 #5F04B4'}}>
                  <CardContent >
                  <Grid container>
                      <Grid item xs={3}>
                        <LoupeIcon style={{ fill: "#5F04B4", fontSize: '50px',marginTop:'10px'  }} />
                      </Grid>
                      <Grid item xs={9}>
                      <div style={{ fontWeight: 'bold' }}> Grand Total</div>{grandtotal}
                      </Grid>
                    </Grid>
                    
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Grid>




        </Grid>


        <Grid container style={{ textAlign: "center" ,marginTop:'7px'}}>
          <Grid item xs={1}>

          </Grid>
          <Grid item xs={10}>
            <Card variant="outlined">
              <CardContent >
                <Grid container style={{ textAlign: "center" }}>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Type of BOI"
                      id="filled-size-small"
                      //defaultValue="Small"
                      // value={this.state.datainforOne.typeBoi}
                      value={this.props.backinformation.typeBoi}
                      variant="outlined"
                      // size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Lot No"
                      id="filled-size-small"
                      //  value={this.state.datainforOne.lotNo}
                      value={this.props.backinformation.lotNo}
                      variant="outlined"
                      //  size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Move Out Date"
                      id="filled-size-small"
                      //   value={this.state.datainforOne.moveOutDate}
                      value={this.props.backinformation.moveOutDate}
                      variant="outlined"
                      //   size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Waste Name"
                      id="filled-size-small"
                      // value={this.state.datainforOne.wasteName}
                      value={this.props.backinformation.wasteName}
                      variant="outlined"
                      //  size="small"
                      style={{ margin: '7px', color: 'black' }}
                    />
                  </Grid>
                </Grid>



                <Grid container style={{ textAlign: "center" }}>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Contract No"
                      id="filled-size-small"
                      //   value={this.state.datainforOne.contractNo}
                      value={this.props.backinformation.contractNo}
                      variant="outlined"
                      // size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Contract Start Date"
                      id="filled-size-small"
                      //  value={this.state.datainforOne.contractStartDate}
                      value={this.props.backinformation.contractStartDate}
                      variant="outlined"
                      // size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Contract End Date"
                      id="filled-size-small"
                      //  value={this.state.datainforOne.contractEndDate}
                      // value={this.props.backinformation.contractEndDate}
                      value={this.props.backinformation.contractEndDate}
                      variant="outlined"
                      //   size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Conterparty Name"
                      id="filled-size-small"
                      //  value={this.state.datainforOne.counterpartyName}
                      value={this.props.backinformation.counterpartyName}
                      variant="outlined"
                      //   size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>
                </Grid>



                <Grid container style={{ textAlign: "center" }}>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Phone No"
                      id="filled-size-small"
                      //  value={this.state.datainforOne.phoneNo}
                      value={this.props.backinformation.phoneNo}
                      variant="outlined"
                      //  size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Fax"
                      id="filled-size-small"
                      // value={this.state.datainforOne.fax}
                      value={this.props.backinformation.fax}
                      variant="outlined"
                      // size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Counterparty Address"
                      id="filled-size-small"
                      //  value={this.state.datainforOne.counterpartyAddress}
                      value={this.props.backinformation.counterpartyAddress}
                      variant="outlined"
                      //  size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Counterparty Charge"
                      id="filled-size-small"
                      value={this.props.backinformation.counterpartyChange}
                      //  value={this.state.datainforOne.counterpartyChange}
                      variant="outlined"
                      // size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>
                </Grid>





                <Grid container style={{ textAlign: "center" }}>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Counterparty harge Position"
                      id="filled-size-small"
                      // value={this.state.datainforOne.counterPartyChangePosition}
                      value={this.props.backinformation.counterPartyChangePosition}
                      variant="outlined"
                      //  size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>
                  <Grid item xs={3}>
                    <TextField
                      disabled
                      label="Invoice Date"
                      id="filled-size-small"
                      // value={this.state.datainforOne.invoiceDate}
                      value={this.props.backinformation.invoiceDate}
                      variant="outlined"
                      //  size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  {/* <Grid item xs={3}>
                  <TextField
                   disabled
                      label="Size"
                      id="filled-size-small"
                      value={this.state.datainforOne.counterPartyChangePosition}
                      variant="outlined"
                      size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid>

                  <Grid item xs={3}>
                  <TextField
                   disabled
                      label="Size"
                      id="filled-size-small"
                      defaultValue="Small"
                      variant="outlined"
                      size="small"
                      style={{ margin: '7px' }}
                    />
                  </Grid> */}
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        </Grid>



        {/* table */}
        <Grid container style={{ marginTop: '10px' }}>
          <Grid item xs={1}>

          </Grid>
          <Grid item xs={10}>
            {this.state.element}
          </Grid>
          <Grid item xs={1}>

          </Grid>
        </Grid>

        <Grid container style={{ margin: "7px" }} >

          <Grid item xs={2}>
            <Button onClick={this.Insertinvoice} startIcon={<CheckCircleIcon />} variant="contained" color="primary" >Finis</Button>
          </Grid>
          <Grid item xs={10}>

          </Grid>

        </Grid>

      </>
    )
  }
}
export default ThirdStep

