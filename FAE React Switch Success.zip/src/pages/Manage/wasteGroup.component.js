
import React, { Component } from 'react';

import Datatable from '../components/datatable/index.component';

import axios from 'axios';

class WasteGroup extends Component {
    constructor(props) {
        super(props);

        this.state = {
            header: [
                { title: 'Waste Group', field: 'groupName', headerStyle: { backgroundColor: 'rgb(255 152 0 / 38%)' } },
            ],
            rowData: [],
            element: null,
        };
        this.rowData = this.rowData.bind(this);
    }

    componentDidMount() {
        this.rowData();
    }
    delete() {

    }
    insert() {

    }

    update() {

    }

    async rowData() {
        try {

            this.setState({ element: '....' })
            const instance = axios.create({
                baseURL: process.env.REACT_APP_ENDPOINT,
                headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
            });

            const response = await instance.get(`/fae-part/wasteGroup`);

            console.log(response.data);
            this.setState({
                element: <Datatable
                    headers={this.state.header}
                    data={response.data.data}
                    title="Waste Group"
                    onDelete={this.delete}
                    onInsert={this.insert}
                    onUpdate={this.update}
                    editable={true}
                />
            })
            // console.log(response.data);
        } catch (error) {
            console.log(error.stack);
        }
    }

    render() {
        return (
            <>
                {this.state.element}
            </>
        );
    }
}

export default WasteGroup;