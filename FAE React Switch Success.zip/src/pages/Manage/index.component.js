import React from 'react';
import RecycleCom from '../Manage/recycleCompany'
import Quotation from './quotation.component';
import { Grid, IconButton } from '@material-ui/core';
import WasteName from './wastename.component';
import Zoom from '@material-ui/core/Zoom';

import WasteGroup from './wasteGroup.component';

import AddwasteGroup from './actions/wasteGroup/addWastegroup.component';
import AddCompany from './actions/company/addCompany.component';
import AddWastename from './actions/wasteName/addWasteName.component';

class Manage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            dialog_company: false,
            createWasteGroup: false,
            createWasteName: false,
        }
        this.ShowDialogCompany = this.ShowDialogCompany.bind(this);
        this.cancle = this.cancle.bind(this);
        this.createWasteGroup = this.createWasteGroup.bind(this);
        this.createWasteName = this.createWasteName.bind(this)
    }

    ShowDialogCompany() {
        this.setState({ dialog_company: true })
        console.log("dia")
    }
    createWasteName() {
        this.setState({ createWasteName: true })
    }
    createWasteGroup() {
        this.setState({ createWasteGroup: true, })
    }
    async cancle() {
        await this.setState({ dialog_company: false, createWasteGroup: false, createWasteName: false,})
    }
    render() {
        let dialogcompyny; let wasteGroup; let wasteName;
        if (this.state.dialog_company === true) {
            dialogcompyny = <AddCompany cancle={this.cancle} />
        }
        if (this.state.createWasteGroup === true) {
            wasteGroup = <AddwasteGroup close={this.cancle}/>
        }
        if (this.state.createWasteName === true) {
            wasteName =  <AddWastename close={this.cancle} />
        }
        return (
            <>
           
                {dialogcompyny}{wasteGroup}{wasteName}
                <Grid container spacing={0} alignItems="center" justify="center" style={{ maxHeight: "50%", marginTop: 'calc(5%)' }}>
                    <Grid item xs={4} style={{ textAlign: 'center' }}>
                        <IconButton onClick={this.ShowDialogCompany}>
                            <img src={`${process.env.REACT_APP_FILES_PATH}/icons/company.png`} alt="company.png" width="50" height="50" />
                            <p style={{ fontSize: '14px' }}>Add company</p>
                        </IconButton>
                    </Grid>
                    <Grid item xs={4} style={{ textAlign: 'center' }}>
                        <IconButton onClick={this.createWasteName}>
                            <img src={`${process.env.REACT_APP_FILES_PATH}/icons/wastename.png`} alt="wastename.png" width="50" height="50" />
                            <p style={{ fontSize: '14px' }}>Add waste name</p>
                        </IconButton>
                    </Grid>
                    <Grid item xs={4} style={{ textAlign: 'center' }}>
                        <IconButton onClick={this.createWasteGroup}>
                            <img src={`${process.env.REACT_APP_FILES_PATH}/icons/wastegroup.png`} alt="wastegroup.png" width="50" height="50" />
                            <p style={{ fontSize: '14px' }}>Add waste group</p>
                        </IconButton>
                    </Grid>
                </Grid>


                <Grid container spacing={0} alignItems="center" justify="center" style={{ maxHeight: "50%", marginTop: 'calc(3%)' }}>
                    <Zoom in={true}>
                        <Grid item xs={12} style={{ marginRight: '20px' }}>
                            <RecycleCom />
                        </Grid>
                    </Zoom>
                </Grid>

                <Grid container spacing={0} alignItems="center" justify="center" style={{ maxHeight: "50%", marginTop: 'calc(2%)' }}>
                    <Zoom in={true}>
                        <Grid item xs={12}>
                            <WasteName />
                        </Grid>
                    </Zoom>
                </Grid>

                <Grid container spacing={0} alignItems="center" justify="center" style={{ maxHeight: "50%", marginTop: 'calc(2%)' }}>
                    <Zoom in={true}>
                        <Grid item xs={12}>
                            <WasteGroup />
                        </Grid>
                    </Zoom>
                </Grid>

                <Grid container spacing={0} alignItems="center" justify="center" style={{ maxHeight: "50%", marginTop: 'calc(5%)' }}>
                    <Zoom in={true}>
                        <Grid item xs={12}>
                            <Quotation />
                        </Grid>
                    </Zoom>
                </Grid>

            </>
        )
    }
}
export default Manage
