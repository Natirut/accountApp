import React from 'react'
import Axios from 'axios';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import DatePicker from '../components/datepicker/index.component'
import MenuItem from '@material-ui/core/MenuItem';
import Fab from '@material-ui/core/Fab';
import FormatColorTextIcon from '@material-ui/icons/FormatColorText';
import FormatBoldIcon from '@material-ui/icons/FormatBold';
import Today from '@material-ui/icons/Today';
import moment from 'moment';
import Autocomplete from '@material-ui/lab/Autocomplete';
import FormControl from '@material-ui/core/FormControl';
import { Select, InputLabel } from '@material-ui/core';

// import SwipeableViews from 'react-swipeable-views';
import SwipeableViews from 'react-swipeable-views';
import Paper from '@material-ui/core/Paper';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

class RequesterInput extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            valueDate: '',
            dialogDate: false,
            time: '',
            data_deptdiv: null,
            // show_dept: null,
            data_div: null,
            show_div: null,
            data_dept: null,
            pageA: null,
            pageB: null,

            index: 0,
        }
        this.openDatePicker = this.openDatePicker.bind(this)
        this.onSelectedDate = this.onSelectedDate.bind(this)
        this.Settime = this.Settime.bind(this)
        this.SetDept = this.SetDept.bind(this)
        this.getCurren = this.getCurren.bind(this)
        this.ShowPageA = this.ShowPageA.bind(this)
        this.ShowPageA = this.ShowPageA.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.handleChangeIndex = this.handleChangeIndex.bind(this)

        // ShowPageA
    }
    // handleChangeIndex (index) {
    //     this.setState({ value:index })
    // }
    // handleChange(event, value) {
    //     this.setState({ value })
    // }
    handleChange = (event, value) => {
        this.setState({
            index: value,
        });
    };

    handleChangeIndex = index => {
        this.setState({
            index,
        });
    };

    getCurren() {
        let datee
        let timee
        datee = moment(this.state.currenDate).format('YYYY/MM/DD')
        timee = moment(this.state.currenDate).format('HH:mm')
        this.setState({ valueDate: datee })
        this.setState({ time: timee })


    }
    ShowPageB() {
        this.setState({
            pageB: <>
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Data Page B</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="phase"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Waste of Phase"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>
            </>
        })
    }
    ShowPageA() {
        this.setState({
            pageA: <>
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Waste of Phase</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="phase"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Waste of Phase"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Waste Name</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="wastename"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Waste Name"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Waste Group</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="wastegroup"
                                style={{ width: '170px' }}
                                // onChange={this.SetWastePhase}
                                label="Waste Group"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2} style={{ marginLeft: 'calc(3%)' }}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Contractor Company</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="contractor"
                                style={{ width: '170px' }}
                                // onChange={this.SetWastePhase}
                                label="Contractor Company"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Bindind Type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="bindind"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Bindind Type"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={3} >
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">CPT Maintype</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="cptMaintype"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="CPT Maintype"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2} >
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Waste type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="wastetype"
                                style={{ width: '170px' }}
                                // onChange={this.SetWastePhase}
                                label="Waste type"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={1}>
                    </Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Boi type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="boitype"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Boi type"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Parts Normal type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="partsnormal"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Parts Normal type"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={2}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Product type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="producttype"
                                style={{ width: '170px' }}
                                // onChange={this.SetWastePhase}
                                label="Product type"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={1}></Grid>
                    <Grid item xs={3}>
                        <TextField label="Lot No." style={{ width: '190px' }} variant="outlined" id="lotno" />
                    </Grid>
                    <Grid item xs={3}>
                        <TextField label="Company Approval No." style={{ width: '190px' }} variant="outlined" id="Companyapproval" />
                    </Grid>
                </Grid>
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={1}></Grid>
                    <Grid item xs={3}>
                        <FormControl variant="outlined" >
                            <InputLabel id="demo-simple-select-outlined-label">Container type</InputLabel>
                            <Select
                                labelId="demo-simple-select-outlined-label"
                                id="producttype"
                                style={{ width: '190px' }}
                                // onChange={this.SetWastePhase}
                                label="Container type"
                            >
                                <MenuItem value=""><em>None</em></MenuItem>
                                <MenuItem value="Phase 1">Phase 1</MenuItem>
                                <MenuItem value="Phase 2">Phase 2</MenuItem>
                                <MenuItem value="Phase 3">Phase 3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={3}>
                        <TextField label="Qty Of Container" style={{ width: '190px' }} variant="outlined" id="Qtycontainer" />
                    </Grid>
                    <Grid item xs={2}>
                        <TextField label="Weight per Container" style={{ width: '170px' }} variant="outlined" id="Weightper" />
                    </Grid>
                    <Grid item xs={2} style={{ marginLeft: 'calc(3%)' }}>
                        <TextField label="Total Weight" style={{ width: '170px' }} variant="outlined" id="totalweight" />
                    </Grid>
                </Grid>
            </>
        })
    }
    async SetDept(e, data) {
        if (data !== null) {
            // console.log("data",data.depT_ABB_NAME)
            await this.setState({ data_div: data.diV_NAME_WC })
            this.setState({ data_dept: data.depT_ABB_NAME })
            this.setState({
                show_div:
                    <TextField id="div" style={{ width: '170px' }} label="Div" variant="outlined" value={this.state.data_div} />
            })
        }
        // console.log("data", data.diV_NAME_WC)

        // await this.setState({ data_div: this.state.data_dept.find(x => x.depT_ABB_NAME === data.diV_NAME_WC) })

    }

    async componentDidMount() {
        await this.getDept()
        await this.ShowPageA()
        await this.ShowPageB()
    }
    async getDept() {
        let url = `${process.env.REACT_APP_ENDPOINT}/fae-part/service/dept`
        try {
            Axios.get(url, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
                .then(async res => {
                    console.log("data", res.data.data)
                    await this.setState({ data_deptdiv: res.data.data })
                    // this.setState({
                    //     show_dept: this.state.data_dept.map((item) => (
                    //         <MenuItem value={item.depT_ABB_NAME}>{item.depT_NAME}</MenuItem>
                    //     ))
                    // });
                })


        } catch (err) {
            console.log(err.response)
        }
    }
    Settime(e) {
        console.log(e.target.value)
        this.setState({ time: e.target.value })
    }
    openDatePicker() {
        this.setState({ dialogDate: true })
    }
    async onSelectedDate(date) {
        if (date !== false) {
            await this.setState({ valueDate: date.selectedDate })
        }
        this.setState({ dialogDate: false, })
    }
    render() {
        const { index } = this.state;
        let datepicker;
        if (this.state.dialogDate === true) {
            datepicker = <DatePicker callBackClose={this.onSelectedDate} />
        }
        let content_array = [this.state.pageA, this.state.pageB];
        return (
            <>
                {datepicker}
                <Grid container style={{ marginTop: 'calc(8%)' }}>
                    <Grid container>
                        <Grid item xs={1}>

                        </Grid>
                        <Grid item xs={3}>
                            <TextField id="date" style={{ width: '190px' }} label="Request Date" variant="outlined" value={this.state.valueDate} onClick={this.openDatePicker} />
                        </Grid>

                        <Grid item xs={3}>
                            <TextField onChange={this.Settime} style={{ width: '180px' }} id="time" type="time" label="Request Time" variant="outlined" value={this.state.time} />
                            <Today onClick={this.getCurren} style={{ color: '#00b300', position: 'absolute' }} />
                        </Grid>
                        <Grid item xs={2} >
                            <Autocomplete
                                id="combo-box-demo"
                                options={this.state.data_deptdiv}
                                getOptionLabel={(option) => option.depT_NAME}
                                style={{ width: 170 }}
                                onChange={(event, newValue) => {
                                    this.SetDept(event, newValue)
                                }}
                                renderInput={(params) => <TextField {...params} label="Dept" variant="outlined" />}
                            />
                        </Grid>
                        <Grid item xs={2} style={{ marginLeft: 'calc(3%)' }}>
                            {this.state.show_div}
                        </Grid>
                    </Grid>
                </Grid>
             
                {/* {this.state.pageA}
                {this.state.pageB} */}
                <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid container>
                        <Grid item xs={1}>

                        </Grid>
                        <Grid>
                        <Tabs value={index} fullWidth onChange={this.handleChange} style={{backgroundColor:'#fff'}}>
                            <Tab label="TAB A" />
                            <Tab label="TAB B" />
                        </Tabs>
                        </Grid>
                    </Grid>
                    
                    <Grid container>
                        <Grid item xs={12} >
                       
                       <SwipeableViews index={index} onChangeIndex={this.handleChangeIndex}>
                           {this.state.pageA}
                           {this.state.pageB}
                       </SwipeableViews>
                   </Grid>
                    </Grid>
                </Grid>
                {/* <div>
                   
                </div> */}

            </>
        )
    }
}
export default RequesterInput

