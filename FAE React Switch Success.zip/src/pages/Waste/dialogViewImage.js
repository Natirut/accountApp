import React from 'react'
import Dialog from '@material-ui/core/Dialog';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import Badge from '@material-ui/core/Badge';
import Grid from '@material-ui/core/Grid';
class DialogImage extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            open: false,
            slide: null,
            dataImage: ""
        }
        this.handleClose = this.handleClose.bind(this);
        this.readydata = this.readydata.bind(this);
    }

    handleClose() {
        this.props.close()
    }
    async componentDidMount() {
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
        // await this.readydata()

    }
    readydata() {
        console.log("di image", this.props.data.length)

        const tmp = []
        let file;
        for (let i = 0; i < this.props.data.length; i++) {
            let reader = new FileReader();
            file = this.props.data[i];

            reader.onload = (file) => {

                tmp.push(reader.result)
            }
            reader.readAsDataURL(file)
        }

        this.setState({ dataImage: tmp })
        console.log("immmm", this.state.dataImage)
    }
    render() {
        return (
            <>
                <div>
                    <Dialog
                        fullWidth="true"
                        maxWidth="md"
                        open={this.state.open}
                        TransitionComponent={this.state.slide}
                        onClose={this.handleClose}

                    >
                        <DialogTitle >View Image</DialogTitle>
                        <DialogContent  >
                            <Grid container>
                                <Grid
                                    item xs={9}
                                    style={{
                                        display: 'flex',
                                        flexWrap: 'wrap',
                                        justifyContent: 'space-around',
                                        overflow: 'hidden',
                                        // backgroundColor: 'skyblue'
                                    }}
                                >
                                    <GridList cellHeight={170} style={{
                                        width: 500,
                                        height: 450
                                    }} >
                                        {this.props.data.map((item) => (
                                            <GridListTile key={item}  >
                                                <center>
                                                    <img src={item} alt="test" style={{ width: '200px', height: '200px' }} />
                                                </center>

                                                <GridListTileBar
                                                    style={{
                                                         background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)'
                                                    }}
                                                    // title={tile.title}
                                                // classes={{
                                                //     root: classes.titleBar,
                                                //     title: classes.title,
                                                // }}
                                                />
                                            </GridListTile>
                                        ))}
                                    </GridList>



                                </Grid>
                                <Grid item xs={3} style={{marginTop:'20px'}}>
                                    <Grid container >
                                    <Badge badgeContent={this.props.sheet[1]} color="secondary" style={{margin:'20px'}}>
                                        <img src="http://cptsvs52t/waste/icons/excel.png" alt="test" style={{ width: '50px', height: '50px', }} />
                                     </Badge> 
                                     <Badge badgeContent={this.props.sheet[2]} color="secondary" style={{margin:'20px'}}>
                                        <img src="http://cptsvs52t/waste/icons/word.png" alt="test" style={{ width: '50px', height: '50px',}} />
                                        </Badge>
                                    </Grid>

                                    <Grid container >
                                    <Badge badgeContent={this.props.sheet[0]} color="secondary" style={{margin:'20px'}}>
                                        <img src="http://cptsvs52t/waste/icons/powerpoint.png" alt="test" style={{ width: '50px', height: '50px', }} />
                                     </Badge> 
                                     <Badge badgeContent={this.props.sheet[3]} color="secondary" style={{margin:'20px'}}>
                                        <img src="http://cptsvs52t/waste/icons/pdf.png" alt="test" style={{ width: '50px', height: '50px',}} />
                                        </Badge>
                                    </Grid>

                                    <Grid container >
                                     <Badge badgeContent={this.props.sheet[4]} color="secondary" style={{margin:'20px'}}>
                                        <img src="http://cptsvs52t/waste/icons/not.png" alt="test" style={{ width: '50px', height: '50px',}} />
                                        </Badge>
                                    </Grid>
                                </Grid>
                            </Grid>

                        </DialogContent>
                    </Dialog>
                </div>
            </>
        )
    }
}
export default DialogImage

