import React from 'react'
import ReactDom from 'react-dom';
import BottomNavigation from '@material-ui/core/BottomNavigation';
import BottomNavigationAction from '@material-ui/core/BottomNavigationAction';
import AllInboxIcon from '@material-ui/icons/AllInbox';
import DashboardIcon from '@material-ui/icons/Dashboard';
import DomainDisabledIcon from '@material-ui/icons/DomainDisabled';
import  Page from '../page/index.component';
class Buttom extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
        this.in = this.in.bind(this);
        // this.out = this.out.bind(this);
        // this.summary = this.summary.bind(this);
    }
    componentDidMount() {
      ReactDom.unmountComponentAtNode(document.getElementById('space'))
      ReactDom.render(<Page page='home' />, document.getElementById('space'));
    }
    in() {
        ReactDom.unmountComponentAtNode(document.getElementById('space'))
        ReactDom.render(<Page page='in' />, document.getElementById('space'));
      }
      out() {
        ReactDom.unmountComponentAtNode(document.getElementById('space'))
        ReactDom.render(<Page page='out' />, document.getElementById('space'));
      }
      summary() {
        ReactDom.unmountComponentAtNode(document.getElementById('space'))
        ReactDom.render(<Page page='summary' />, document.getElementById('space'));
      }
    render() {
        return (
            <>   
      <BottomNavigation showLabels value="recent" style={{backgroundColor:'#2abfc0'}}>
      {/* <BottomNavigation showLabels value="recent" style={{backgroundColor:'#2abfc0'}}> */}
      <BottomNavigationAction onClick={this.in} label="IN" value="recents" icon={<AllInboxIcon   style={{color:'white'}}/>} />
      <BottomNavigationAction onClick={this.out} label="OUT" value="favorites" icon={<DomainDisabledIcon style={{color:'white'}} />} />
      <BottomNavigationAction onClick={this.summary} label="SUMMARY" value="nearby" icon={<DashboardIcon style={{color:'white'}} />} />
    </BottomNavigation>
    <div id="space"></div>
            </>
        )
    }
}
export default Buttom

