import React from 'react'
import MUIDataTable from "mui-datatables";
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import EditIcon from '@material-ui/icons/Edit';
import IconButton from '@material-ui/core/IconButton';
import DialogEdit from './dialogedit';
// import Chip from '@material-ui/core/Chip'; 
class Summary extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
             dataParts:null,
             showtable:null,
             flag3:null,
             storebox:null,
             transbox:null,

             dialogEdit:false,
             dataEdit:null
        }
        this.getdataPats = this.getdataPats.bind(this)
        this.settable = this.settable.bind(this)
        this.CheckFlag3 = this.CheckFlag3.bind(this)
        this.OpenEdit = this.OpenEdit.bind(this)
        this.cancle = this.cancle.bind(this)
        this.Setnewtable = this.Setnewtable.bind(this)
    }
    cancle(){
        this.setState({dialogEdit:false})
    }
    async OpenEdit(data){
        await this.setState({dataEdit:data})
        await this.setState({dialogEdit:true})
       console.log(data)
    }
      CheckFlag3(){
          console.log(this.state.storebox)
          console.log(this.state.transbox)
          if(this.state.dataParts!==null && this.state.dataParts.length !==0){
                      if(this.state.storebox>this.state.transbox){
            this.setState({flag3:"-"})
        }else if(this.state.storebox<this.state.transbox){
            this.setState({flag3:"Over"})
            // this.setState({flag3:<Chip label="Over" style={{backgroundColor:'red',color:'white'}} />})
        }else{
            this.setState({flag3: "Finis"})
            // this.setState({flag3: <Chip label="Finis" style={{backgroundColor:'#01bd23',color:'white'}} />})
        }
        // this.setState({dataParts.flag3:this.state.flag3})
        //  this.state.dataParts[0].flag3  = this.state.flag3 
        this.setState(Object.assign(this.state.dataParts[0],{flag3:this.state.flag3}));
          this.settable()
          }
         
    }
   async Setnewtable(){
      await this.getdataPats()
      await this.settable()
    //   this.CheckFlag3()
    }
  async  getdataPats(){
        //   try {
        //       const url =  `${process.env.REACT_APP_API}/Home/parts`
        //     axios.get(url).then(  res =>  {
        //         console.log(res.data)
        //          this.setState({dataParts:res.data})
        //          this.settable()
        //     })
           
        //   } catch (err) {
              
        //   }

          try {
            const instance = axios.create({
                baseURL: `${process.env.REACT_APP_API}/Home/parts`
            });
         const res =   await instance.get()
             console.log(res.data)
             this.setState({dataParts:res.data})
             this.setState({storebox:res.data[0].store_box})
             this.setState({transbox:res.data[0].trans_box})
          
        } catch (err) {
            console.log(err)
        }  
    }
    settable(){
        const row = [];
        var flex = null;
        for (const item of this.state.dataParts){
           console.log(item.flag3,"hhhh")
           if(item.store_box>item.trans_box){
              flex = "-"
           }else if(item.store_box<item.trans_box){
              flex = "Over"
           }else{
              flex = "Finis"
           }
           row.push({
            no_po: item.no_po, 
            supplier: item.supplier, 
            no_parts: item.no_parts, 
            bc_use: item.bc_use, 
            palletize: item.palletize, 
            in_id: item.in_id, 
            store_box: item.store_box, 
            time_store_in: item.time_store_in, 
            out_id: item.out_id, 
            trans_box: item.trans_box,
            time_store_out: item.time_store_out,
            flag3: flex,
            action:   <IconButton color="primary" component="span">
             <EditIcon  onClick={() => this.OpenEdit(item)} style={{color:'orange'}}/>
          </IconButton>
        , 
           })
        }
        const columns = [
            { 
                name: "no_po",
                label: "NoPo",
             
                options: {
                    // setCellHeaderProps: value => ({ style: { textDecoration: 'underline' } }),
                    // customHeadLabelRender: () => ({ style: {fontWeight : "bold" }})
              },
            },
            {
                name: "supplier",
                label: "Supplier",
            },
            {
                name: "no_parts",
                label: "NoParts",
            },
            {
                name: "bc_use",
                label: "BcUse",
            },
            {
                name: "palletize",
                label: "Palletize",
            },
            {
                name: "in_id",
                label: "InId",
            },
            {
                name: "store_box",
                label: "StoreBox",
            },
            {
                name: "time_store_in",
                label: "TimeStoreIn",
            },
            {
                name: "out_id",
                label: "OutId",
            },
            {
                name: "trans_box",
                label: "TransBox",
            },
            {
                name: "time_store_out",
                label: "timeStoreOut",
            },
            {
                name: "flag3",
                label: "Flag3",
            },
            {
                name: "action",
                label: "Action",
                options:{
                    download:false
                }
            }
           
        ];
        
        const options = {
            filterType: 'checkbox',
            // responsive: 'standard',
            filter: false,
            viewColumns: false,
             print: false,
            download:true,
            selectableRows:false,
        };
        // this.setState({showtable:null})
        this.setState({showtable:
        <MUIDataTable
            title={"Parts List"}
            data={row}
            columns={columns}
            // columns={[{}]}
            options={options}
        />})
    }
   async componentDidMount() {
      await this.getdataPats()
       this.settable()
    //   this.CheckFlag3()
    }
    render() {
        let dialogedit
        if(this.state.dialogEdit === true){
            dialogedit = <DialogEdit cancle={this.cancle} data={this.state.dataEdit} get={this.Setnewtable}/>
        }
        return (
            <>{dialogedit}
            <Grid container style={{marginTop:'calc(4%)'}}>
            {/* <Grid item xs = {1}></Grid> */}
                 <Grid item xs = {12}>
                    {this.state.showtable}
                 </Grid>
                 {/* <Grid item xs = {1}></Grid> */}
            </Grid>
                
            </>
        )
    }
}
export default Summary

