import React from 'react'
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import TextField from '@material-ui/core/TextField';
import axios from 'axios';

class Edit extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            slide: null,
            open: false,
            id_update:null,
            palletize_update:null
        }
        this.handleClose = this.handleClose.bind(this);
        this.SetPallet = this.SetPallet.bind(this);
        this.Update = this.Update.bind(this);
         console.log("propss", this.props)
    }
   async Update(){
        const pallet = {
            no_po: "string",
            supplier: "string",
            no_parts: "string",
            bc_use: "string",
            palletize: this.state.palletize_update,
            in_id: "string",
            store_box: 0,
            time_store_in: "string",
            out_id: "string",
            trans_box: 0,
            time_store_out: "string",
            flag3: "string"
         }  
         console.log(pallet)
       try {
        //    url = "http://cptsvs52t/apioverarea/Home/Update/5"
         const url =  `${process.env.REACT_APP_API}/Home/Update/${this.state.id_update}`   
         axios.put(url,pallet).then( async res => {
            console.log(res.data)
           await this.handleClose()
           await this.props.get()
         })
       } catch (err) {
           console.log(err)
       }
      
    }
    SetPallet(e){
       this.setState({palletize_update:e.target.value}) 
    }
    handleClose() {
        this.setState({ open: false })
        setTimeout(() => {
            this.props.cancle()
        }, 200);

    }

    async componentDidMount() {
        await this.setState({palletize_update:this.props.data.palletize})
        await this.setState({id_update:this.props.data.id})
        await this.setState({
            slide: React.forwardRef((props, ref) => {
                return <Slide direction="up" ref={ref} {...props} />
            })
        });
        await this.setState({ open: true, })
    }
    render() {
        return (

            <>

                <Dialog
                    fullWidth="true"
                    maxWidth="xs"
                    open={this.state.open}
                    TransitionComponent={this.state.slide}
                    onClose={this.handleClose}

                >
                    <DialogTitle >Edit Palletize</DialogTitle>
                    <DialogContent>
                        <Grid container style={{  textAlign: 'center' }}>
                            <Grid item xs={1}></Grid>
                     
                            <Grid item xs={10} >
                                    <TextField onChange={this.SetPallet} value={this.state.palletize_update} id="outlined-basic" label="Palletize" variant="outlined" />  
                            </Grid>
                          
                        </Grid>
                 

                        <Grid container style={{ marginTop: 'calc(4%)' , textAlign: 'center' }}>
                            <Grid item xs={12} >
                            <Button variant="contained" onClick={this.Update}  style={{ backgroundColor: '#4dbc82', color: 'white' }}>
                                 Update
                              </Button>
                            </Grid>
                        
                        </Grid>

                    </DialogContent>
                    {/* <DialogActions>
                        <Button color="primary">Check</Button>
                    </DialogActions> */}
                </Dialog>

            </>
        )
    }
}
export default Edit

