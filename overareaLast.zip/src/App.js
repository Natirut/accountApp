// import logo from './logo.svg';\
import React from 'react';
import './App.css';
import Nev from './nevbar/index.component'
import Grid from '@material-ui/core/Grid';
import Page from './page/index.component';
import Footer from './buttom/index.component';
import Login from './login/index.component';
import NevButtom from './nevbuttom/index.component';
class App extends React.Component {
  render() {
    let getUser = localStorage.getItem('username');
    console.log(getUser)
    if (getUser != null) {
      return (
        <>
          <Grid container spacing={0}>
            <Grid item xs={12}>
              <Nev />
              <Footer  />
              <Page/>
              <NevButtom />
            </Grid>
          </Grid>
        </>
      )
    }
    else {
      return (
        <>
         <Login />
        </>
      )
    }

  }
}

export default App;
// function App() {
//   return (
//     <>
//     <Grid container spacing={0}>
//       <Grid item xs={12}>
//         <Nev />
//         <Footer  />
//         <Page/>
//       </Grid>
//     </Grid>
//   </>
//   );
// }

// export default App;
