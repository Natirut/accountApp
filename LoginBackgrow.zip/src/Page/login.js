import React from 'react'
import ParticlesBg from 'particles-bg'
import './style.css'
import {TextField, Grid, Paper, Typography, } from "@material-ui/core";
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
class Login extends React.Component{
     constructor(props){
          super(props)
          this.state={

          }
     }
     componentDidMount(){

     }
     render(){
        let config = {
            num: [4, 7],
            rps: 0.1,
            radius: [5, 40],
            life: [1.5, 3],
            v: [2, 3],
            tha: [-40, 40],
            // body: "./img/icon.png", // Whether to render pictures
            // rotate: [0, 20],
            alpha: [0.6, 0],
            scale: [1, 0.1],
            position: "center", // all or center or {x:1,y:1,width:100,height:100}
            color: ["random", "#ff0000"],
            cross: "dead", // cross or bround
            random: 15,  // or null,
            g: 5,    // gravity
            // f: [2, -1], // force
            onParticleUpdate: (ctx, particle) => {
                ctx.beginPath();
                ctx.rect(particle.p.x, particle.p.y, particle.radius * 2, particle.radius * 2);
                ctx.fillStyle = particle.color;
                ctx.fill();
                ctx.closePath();
            }
          };

         return(
             <>
              <Grid container spacing={0} justify="center" >
          <Grid >
            <Grid item>
              <Grid container direction="column" justify="center" spacing={2} className="login-form">
                <Grid container>
                  <Grid item xs={12} style={{marginTop:'calc(-19%)'}}>
                  </Grid>
                </Grid>
                <Paper
                  variant="elevation"
                  elevation={2}
                  className="login-background"
                >
                  <Grid item>
                    <AccountCircleIcon style={{ fontSize: '70px', color: '#2abfc0' }} />
                    <Typography component="h1" variant="h5">
                      Sign in
               </Typography>
                  </Grid>
                  <Grid item style={{ marginTop: 'calc(5%)' }}>
                      <Grid container direction="column" spacing={6}>
                        <Grid item>
                          <TextField
                            type="text"
                            placeholder="Username"
                            fullWidth
                            name="username"
                            variant="outlined"
                            onKeyPress={this.ChangeSubmit}
                            required
                            autoFocus
                          />
                        </Grid>
                        <Grid item>
                        </Grid>
                      </Grid>
                  </Grid>
                  <Grid item>
                  </Grid>
                </Paper>
              </Grid>
            </Grid>
          </Grid>

        </Grid>
        <ParticlesBg type="thick"  bg={true} />
             </>
         )
     }
}
export default Login

