import React from 'react';
import './App.css';
import Grid from '@material-ui/core/Grid';
import Login from './Page/login'
class App extends React.Component {
  render() {
      return (
        <>
          <Grid container spacing={0}>
            <Grid item xs={12}>
              <Login />
            </Grid>
          </Grid>
        </>
      )
  }
}

export default App;
