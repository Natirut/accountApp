import React from 'react'
import Grid from '@material-ui/core/Grid';
import { Select, MenuItem, InputLabel } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import { Alert, AlertTitle } from '@material-ui/lab';
class IN extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            error: null,
            success: null,
            status: null
        }
        this.ReadyStatus = this.ReadyStatus.bind(this)
        this.ShowAlert = this.ShowAlert.bind(this)

    }
    ShowAlert(){
       setTimeout( () => {
          this.setState({status:this.state.success}) 
        //  this.setState({status:null}) 
       }, 500); 

       setTimeout( () => {
      this.setState({status:null}) 
     }, 3000); 
    }
    async ReadyStatus() {
        await this.setState({
            error: <>
                <Alert severity="error" style={{ height: '100px' }}>
                    <AlertTitle>Error</AlertTitle>
                     This is an error alert — <strong>check it out!</strong>
                </Alert></>
        })
        await this.setState({success:<>
                  <Alert severity="success" style={{ height: '100px' }}>
                       <AlertTitle>Success</AlertTitle>
                       This is a success alert — <strong>check it out!</strong>
                  </Alert>
               </>
        })
    }
    componentDidMount() {
         this.ReadyStatus()
    }
    render() {
        return (
            <>
                <Grid container>
                    <Grid item xs={12}>
                        <FormControl variant="outlined" margin='dense' >
                            <InputLabel id="demo-simple-select-helper-label" style={{ marginTop: '7px' }}>Model</InputLabel>
                            <Select
                                label="Model"
                                labelId="model"
                                id="model"
                                style={{ margin: '7px', width: '100px', }}
                            >
                                <MenuItem value="BOI">BOI</MenuItem>
                                <MenuItem value="NON-BOI">NON-BOI</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                </Grid>

                <Grid container>
                    <Grid item xs={12}>
                        <h3 style={{ marginLeft: 'calc(2%)' }}>Over Check</h3>
                    </Grid>
                </Grid>

                <Grid container>
                    <Grid item xs={12}>
                        <span style={{ marginLeft: 'calc(2%)' }}>Barcode Pallet</span>
                        <TextField style={{ width: '40%', marginLeft: 'calc(2%)', marginTop: 'calc(-2%)' }} size="small" id="outlined-basic" variant="outlined" />
                        <Button onClick={this.ShowAlert} style={{ marginLeft: 'calc(2%)' }} size="small" variant="contained" color="primary">
                            Clear
                         </Button>
                    </Grid>
                </Grid>

                <Grid container style={{ marginTop: 'calc(4%)' }}>
                    <Grid item xs={12}>
                        <span style={{ marginLeft: 'calc(2%)' }}>PO NOF</span>
                        <TextField style={{ width: '40%', marginLeft: 'calc(2%)', marginTop: 'calc(-2%)' }} size="small" id="outlined-basic" variant="outlined" />
                        <Button style={{ marginLeft: 'calc(2%)', color: '#183059' }} size="small" variant="contained" >
                            Clear
                         </Button>
                    </Grid>
                </Grid>

                <Grid container style={{ marginTop: 'calc(10%)' }}>
                    <Grid item xs={12}>
                        {this.state.status}
                    </Grid>
                </Grid>

                {/* <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={12}>
                        <Alert severity="success" style={{ height: '100px' }}>
                            <AlertTitle>Success</AlertTitle>
                              This is a success alert — <strong>check it out!</strong>
                        </Alert>
                    </Grid>
                </Grid> */}
            </>
        )
    }
}
export default IN
