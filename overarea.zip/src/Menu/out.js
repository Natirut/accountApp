import React from 'react'
class Music extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
    
          play: false,
          pause: true
    
        };
    
        this.url = "http://cptsvs52t/overarea/sound/ok.mp3";
        this.audio = new Audio(this.url);
    
      }
    componentDidMount() {
      this.audio.addEventListener('ended', () => this.setState({ play: false }));
    }
  
    // componentWillUnmount() {
    //   this.removeEventListener('ended', () => this.setState({ play: false }));  
    // }
  
    togglePlay = () => {
      this.setState({ play: !this.state.play }, () => {
        this.state.play ? this.audio.play() : this.audio.pause();
      });
    }
  
    render() {
      return (
        <div>
          <button onClick={this.togglePlay}>{this.state.play ? 'Pause' : 'Play'}</button>
        </div>
      );
    }
  }
  
  export default Music;