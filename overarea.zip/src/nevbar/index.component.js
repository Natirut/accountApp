import React from 'react'
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
 import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import AllInboxIcon from '@material-ui/icons/AllInbox';
import DashboardIcon from '@material-ui/icons/Dashboard';
import DomainDisabledIcon from '@material-ui/icons/DomainDisabled';
class NevBar extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }
    componentDidMount() {

    }
    render() {
        return (
            <>
                <div  style={{flexGrow:'1'}}>
                    <AppBar position="static" style={{backgroundColor:'#2abfc0'}}>
                        <Toolbar>
                            <IconButton edge="start" color="inherit" aria-label="menu">
                                {/* <MenuIcon /> */}
                            </IconButton>
                            <Typography variant="h6"  style={{flexGrow:'1'}}>
                               Over Area
                               {/* <Button variant="contained" startIcon={<AllInboxIcon />} style={{margin:'5px'}} color="primary">IN</Button>
                               <Button   variant="contained" startIcon={<DomainDisabledIcon />}  style={{margin:'5px'}} color="primary">OUT</Button>
                               <Button   variant="contained" startIcon={<DashboardIcon />} style={{margin:'5px'}} color="primary">SUMMARY</Button> */}
                       </Typography>
                            {/* <Button color="inherit">Login</Button> */}
                        </Toolbar>
                    </AppBar>
                </div>
            </>
        )
    }
}
export default NevBar

