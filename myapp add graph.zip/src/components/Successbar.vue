<template>
  <v-row justify="center">
    <v-dialog
      v-model="dialog"
      persistent
      max-width="200"
    >
      <v-card>
        <v-card-title class="headline justify-center">
         <center>Loading..</center>
        </v-card-title>

        <v-card-text >
           <center>
                <v-progress-circular
      :rotate="90"
      :size="100"
      :width="20"
      :value="value"
       color="teal"
    >
      {{ value }}
    </v-progress-circular>
           </center>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
export default {
  data () {
    return {
      dialog: true,
      value: 0,
      interval: {}
    }
  },
  mounted () {
    this.interval = setInterval(() => {
      if (this.value === 100) {
        this.dialog = false
      }
      this.value += 100
    }, 1000)
  }
}
</script>
<style scoped>
.v-progress-circular {
  margin: 1rem;
}
</style>
