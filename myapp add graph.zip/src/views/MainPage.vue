<template>
 <v-app >
     <div >
     <!-- <Nev/> -->
    </div>
    <v-main >
      <Main/>
    </v-main>
    <div >
      <!-- <Buttom/> -->
    </div>
  </v-app>
</template>

<script>
import Main from '../views/MainMenu'
// import Nev from '../views/Nevbar'
// import Buttom from '../views/NevButtom'
export default {
  name: 'App',
  components: {
    Main
    // Nev,
    // Buttom
    // Login
  },

  data: () => ({
    name: 'ter',
    test: 'now',
    getuser: ''
  }),
  methods: {
    baby () {
      this.test = 'mmm'
    }
  },
  computed: {
    show () {
      return 0
    }
  }
  // mounted () {
  //   this.getuser = localStorage.getItem('user')
  //   if (localStorage.getItem('user') === null) {
  //     this.$router.replace('/')
  //   }
  //   console.log('mmmmmmmmmmmmm' + localStorage.getItem('user'))
  // }

}
</script>
