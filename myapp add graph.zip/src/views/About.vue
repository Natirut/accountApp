<template>
  <v-row style="margin-top:calc(7%)">
    <v-col class="text-center"  sm="12">
      <!-- <v-btn small color="primary" @click="getdata">Primary</v-btn> -->
      <div class="my-2">
        <v-data-table
    :headers="this.headers"
    :items="this.datarow"
    :items-per-page="5"
    class="elevation-1"
    v-if="this.data!==''"
  >
      <template v-slot:[`item.operater`]="{ items }">
      <v-icon
        small
        class="mr-2"
        @click="editItem(items)"
      >
        mdi-pencil
      </v-icon>
      <v-icon
        small
        @click="deleteItem(items)"
      >
        mdi-delete
      </v-icon>
    </template>
  </v-data-table>
      </div>
    </v-col>
  </v-row>
</template>
<script>
import Axios from 'axios'
export default {
  data: () => ({
    pass: 'test',
    data: ''
  }),
  methods: {
    getdata () {
      try {
        const url = 'http://cptsvs52t/dist/Home/product'
        Axios.get(url).then(res => {
          console.log(res)
          this.data = res.data
        })
      } catch (error) {
        console.log(error)
      }
    },
    editItem (x) {
      console.log('item' + x)
    }
  },
  computed: {
    headers () {
      return [
        { text: 'Product Name', value: 'product_name' },
        { text: 'Product Made', value: 'product_name' },
        { text: 'Product Price', value: 'product_price' },
        { text: 'Product Type', value: 'product_type' },
        { text: 'Product Code', value: 'product_code' },
        { text: 'Operater', value: 'operater' }
      ]
    },
    datarow () {
      console.log(this.data)
      return this.data
    }
  },
  mounted () {
    try {
      const url = 'http://cptsvs52t/dist/Home/product'
      Axios.get(url).then(res => {
        console.log(res)
        this.data = res.data
      })
    } catch (error) {
      console.log(error)
    }
  }
}
</script>
