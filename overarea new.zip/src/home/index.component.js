import React from 'react'
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
class Home extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }
    componentDidMount() {

    }
    render() {
        return (
            <>
                <Grid container style={{ marginTop: 'calc(10%)' }}>
                    <Grid item xs={12} style={{ alignItems: 'center' }}>
                        <center> <img src={"http://cptsvs52t/overarea/logo/water-pump.png"} alt="logo"
                            style={{ width: '200px', height: '200px', }}
                        /></center>
                    </Grid>
                </Grid>
                <Grid container style={{ marginTop: 'calc(2%)' }}>
                    <Grid item xs={12} style={{ alignItems: 'center' }}>
                        <center>
                            <Typography style={{fontWeight:'bold'}} variant="h4" gutterBottom>
                            OVERAREA
                            </Typography>
                        </center>
                    </Grid>
                </Grid>
            </>
        )
    }
}
export default Home

