import React from 'react'
import Grid from '@material-ui/core/Grid';
// import { Select, MenuItem, InputLabel } from '@material-ui/core';
// import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Button from '@material-ui/core/Button';
import { Alert, AlertTitle } from '@material-ui/lab';
// import Music from './component/sound';
import axios from 'axios';
import moment from 'moment';//
import Typography from '@material-ui/core/Typography';
class OUT extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            ponoftemp: null,
            showpallet: null,
            showponof: null,
            error: null,
            success: null,
            status: null,
            dataParts: null,
            sound: true,
            sound2: null,

            dataPO: [],

            usebox: null,
            pallet: null,
            ponof: null,
            supplier: null,
            // boxcode:null,
            noparts: null,
            transbox: 0,
            storebox: 0,
            flag3: null,
            statusfocus:false
        }
        this.ReadyStatus = this.ReadyStatus.bind(this)
        this.ShowAlert = this.ShowAlert.bind(this)
        this.ShowAlertNg = this.ShowAlertNg.bind(this)
        this.Insert = this.Insert.bind(this)
        this.Setponof = this.Setponof.bind(this)
        this.SetTextPallet = this.SetTextPallet.bind(this)
        this.SetTextPonof = this.SetTextPonof.bind(this)
        this.clearpallet = this.clearpallet.bind(this)
        this.clearponof = this.clearponof.bind(this)
        this.Setpallet = this.Setpallet.bind(this)
        // this.SetBoxCode = this.SetBoxCode.bind(this)
        this.Node = this.Node.bind(this)
        this.CheckPlusBox = this.CheckPlusBox.bind(this)
        //CheckPlusBox
        this.findsupplier = this.findsupplier.bind(this)
    }


    async Setpallet(e) {
        if (e.key === 'Enter') {
       
            //  await this.SetBoxCode()
            setTimeout( async () => {
                await this.setState({ pallet: e.target.value })
                await this.setState({statusfocus:true})
                await this.SetTextPonof()
                await this.Node()
            }, 2000);
             
            
            console.log("ppppppppp")
           
            }
    }

    async clearpallet() {
        await this.setState({ pallet: null })
        // await this.setState({ showpallet: null })
        this.SetTextPallet()
    }
    async clearponof() {
        await this.setState({ ponof: null })
        // await this.setState({ showponof: null })
        this.SetTextPonof()
    }
    async SetTextPallet() {
        await this.setState({ showpallet: null })
        await this.setState({
            showpallet:
                //  <TextField value={this.state.pallet} onChange={this.Setpallet} style={{ width: '40%', marginLeft: 'calc(2%)', marginTop: 'calc(-2%)' }} size="small" id="outlined-basic" variant="outlined" />
                <TextField value={this.state.pallet} onKeyPress={this.Setpallet} style={{ width: '70%' }} size="small" id="outlined-basic" label="Barcoad Pallet" variant="outlined" />
        })
    }
    async SetTextPonof() {
        await this.setState({showponof:null})
        await this.setState({
            showponof:
                // <TextField  value={this.state.ponof}  onChange={this.Setponof} style={{ width: '40%', marginLeft: 'calc(2%)', marginTop: 'calc(-2%)' }} size="small" id="outlined-basic" variant="outlined" />
                <TextField autoFocus={this.state.statusfocus} value={this.state.ponof} onKeyPress={this.Setponof} style={{ width: '70%' }} size="small" id="outlined-basic" label="PO NOF" variant="outlined" />
        })
    }
    async Setponof(e) {
        //  await this.setState({ponof:e.target.value}) 
        
        if (e.key === 'Enter') {
            setTimeout( async () => {
                await this.setState({ ponoftemp: e.target.value })
                await this.setState({ ponof: e.target.value.substring(8, 17) })
                await this.postbyid()
                await this.findsupplier()
                await this.Node()
            }, 2000);
             
        }
    }

    async findsupplier() {
        const body = {
            "command": `select cd_sply from j300_purchase_order_status where no_po = '${this.state.ponof}' and no_parts = '${this.state.noparts}' and cd_use_block = '${this.state.usebox}'`
        }
        console.log("body",body)
        if (this.state.ponoftemp.length === 22) {
                try {
                    const instance = axios.create({
                        baseURL: "http://cptsvs531:1000/middleware/oracle/euc"
                    });
                    const body = {
                        "command": `select cd_sply from j300_purchase_order_status where no_po = '${this.state.ponof}' and no_parts = '${this.state.noparts}' and cd_use_block = '${this.state.usebox}'`
                    }
                    console.log("body")
                    const res = await instance.post("", body)
                    this.setState({ supplier: res.data.data[0].CD_SPLY })
                    console.log(this.state.supplier)
                } catch (err) {
                    console.log(err)
                }
        }
    }
    async postbyid() {
        // console.log("\"Hello\"")
        if (this.state.ponoftemp.length === 22) {
            try {
                const instance = axios.create({
                    baseURL: "http://cptsvs531:1000/middleware/oracle/euc"
                });
                const body = {
                    "command": `select NO_PARTS,NO_PO,CD_USE_BLOCK from BUVKA001.j300_by_po where no_po = '${this.state.ponof}'`

                }
                const res = await instance.post("", body)
                await this.setState({ dataPO: res.data.data })
                console.log(res.data)
                await this.setState({ noparts: res.data.data[0].NO_PARTS })
                await this.setState({ usebox: res.data.data[0].CD_USE_BLOCK })

            } catch (err) {
                console.log(err)
            }
        }
    }

    Node() {
        console.log(this.state.dataPO, "NNNNNNNNNNNNNNNNNNNN")
        if (this.state.ponoftemp) {
            if (this.state.ponof !== null && this.state.pallet !== null) {
                if (this.state.dataPO === null) {
                    //  if (this.state.ponoftemp.length === 22) {
                        console.log("on1")
                    this.ShowAlertNg()
                    // }
                } else {
                    if (this.state.dataPO.length !== 0) {
                        if (this.state.ponof !== null && this.state.noparts !== null && this.state.usebox !== null){
                                 console.log("on2")
                        if (this.state.ponoftemp.length === 22) {
                            this.ShowAlert()
                            this.Insert()
                            console.log("on3")
                            // document.getElementById("sound").click()
                        }
                        }
                       

                    }
                    else {
                        console.log("on4")
                        //  if (this.state.ponoftemp.length === 22) {
                        this.ShowAlertNg()
                        //   }

                    }
                }
            }
        }
        // console.log("node", this.state.ponoftemp.length )


    }
    async CheckPlusBox() {

        try {
            const instance = axios.create({
                baseURL: `${process.env.REACT_APP_API}/Home/GetByPo?po=${this.state.ponof}&area=${this.state.pallet}`
            });
            const res = await instance.post("")
            this.setState({ storebox: res.data[0].store_box })
            this.setState({ transbox: res.data[0].trans_box })
        } catch (err) {
            console.log(err)
        }
    }
    async Insert() {
        await this.CheckPlusBox()
        try {
            const data = {
                no_po: this.state.ponof,
                supplier: this.state.supplier,
                no_parts: this.state.noparts,//
                bc_use: this.state.usebox,
                palletize: this.state.pallet,
                in_id: "-",//
                store_box: 0,
                time_store_in: "-",
                out_id: localStorage.getItem('username'),//
                trans_box: this.state.transbox + 1,
                time_store_out: moment(new Date()).format('DD/MM/YYYY HH:mm'),
                flag3: "-"
            }
            //    const url = "http://cptsvs52t/apioverarea/Home/Insert"
            const url = process.env.REACT_APP_API + '/Home/InsertOUT'
            axios.post(url, data)
            //  this.ShowAlert()
        } catch (err) {
            console.log(err)
        }
        setTimeout(() => {
            // this.clearpallet()
            this.clearponof()
        }, 1300);



    }
    ShowAlert() {
        document.getElementById('ok').play();
        this.setState({ status: this.state.success })
        setTimeout(()  => {
            this.setState({ status: null })
        }, 1000);
    }

    ShowAlertNg() {
        document.getElementById('ng').play();
        this.setState({ status: this.state.error })
    setTimeout(() => {
        this.setState({ status: null })
    }, 1000);
    }

    async ReadyStatus() {
        await this.setState({
            error: <>
                <Alert severity="error" style={{ height: '100px' }}>
                    <AlertTitle>Error</AlertTitle>
                     This is an error alert — <strong>check it out!</strong>
                </Alert></>
        })
        await this.setState({
            success: <>
                <Alert severity="success" style={{ height: '100px' }}>
                    <AlertTitle>Success</AlertTitle>
                       This is a success alert — <strong>check it out!</strong>
                </Alert>
            </>
        })
    }
    async componentDidMount() {
        await this.ReadyStatus()
        await this.SetTextPallet()
        await this.SetTextPonof()
    }

    render() {
        return (
            <>
            {/* {this.state.sound2} */}
                    <audio id="ok" src="http://cptsvs52t/overarea/sound/ok.mp3" />
                    <audio id="ng" src="http://cptsvs52t/overarea/sound/ng.mp3" />
                <Grid container style={{ marginLeft: 'calc(6%)' }}>
                    <Grid item xs={12} >
                        <Typography><h3 style={{ marginLeft: 'calc(2%)', color: '#777777' }}>Over Check OUT</h3></Typography>
                        {/* <Typography variant="h6" gutterBottom>
                            <h4 >Over Check</h4>
                        </Typography> */}
                    </Grid>
                </Grid>

                <Grid container style={{ textAlign: 'center' }} >
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={10}>
                        <ButtonGroup disableElevation variant="contained" color="primary">
                            {/* <TextField style={{ width: '70%' }} size="small" id="outlined-basic" label="Barcoad Pallet" variant="outlined" /> */}
                            {this.state.showpallet}
                            <Button onClick={this.clearpallet} size="small" variant="contained" color="primary">
                                Clear
                         </Button>
                        </ButtonGroup>
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>

                <Grid container style={{ textAlign: 'center', marginTop: 'calc(3%)' }} >
                    <Grid item xs={1}>

                    </Grid>
                    <Grid item xs={10}>
                        <ButtonGroup disableElevation variant="contained" color="primary">
                            {this.state.showponof}
                            <Button onClick={this.clearponof} size="small" variant="contained" >
                                Clear
                         </Button>
                        </ButtonGroup>
                    </Grid>
                    <Grid item xs={1}>

                    </Grid>
                </Grid>
                {/* 
                <Grid container style={{ marginTop: 'calc(10%)' }}>
                    <Grid item xs={6}>
                     <Button onClick={this.ShowAlert} style={{ marginLeft: 'calc(2%)',backgroundColor:'#2abfc0' }} size="small" variant="contained" color="primary">
                            TestOk
                         </Button>
                    </Grid>
                    <Grid item xs={6}>
                     <Button color="secondary" onClick={this.ShowAlertNg} style={{ marginLeft: 'calc(2%)' }} size="small" variant="contained">
                           TestNg
                         </Button>
                    </Grid>
                </Grid> */}

                <Grid container style={{ marginTop: 'calc(10%)' }}>
                    <Grid item xs={12}>
                        {this.state.status}
                    </Grid>
                </Grid>

                {/* <Grid container style={{ marginTop: 'calc(3%)' }}>
                    <Grid item xs={12}>
                        <Alert severity="success" style={{ height: '100px' }}>
                            <AlertTitle>Success</AlertTitle>
                              This is a success alert — <strong>check it out!</strong>
                        </Alert>
                    </Grid>
                </Grid> */}
            </>
        )
    }
}
export default OUT
