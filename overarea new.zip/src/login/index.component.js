import React from "react";
import './style.css'
import Axios from 'axios';
import ReactDom from 'react-dom';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import Atp from '../App';
import { Button, TextField, Grid, Paper, Typography, } from "@material-ui/core";
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      authflag: 1
    };
    this.SetUsername = this.SetUsername.bind(this);
    this.SetPassword = this.SetPassword.bind(this);
    this.Submit = this.Submit.bind(this);
    this.ChangeSubmit = this.ChangeSubmit.bind(this);
  }
  SetUsername(e) {
    this.setState({ username: e.target.value });
    console.log(e.target.value)
  }
  SetPassword(e) {
    console.log(e.target.value)
    this.setState({ password: e.target.value });
  }
  ChangeSubmit(e){
      console.log(e.key)
    if (e.key === 'Enter') {
       this.Submit()
    }
  }
  async Submit() {
  
    try {

      const user = {
        username: this.state.username,
        password: this.state.password
      }

      console.log('BODY: ', user)

      const url = "http://cptsvs52t/apioverarea/Home/login"
      Axios.post(url, user, { headers: { 'Content-Type': 'application/json' } }).then((res) => {
        console.log(res.data.length)
        if (res.data.length !== 0) {
          localStorage.setItem('username', res.data[0].username);
          ReactDom.unmountComponentAtNode(document.getElementById('root'))
          ReactDom.render(<Atp />, document.getElementById('root'));
        }

      }).catch((err) => {
        console.log(err.response);
      })
    } catch (err) {
      console.log(err)
    }
  }
  render() {
    return (
      <>
        <Grid container spacing={0} justify="center" >
          <Grid >
            <Grid item>
              <Grid container direction="column" justify="center" spacing={2} className="login-form">
                <Paper
                  variant="elevation"
                  elevation={2}
                  className="login-background"
                >
                  <Grid item>
                 <AccountCircleIcon style={{fontSize:'70px',color:'#2abfc0'}}/>
                    <Typography component="h1" variant="h5">
                      Sign in
               </Typography>
                  </Grid>
                  <Grid item>
                    <form onSubmit={this.handleSubmit}>
                      <Grid container direction="column" spacing={6}>
                        <Grid item>
                          <TextField
                            type="text"
                            placeholder="Username"
                            fullWidth
                            name="username"
                            variant="outlined"
                            // value={this.state.username}
                            onChange={this.SetUsername}
                            required
                            autoFocus
                          />
                        </Grid>
                        <Grid item>
                          <TextField
                            type="password"
                            placeholder="Password"
                            fullWidth
                            name="password"
                            variant="outlined"
                            // value={this.state.password}
                            onKeyDown={this.ChangeSubmit}
                            onChange={this.SetPassword}
                            required
                          />
                        </Grid>
                        <Grid item>
                          <Button onClick={this.Submit} onKeyDown={this.Submit}  variant="contained" color="primary" className="button-block">
                            Submit
                        </Button>
                        </Grid>
                      </Grid>
                    </form>
                  </Grid>
                  <Grid item>
                    {/* <Link href="#" variant="body2">
                    Forgot Password?
                  </Link> */}
                  </Grid>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
     
        </Grid>
      </>
    );
  }
}
export default Login;