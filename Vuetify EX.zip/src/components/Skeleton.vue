<template>
      <div style="margin-top:calc(2%)">
          <v-skeleton-loader
           type="table"
        ></v-skeleton-loader>
      </div>
</template>
<script>
export default {
  data: () => ({
    attrs: {
      class: 'mb-6',
      boilerplate: true,
      elevation: 2
    }
  })
}
</script>
