<template>
  <div>
     <v-container>
      <v-row>
          <v-col  sm="4">
                  <barchart :chartdata="chartData" :options="chartOptions"/>
         </v-col>
            <v-col  sm="4">
                  <areachart :chartdata="chartData" :options="chartOptions"/>
         </v-col>
            <v-col  sm="4">
                <piechart :chartdata="chartData" :options="chartOptions"/>
         </v-col>
     </v-row>
      <v-row>
            <v-col  sm="4">
                  <radachart :chartdata="chartData" :options="chartOptions"/>
         </v-col>
             <v-col  sm="4">
                  <donutchart :chartdata="chartData" :options="chartOptions"/>
         </v-col>
             <v-col  sm="4">
                  <linechart :chartdata="chartData" :options="chartOptions"/>
         </v-col>
     </v-row>
   </v-container>
  </div>
</template>
<script>
import linechart from '../components/Chart/Line'
import barchart from '../components/Chart/Bar'
import piechart from '../components/Chart/Pie'
import radachart from '../components/Chart/Rada'
import areachart from '../components/Chart/Area'
import donutchart from '../components/Chart/Donut'
export default {
  components: {
    linechart,
    barchart,
    piechart,
    radachart,
    areachart,
    donutchart
  },
  data () {
    return {
      chartdata: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'Data One',
            backgroundColor: ['#b3d4f4', '#8f93ec', '#99ee88', '#f9b47b', '#434348', '#f15c80', '#f45b5b'],
            data: [2, 10, 5, 9, 1, 6, 20]
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false
      }
    }
  },
  computed: {
    chartData () {
      return this.chartdata
    },
    chartOptions () {
      return this.options
    }
  }
}
</script>
