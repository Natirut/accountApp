<template>
 <v-app >

<div v-if="hide">
 <Nev/>
</div>
 <v-main>
    <router-view />
 </v-main>
<div v-if="hide">
 <NevButtom/>
</div>
  </v-app>
</template>

<script>
// import Login from './views/Login.vue'
// import Main from './views/MainPage'
import Nev from './views/Nevbar'
import NevButtom from './views/NevButtom'
export default {
  name: 'App',
  components: {
    // Main,
    Nev,
    NevButtom
    // Login
  },
  data: () => ({
    name: 'ter',
    test: 'now',
    getuser: ''
  }),
  methods: {
    baby () {
      this.test = 'mmm'
    }
  },
  computed: {
    show () {
      return localStorage.getItem('user')
    },
    hide () {
      return this.$route.path !== '/'
    }
  },
  mounted () {
    // this.getuser = localStorage.getItem('user')
    // console.log('mmmmmmmmmmmmm' + localStorage.getItem('user'))
    if (localStorage.getItem('user') === null) {
      this.$router.replace('/')
    }
  }

}
</script>

  <style lang="sass">
    @import '../node_modules/typeface-roboto/index.css'
  </style>
